package com.example.myapplication2.ui.materia.agregar_materia

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.databinding.FragmentAgregarMateriaBinding
import com.example.myapplication2.ui.materia.MateriaRepository

class AgregarMateriaFragment : Fragment() {

    private var _binding: FragmentAgregarMateriaBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: AgregarMateriaViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarMateriaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val databaseHelper = DatabaseHelper(requireContext())
        val materiaRepository = MateriaRepository(databaseHelper)
        val factory = AgregarMateriaVMFactory(materiaRepository)
        viewModel = ViewModelProvider(this, factory).get(AgregarMateriaViewModel::class.java)

        binding.buttonAceptar.setOnClickListener {
            val nombreMateria = binding.etNombreMateria.text.toString()
            val usaPorcentaje = binding.switchUsaPorcentaje.isChecked

            if (nombreMateria.isBlank()){
                binding.etNombreMateria.error = "Nombre de materia requerido"
                binding.textinputError.text = "Nombre de materia requerido"
                return@setOnClickListener
            }
            if (nombreMateria.isNotBlank()) {
                viewModel.guardarMateria(nombreMateria, usaPorcentaje)
                findNavController().popBackStack()
            }
        }

        binding.buttonCancelar.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}