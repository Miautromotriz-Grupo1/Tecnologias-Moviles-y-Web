package com.example.myapplication2

data class Materia(
    val id: Int=0,
    val titulo: String,
    val usaporcentaje: Int
) {}
data class Evaluacion(
    val id: Int,
    val materiaid: Int,
    val nombre: String,
    val porcentaje: Int,
    val notamax: Float
){}
data class NotaAlumno(
    val id: Int,
    val evaluacionid: Int,
    val nota: Float
){}

data class MateriaConteo(
    val materia: Materia,
    val conteoEvaluaciones: Int
)
