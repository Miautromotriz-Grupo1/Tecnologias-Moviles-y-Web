package com.example.myapplication2.ui.nota

import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.NotaAlumno

class NotaRepository(private val db: DatabaseHelper) {
        // NotaAlumno
    fun GetAll() = db.getAllNotaAlumno()
    fun GetById(id: Int) = db.getByIdNotaAlumno(id)
    fun GetByEvaluacion(evalId: Int) = db.getByEvalIdNotaAlumno(evalId)
    fun GetAllByMateria(materiaId: Int) = db.getAllNotaAlumnoByMateriaId(materiaId)
    fun Insert(n: NotaAlumno) = db.insertNotaAlumno(n)
    fun Update(n: NotaAlumno)=db.updateNotaAlumno(n)
    fun Delete(id: Int) = db.deleteNotaAlumno(id)
}