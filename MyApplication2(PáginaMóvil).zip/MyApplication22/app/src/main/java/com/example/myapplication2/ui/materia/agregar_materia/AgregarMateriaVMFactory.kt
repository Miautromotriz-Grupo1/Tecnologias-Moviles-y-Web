package com.example.myapplication2.ui.materia.agregar_materia

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication2.ui.materia.MateriaRepository

class AgregarMateriaVMFactory(private val materiaRepository: MateriaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AgregarMateriaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AgregarMateriaViewModel(materiaRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}