package com.example.myapplication2

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
        val navController = navHost.navController

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_nota, R.id.navigation_materia,R.id.navigation_agregar_nota,R.id.navigation_agregar_materia,R.id.navigation_evaluaciones,R.id.navigation_editar_materia
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        val bottom: BottomNavigationView = binding.navView
        bottom.setupWithNavController(navController)
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.navigation_nota,
                R.id.navigation_agregar_nota -> bottom.menu.findItem(R.id.navigation_nota).isChecked = true

                R.id.navigation_materia,
                R.id.navigation_agregar_materia -> bottom.menu.findItem(R.id.navigation_materia).isChecked = true

                R.id.navigation_evaluaciones -> bottom.menu.findItem(R.id.navigation_materia).isChecked = true
                R.id.navigation_editar_materia -> bottom.menu.findItem(R.id.navigation_materia).isChecked = true
            }
        }
        fun onSupportNavigateUp(): Boolean {
            val navHost = supportFragmentManager
                .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
            return navHost.navController.navigateUp() || super.onSupportNavigateUp()
        }
    }
}