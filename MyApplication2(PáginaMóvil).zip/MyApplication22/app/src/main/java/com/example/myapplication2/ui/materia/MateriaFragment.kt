package com.example.myapplication2.ui.materia

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.databinding.FragmentMateriaBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MateriaFragment : Fragment() {

    private var _binding: FragmentMateriaBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: MateriasAdapter
    private lateinit var viewModel: MateriaViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMateriaBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val database = DatabaseHelper(requireContext())
        val repository = MateriaRepository(database)
        val factory = MateriaVMFactory(repository)
        viewModel = ViewModelProvider(this, factory)[MateriaViewModel::class.java]

        setupRecyclerView()

        viewModel.text.observe(viewLifecycleOwner) {
            binding.textMateria.text = it
        }

        viewModel.materias.observe(viewLifecycleOwner) { materias ->
            adapter.submitList(materias)
            binding.textMateria.visibility = if (materias.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerMaterias.visibility = if (materias.isEmpty()) View.GONE else View.VISIBLE
        }

        binding.actionToAgregarMateria.setOnClickListener {
            val action = MateriaFragmentDirections.actionToAgregarMateria()
            findNavController().navigate(action)
        }

        return root
    }

    override fun onResume() {
        super.onResume()
        viewModel.cargarMaterias()
    }

    private fun setupRecyclerView() {
        adapter = MateriasAdapter(
            onClick = { materiaConteo ->
                val action = MateriaFragmentDirections.actionMateriaToEvaluaciones(materiaConteo.materia.id)
                findNavController().navigate(action)
            },
            onDeleteClick = { materiaConteo ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Confirmar eliminación")
                    .setMessage("¿Estás seguro de que quieres eliminar la materia \"${materiaConteo.materia.titulo}\"?\n Se eliminaran todas las evaluaciones y notas de esta materia.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Eliminar") { _, _ ->
                        viewModel.eliminarMateria(materiaConteo)
                    }
                    .show()
            },
            onEditClick = { materiaConteo ->
                val action = MateriaFragmentDirections.actionToEditarMateria(materiaConteo.materia.id)
                findNavController().navigate(action)
            }

        )
        binding.recyclerMaterias.layoutManager = LinearLayoutManager(context)
        binding.recyclerMaterias.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
