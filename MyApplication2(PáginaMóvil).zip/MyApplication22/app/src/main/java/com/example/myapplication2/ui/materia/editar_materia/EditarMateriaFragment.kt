package com.example.myapplication2.ui.materia.editar_materia

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.databinding.FragmentEditarMateriaBinding
import com.example.myapplication2.ui.materia.MateriaRepository

class EditarMateriaFragment : Fragment() {

    private var _binding: FragmentEditarMateriaBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: EditarMateriaViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarMateriaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val databaseHelper = DatabaseHelper(requireContext())
        val materiaRepository = MateriaRepository(databaseHelper)
        val factory = EditarMateriaVMFactory(materiaRepository)
        viewModel = ViewModelProvider(this, factory).get(EditarMateriaViewModel::class.java)

        val materiaId = arguments?.getInt("materiaId")
        if (materiaId != null) {
            viewModel.cargarMateria(materiaId)
        } else {
            findNavController().popBackStack()
            return
        }

        viewModel.materia.observe(viewLifecycleOwner) { materia ->
            materia?.let {
                (requireActivity() as AppCompatActivity).supportActionBar?.title = "Editar Materia: ${it.titulo}"
                binding.editarNombreMateria.setText(it.titulo)
                binding.switchUsaPorcentaje.isChecked = it.usaporcentaje == 1
            }
        }

        binding.buttonAceptar.setOnClickListener {
            val nombreMateria = binding.editarNombreMateria.text.toString()
            val usaPorcentaje = binding.switchUsaPorcentaje.isChecked

            if (nombreMateria.isBlank()) {
                binding.editarNombreMateria.error = "Nombre de materia requerido"
                binding.textinputError.text = "Nombre de materia requerido"
                return@setOnClickListener
            }

            viewModel.actualizarMateria(materiaId,nombreMateria, usaPorcentaje)
            findNavController().popBackStack()
        }

        binding.buttonCancelar.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}