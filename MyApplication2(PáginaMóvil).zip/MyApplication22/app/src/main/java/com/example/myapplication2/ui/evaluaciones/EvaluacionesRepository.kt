package com.example.myapplication2.ui.evaluaciones

import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.Evaluacion

class EvaluacionesRepository(private val db: DatabaseHelper) {
    fun getAll() = db.getAllEval()
    fun getById(id: Int) = db.getByIdEval(id)
    fun getAllByMateria(materiaId: Int) = db.getBymateriaId(materiaId)
    fun insert(evaluacion: Evaluacion) = db.insertEval(evaluacion)
    fun update(evaluacion: Evaluacion) = db.updateEval(evaluacion)
    fun delete(id: Int) = db.deleteEval(id)
    fun getmateria(id: Int) = db.getByIdMateria(id)
}
