package com.example.myapplication2.ui.materia.editar_materia

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication2.Materia
import com.example.myapplication2.ui.materia.MateriaRepository
import kotlinx.coroutines.launch

class EditarMateriaViewModel(private val repository: MateriaRepository) : ViewModel() {

    private val _materia = MutableLiveData<Materia?>()
    val materia: LiveData<Materia?> = _materia

    fun cargarMateria(id: Int) {
        viewModelScope.launch {
            _materia.value = repository.getById(id)
        }
    }
    fun actualizarMateria(id:Int?,nombreMateria: String, usaPorcentaje: Boolean) {
        viewModelScope.launch {
            val materiaActual = _materia.value
            if (materiaActual != null) {
                val materiaActualizada = materiaActual.copy(
                    id = id!!,
                    titulo = nombreMateria,
                    usaporcentaje = if (usaPorcentaje) 1 else 0
                )
                repository.update(materiaActualizada)
            }
        }
    }
}