package com.example.myapplication2.ui.materia.agregar_materia

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.myapplication2.Materia
import com.example.myapplication2.ui.materia.MateriaRepository

class AgregarMateriaViewModel(private val materiaRepository: MateriaRepository) : ViewModel() {



    fun guardarMateria(nombre: String, usaPorcentaje: Boolean) {
        val usaPorcentajeInt = if (usaPorcentaje) 1 else 0
        val nuevaMateria = Materia(titulo = nombre, usaporcentaje = usaPorcentajeInt)
        materiaRepository.insert(nuevaMateria)
    }
}