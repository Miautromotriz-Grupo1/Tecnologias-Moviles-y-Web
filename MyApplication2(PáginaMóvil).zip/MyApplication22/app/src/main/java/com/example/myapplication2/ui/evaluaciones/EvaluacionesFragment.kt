package com.example.myapplication2.ui.evaluaciones

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.databinding.FragmentEvaluacionesBinding

class EvaluacionesFragment : Fragment() {

    private var _binding: FragmentEvaluacionesBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: EvaluacionesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEvaluacionesBinding.inflate(inflater, container, false)

        val database = DatabaseHelper(requireContext())
        val repository = EvaluacionesRepository(database)
        val factory = EvaluacionesVMFactory(repository)
        viewModel = ViewModelProvider(this, factory)[EvaluacionesViewModel::class.java]

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val materiaId = arguments?.getInt("materiaId")

        if (materiaId != null) {
            viewModel.cargarMateria(materiaId)
        }else{
            findNavController().popBackStack()
        }

        viewModel.materia.observe(viewLifecycleOwner) { materia ->
            if (materia != null) {
                (requireActivity() as AppCompatActivity).supportActionBar?.title = "Evaluaciones de ${materia.titulo}"
            }
        }

        binding.actionToMateria.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
