package com.example.myapplication2.ui.evaluaciones

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.myapplication2.Materia

class EvaluacionesViewModel(private val repository: EvaluacionesRepository) : ViewModel() {

    private val _materia = MutableLiveData<Materia?>()
    val materia: LiveData<Materia?> = _materia

    fun cargarMateria(id: Int) {
        _materia.value = repository.getmateria(id)
    }
}
