    package com.example.myapplication2

    import android.content.ContentValues
    import android.content.Context
    import android.database.sqlite.SQLiteDatabase
    import android.database.sqlite.SQLiteOpenHelper

    class DatabaseHelper(context: Context) : SQLiteOpenHelper(
        context,DATABASE_NAME,null,DATABASE_VERSION
    ) {
        override fun onCreate(db: SQLiteDatabase?) {
            // Tabla Materia, en usa porcentaje es 0 o 1, para el boleano
            val createMateriaTable = """
        CREATE TABLE $TABLE_MATER_NAME (
            $COLUMN_MATER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_MATER_TITULO TEXT NOT NULL,
            $COLUMN_MATER_USAPORCENTAJE INTEGER NOT NULL
        )
    """.trimIndent()

            //tabla evaluaciones

            val createEvaluacionTable = """
        CREATE TABLE $TABLE_EVAL_NAME (
            $COLUMN_EVAL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_EVAL_MATERIAID INTEGER NOT NULL,
            $COLUMN_EVAL_NOMBRE TEXT NOT NULL,
            $COLUMN_EVAL_PORCENTAJE INTEGER,
            $COLUMN_EVAL_NOTAMAX FLOAT,
            FOREIGN KEY($COLUMN_EVAL_MATERIAID) REFERENCES $TABLE_MATER_NAME($COLUMN_MATER_ID)
                ON DELETE CASCADE ON UPDATE CASCADE
        )
    """.trimIndent()

            //tabla evaluaciones

            val createNotaAlumnoTable = """
        CREATE TABLE $TABLE_NOTAALUMNO_NAME (
            $COLUMN_NOTAALUMNO_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_NOTAALUMNO_EVALUACIONID INTEGER NOT NULL,
            $COLUMN_NOTAALUMNO_NOTA FLOAT NOT NULL,
            FOREIGN KEY($COLUMN_NOTAALUMNO_EVALUACIONID) REFERENCES $TABLE_EVAL_NAME($COLUMN_EVAL_ID)
                ON DELETE CASCADE ON UPDATE CASCADE
        )
    """.trimIndent()

            db?.execSQL(createMateriaTable)
            db?.execSQL(createEvaluacionTable)
            db?.execSQL(createNotaAlumnoTable)
        }

        override fun onUpgrade(
            db: SQLiteDatabase?,
            oldVersion: Int,
            newVersion: Int
        ) {
            if (db == null) return

            // Deshabilita FK temporalmente para evitar errores al dropear
            db.execSQL("PRAGMA foreign_keys=OFF")

            // Borra primero las hijas y luego la padre
            db.execSQL("DROP TABLE IF EXISTS $TABLE_NOTAALUMNO_NAME")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_EVAL_NAME")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_MATER_NAME")

            // Rehabilita FK
            db.execSQL("PRAGMA foreign_keys=ON")

            onCreate(db)
        }
        //  DAO - tabla NotaAlumno
        fun insertNotaAlumno(e: NotaAlumno): Long = writableDatabase.use { db->
            val values = ContentValues().apply {
                put(COLUMN_NOTAALUMNO_EVALUACIONID, e.evaluacionid)
                put(COLUMN_NOTAALUMNO_NOTA, e.nota)
            }
            db.insert(TABLE_NOTAALUMNO_NAME, null, values)
        }
        fun getAllNotaAlumno(): List<NotaAlumno> = readableDatabase.use { db ->
            db.query(
                TABLE_NOTAALUMNO_NAME, null,
                null, null, null, null,
                "$COLUMN_NOTAALUMNO_ID DESC"
            ).use { c ->
                val out = mutableListOf<NotaAlumno>()
                while (c.moveToNext()) {
                    out += NotaAlumno(
                        id = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_ID)),
                        evaluacionid = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_EVALUACIONID)),
                        nota = c.getFloat(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_NOTA)),
                     )
                }
                out
            }
        }
        fun getByIdNotaAlumno(id: Int): NotaAlumno? = readableDatabase.use { db ->
            db.query(
                TABLE_NOTAALUMNO_NAME, null,
                "$COLUMN_NOTAALUMNO_ID = ?", arrayOf(id.toString()),
                null, null, null
            ).use { c ->
                if (!c.moveToFirst()) return@use null
                NotaAlumno(
                    id = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_ID)),
                    evaluacionid = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_EVALUACIONID)),
                    nota = c.getFloat(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_NOTA))
                )
            }
        }
        fun getByEvalIdNotaAlumno(evaluacion_id: Int): NotaAlumno? = readableDatabase.use { db ->
            db.query(
                TABLE_NOTAALUMNO_NAME, null,
                "$COLUMN_NOTAALUMNO_EVALUACIONID = ?", arrayOf(evaluacion_id.toString()),
                null, null, null
            ).use { c ->
                if (!c.moveToFirst()) return@use null
                NotaAlumno(
                    id = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_ID)),
                    evaluacionid = c.getInt(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_EVALUACIONID)),
                    nota = c.getFloat(c.getColumnIndexOrThrow(COLUMN_NOTAALUMNO_NOTA))
                )
            }
        }
        fun updateNotaAlumno(e: NotaAlumno): Int = writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(COLUMN_NOTAALUMNO_EVALUACIONID, e.evaluacionid)
                put(COLUMN_NOTAALUMNO_NOTA, e.nota)
            }
            db.update(
                TABLE_NOTAALUMNO_NAME, values,
                "$COLUMN_NOTAALUMNO_ID = ?", arrayOf(e.id.toString())
            )
        }
        fun deleteNotaAlumno(id: Int): Int = writableDatabase.use { db ->
            db.delete(
                TABLE_NOTAALUMNO_NAME,
                "$COLUMN_NOTAALUMNO_ID = ?", arrayOf(id.toString())
            )
        }
        fun getAllNotaAlumnoByMateriaId(materiaId: Int): List<NotaAlumno> = readableDatabase.use { db ->
            db.rawQuery(
                """
        SELECT na.$COLUMN_NOTAALUMNO_ID,
               na.$COLUMN_NOTAALUMNO_EVALUACIONID,
               na.$COLUMN_NOTAALUMNO_NOTA
        FROM $TABLE_NOTAALUMNO_NAME AS na
        JOIN $TABLE_EVAL_NAME AS e
          ON e.$COLUMN_EVAL_ID = na.$COLUMN_NOTAALUMNO_EVALUACIONID
        WHERE e.$COLUMN_EVAL_MATERIAID = ?
        ORDER BY na.$COLUMN_NOTAALUMNO_ID DESC
        """.trimIndent(),
                arrayOf(materiaId.toString())
            ).use { c ->
                val out = mutableListOf<NotaAlumno>()
                while (c.moveToNext()) {
                    out += NotaAlumno(
                        id = c.getInt(0),
                        evaluacionid = c.getInt(1),
                        nota = c.getFloat(2)
                    )
                }
                out
            }
        }



        //  DAO - tabla Evalucion
        fun insertEval(e: Evaluacion): Long = writableDatabase.use { db->
            val values = ContentValues().apply {
                put(COLUMN_EVAL_MATERIAID, e.materiaid)
                put(COLUMN_EVAL_NOMBRE, e.nombre)
                put(COLUMN_EVAL_PORCENTAJE, e.porcentaje)
                put(COLUMN_EVAL_NOTAMAX, e.notamax)
            }
            db.insert(TABLE_EVAL_NAME, null, values)
        }
        fun getAllEval(): List<Evaluacion> = readableDatabase.use { db ->
            db.query(
                TABLE_EVAL_NAME, null,
                null, null, null, null,
                "$COLUMN_EVAL_ID DESC"
            ).use { c ->
                val out = mutableListOf<Evaluacion>()
                while (c.moveToNext()) {
                    out += Evaluacion(
                        id = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_ID)),
                        materiaid = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_MATERIAID)),
                        nombre = c.getString(c.getColumnIndexOrThrow(COLUMN_EVAL_NOMBRE)),
                        porcentaje = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_PORCENTAJE)),
                        notamax = c.getFloat(c.getColumnIndexOrThrow(COLUMN_EVAL_NOTAMAX))
                    )
                }
                out
            }
        }
        fun getByIdEval(id: Int): Evaluacion? = readableDatabase.use { db ->
            db.query(
                TABLE_EVAL_NAME, null,
                "$COLUMN_EVAL_ID = ?", arrayOf(id.toString()),
                null, null, null
            ).use { c ->
                if (!c.moveToFirst()) return@use null
                Evaluacion(
                    id = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_ID)),
                    materiaid = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_MATERIAID)),
                    nombre = c.getString(c.getColumnIndexOrThrow(COLUMN_EVAL_NOMBRE)),
                    porcentaje = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_PORCENTAJE)),
                    notamax = c.getFloat(c.getColumnIndexOrThrow(COLUMN_EVAL_NOTAMAX))
                )
            }
        }
        fun getBymateriaId(materia_id: Int): List<Evaluacion> = readableDatabase.use { db ->
            db.query(
                TABLE_EVAL_NAME, null,
                "$COLUMN_EVAL_MATERIAID = ?", arrayOf(materia_id.toString()),
                null, null, "$COLUMN_EVAL_ID DESC"
            ).use { c ->
                val out = mutableListOf<Evaluacion>()
                while (c.moveToNext()) {
                    out += Evaluacion(
                        id = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_ID)),
                        materiaid = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_MATERIAID)),
                        nombre = c.getString(c.getColumnIndexOrThrow(COLUMN_EVAL_NOMBRE)),
                        porcentaje = c.getInt(c.getColumnIndexOrThrow(COLUMN_EVAL_PORCENTAJE)),
                        notamax = c.getFloat(c.getColumnIndexOrThrow(COLUMN_EVAL_NOTAMAX))
                    )
                }
                out
            }
        }



        fun updateEval(e: Evaluacion): Int = writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(COLUMN_EVAL_MATERIAID, e.materiaid)
                put(COLUMN_EVAL_NOMBRE, e.nombre)
                put(COLUMN_EVAL_PORCENTAJE, e.porcentaje)
                put(COLUMN_EVAL_NOTAMAX, e.notamax)
            }
            db.update(
                TABLE_EVAL_NAME, values,
                "$COLUMN_EVAL_ID = ?", arrayOf(e.id.toString())
            )
        }
        fun deleteEval(id: Int): Int = writableDatabase.use { db ->
            db.delete(
                TABLE_EVAL_NAME,
                "$COLUMN_EVAL_ID = ?", arrayOf(id.toString())
            )
        }

        //  DAO - tabla Materia

        fun insertMateria(m: Materia): Long = writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(COLUMN_MATER_TITULO, m.titulo)
                put(COLUMN_MATER_USAPORCENTAJE, m.usaporcentaje)
            }
            db.insert(TABLE_MATER_NAME, null, values)
        }
        fun getAllMateria(): List<Materia> = readableDatabase.use { db ->
            db.query(
                TABLE_MATER_NAME, null,
                null, null, null, null,
                "$COLUMN_MATER_ID DESC"
            ).use { c ->
                val out = mutableListOf<Materia>()
                while (c.moveToNext()) {
                    out += Materia(
                        id = c.getInt(c.getColumnIndexOrThrow(COLUMN_MATER_ID)),
                        titulo = c.getString(c.getColumnIndexOrThrow(COLUMN_MATER_TITULO)),
                        usaporcentaje = c.getInt(c.getColumnIndexOrThrow(COLUMN_MATER_USAPORCENTAJE)),
                    )
                }
                out
            }
        }
        fun getByIdMateria(id: Int): Materia? = readableDatabase.use { db ->
            db.query(
                TABLE_MATER_NAME, null,
                "$COLUMN_MATER_ID = ?", arrayOf(id.toString()),
                null, null, null
            ).use { c ->
                if (!c.moveToFirst()) return@use null
                Materia(
                    id = c.getInt(c.getColumnIndexOrThrow(COLUMN_MATER_ID)),
                    titulo = c.getString(c.getColumnIndexOrThrow(COLUMN_MATER_TITULO)),
                    usaporcentaje = c.getInt(c.getColumnIndexOrThrow(COLUMN_MATER_USAPORCENTAJE)),
                )
            }
        }
        fun updateMateria(m: Materia): Int = writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(COLUMN_MATER_TITULO, m.titulo)
                put(COLUMN_MATER_USAPORCENTAJE, m.usaporcentaje)
            }
            db.update(
                TABLE_MATER_NAME, values,
                "$COLUMN_MATER_ID = ?", arrayOf(m.id.toString())
            )
        }
        fun deleteMateria(id: Int): Int = writableDatabase.use { db ->
            db.delete(
                TABLE_MATER_NAME,
                "$COLUMN_MATER_ID = ?", arrayOf(id.toString())
            )
        }
        companion object{
            private const val DATABASE_NAME="Evaluaciones.db"
            private const val DATABASE_VERSION=1

            // tabla materia
            private const val TABLE_MATER_NAME="Materia"
            private const val COLUMN_MATER_ID="id"
            private const val COLUMN_MATER_TITULO="titulo"
            private const val COLUMN_MATER_USAPORCENTAJE="usaporcentaje"

            //tabla evaluacion

            private const val TABLE_EVAL_NAME="Evaluacion"
            private const val COLUMN_EVAL_ID="id"
            private const val COLUMN_EVAL_MATERIAID="materiaid"
            private const val COLUMN_EVAL_NOMBRE="nombre"
            private const val COLUMN_EVAL_PORCENTAJE="porcentaje"
            private const val COLUMN_EVAL_NOTAMAX="notamax"

            //tabla notaalumno

            private const val TABLE_NOTAALUMNO_NAME="NotaAlumno"
            private const val COLUMN_NOTAALUMNO_ID="id"
            private const val COLUMN_NOTAALUMNO_EVALUACIONID="evaluacionid"
            private const val COLUMN_NOTAALUMNO_NOTA="nota"

        }
    }