package com.example.myapplication2.ui.nota

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class NotaViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Esta Pagina es para ver las notas"
    }
    val text: LiveData<String> = _text
}