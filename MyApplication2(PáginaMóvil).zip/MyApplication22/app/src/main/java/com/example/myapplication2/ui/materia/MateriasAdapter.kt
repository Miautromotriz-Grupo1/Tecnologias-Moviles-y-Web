package com.example.myapplication2.ui.materia

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.R
import com.example.myapplication2.MateriaConteo

class MateriasAdapter(
    private val onClick: (MateriaConteo) -> Unit,
    private val onEditClick: (MateriaConteo) -> Unit,
    private val onDeleteClick: (MateriaConteo) -> Unit
) : ListAdapter<MateriaConteo, MateriasAdapter.MateriaVH>(MateriaDiffCallback()) {

    inner class MateriaVH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvTitulo: TextView = view.findViewById(R.id.tvTitulo)
        private val tvEvals: TextView = view.findViewById(R.id.tvEvals)
        private val tvModo: TextView = view.findViewById(R.id.tvModo)
        private val editButton: ImageButton = view.findViewById(R.id.button_editar_materia)
        private val deleteButton: ImageButton = view.findViewById(R.id.button_eliminar_materia)

        fun bind(materiaConteo: MateriaConteo) {
            val materia = materiaConteo.materia
            tvTitulo.text = materia.titulo
            tvModo.text = if (materia.usaporcentaje == 1) "Modo: Porcentaje" else "Modo: Promedio"
            tvEvals.text = "Evaluaciones: ${materiaConteo.conteoEvaluaciones}"
            itemView.setOnClickListener { onClick(materiaConteo) }
            editButton.setOnClickListener { onEditClick(materiaConteo) }
            deleteButton.setOnClickListener { onDeleteClick(materiaConteo) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MateriaVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.materia_item_materia, parent, false)
        return MateriaVH(v)
    }

    override fun onBindViewHolder(holder: MateriaVH, position: Int) {
        holder.bind(getItem(position))
    }
}

class MateriaDiffCallback : DiffUtil.ItemCallback<MateriaConteo>() {
    override fun areItemsTheSame(oldItem: MateriaConteo, newItem: MateriaConteo): Boolean {
        return oldItem.materia.id == newItem.materia.id
    }

    override fun areContentsTheSame(oldItem: MateriaConteo, newItem: MateriaConteo): Boolean {
        return oldItem == newItem
    }
}
