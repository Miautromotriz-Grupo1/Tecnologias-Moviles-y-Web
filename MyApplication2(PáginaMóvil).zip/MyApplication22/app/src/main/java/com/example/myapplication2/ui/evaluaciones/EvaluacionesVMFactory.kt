package com.example.myapplication2.ui.evaluaciones

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class EvaluacionesVMFactory(private val repository: EvaluacionesRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EvaluacionesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EvaluacionesViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
