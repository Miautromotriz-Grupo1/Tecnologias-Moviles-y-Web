package com.example.myapplication2.ui.nota.agregar_nota


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.R
import com.example.myapplication2.databinding.FragmentAgregarNotaBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AgregarNotaFragment : Fragment() {
    private var _binding: FragmentAgregarNotaBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val notaViewModel =
            ViewModelProvider(this).get(AgregarNotaViewModel::class.java)

        _binding = FragmentAgregarNotaBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textAgregarNota
        notaViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        val fab:  FloatingActionButton = binding.actionToNota
        fab.setOnClickListener { findNavController().navigate(R.id.navigation_nota) }
        return root
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}