package com.example.myapplication2.ui.materia

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.map
import com.example.myapplication2.MateriaConteo

class MateriaViewModel(private val repo: MateriaRepository) : ViewModel() {
    private val _materias = MutableLiveData<List<MateriaConteo>>(emptyList())
    val materias: LiveData<List<MateriaConteo>> = _materias

    val text: LiveData<String> = materias.map {
        if (it.isEmpty()) {
            "No hay materias ingresadas"
        } else {
            ""
        }
    }

    init {
        cargarMaterias()
    }

    fun cargarMaterias() {
        _materias.value = repo.getAll()
    }

    fun eliminarMateria(materiaConteo: MateriaConteo) {
        repo.delete(materiaConteo.materia.id)
        cargarMaterias()
    }
}