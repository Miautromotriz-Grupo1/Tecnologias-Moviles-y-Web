package com.example.myapplication2.ui.materia.editar_materia

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication2.ui.materia.MateriaRepository

class EditarMateriaVMFactory(private val repository: MateriaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EditarMateriaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EditarMateriaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}