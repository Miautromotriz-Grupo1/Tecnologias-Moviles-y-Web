package com.example.myapplication2.ui.materia

import com.example.myapplication2.DatabaseHelper
import com.example.myapplication2.Materia
import com.example.myapplication2.MateriaConteo

class MateriaRepository(private val db: DatabaseHelper) {

    // Materia
    fun getAll(): List<MateriaConteo> {
        val materias = db.getAllMateria()
        return materias.map { materia ->
            val conteo = db.getBymateriaId(materia.id).size
            MateriaConteo(materia, conteo)
        }
    }
    fun getById(id: Int) = db.getByIdMateria(id)

    fun getAllEval(id: Int) = db.getBymateriaId(id)
    fun insert(m: Materia) = db.insertMateria(m)
    fun update(m: Materia) = db.updateMateria(m)
    fun delete(id: Int) = db.deleteMateria(id)


}