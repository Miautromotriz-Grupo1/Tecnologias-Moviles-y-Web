package com.example.myapplication2.ui.nota.agregar_nota

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AgregarNotaViewModel : ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = "Esta Pagina es para agregar nuevas notas"
    }
    val text: LiveData<String> = _text
}