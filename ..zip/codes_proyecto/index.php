<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIAUtomotriz</title>
    <link rel="stylesheet" href="style01.css">
</head>
<body>
    <header>
        <h1>MIAUtomotriz</h1>
        <button class="login-btn" id="login-btn">Login</button>
        <button class="login-btn" id="register-btn" style="left: 10rem;">Registrarse</button>
        <button id="toggle-theme">Modo oscuro</button>
        <!-- Ilustración de gato en el header -->
        <img style="fill: #ffffff;" src="media/logo-miautomotriz.svg" alt="Logo MIAU-tomotriz" class="cat-illustration">
    </header>
    <nav>
        <a href="index.php">Inicio</a>
        <a href="#productos-container" class="nav-link" onclick="smoothScroll(event)">Productos</a>
        <a href="contacto.php" id="nav-contacto">Contacto</a>
    </nav>
    <main>
        <h2>Productos Destacados</h2>

        <!-- Contenedor vacío: los productos se cargarán desde js/json/productos.json -->
        <div class="productos" id="productos-container">
            <!-- renderProductos() llenará este contenedor -->
        </div>
    </main>

    <!-- Botón flotante del carrito -->
    <button id="floating-cart" type="button" title="Abrir carrito" aria-label="Abrir carrito">🛒</button>

    <!-- Modal de login -->
    <div class="login-modal" id="login-modal">
        <div class="login-box">
            <button class="close-modal" id="close-login">&times;</button>
            <h2>Iniciar Sesión</h2>
            <input type="text" placeholder="Usuario" id="login-usuario">
            <input type="password" placeholder="Contraseña" id="login-password">
            <button id="login-submit">Entrar</button>
        </div>
    </div>
    <!-- Modal de registro -->
    <div class="login-modal" id="register-modal">
        <div class="login-box">
            <button class="close-modal" id="close-register">&times;</button>
            <h2>Registrarse</h2>
            <input type="text" placeholder="Nombre de usuario" id="register-usuario" required>
            <input type="email" placeholder="Correo electrónico" id="register-email" required>
            <input type="password" placeholder="Contraseña" id="register-password" required>
            <button id="register-submit">Registrar</button>
        </div>
    </div>
    <!-- Sección de comentarios -->
    <section class="comentarios-section">
        <h3>Deja tu comentario sobre la página</h3>
        <form id="comentario-form">
            <textarea id="comentario-text" placeholder="Escribe tu comentario aquí..." required></textarea>
            <button type="submit">Enviar comentario</button>
        </form>
        <div class="comentarios-list" id="comentarios-list">
            <!-- Comentarios aparecerán aquí -->
        </div>
    </section>
    <!-- Sidebar del carrito -->
    <div id="carrito-sidebar" style="display:none; position:fixed; top:0; right:0; width:350px; height:100vh; background:#fff; box-shadow:-2px 0 10px rgba(0,0,0,0.2); z-index:2000; padding:2rem 1rem 1rem 1rem; overflow-y:auto;">
        <button id="cerrar-carrito" style="position:absolute; top:1rem; right:1rem; background:none; border:none; font-size:1.5rem; cursor:pointer;">&times;</button>
        <h2>Carrito</h2>
        <div id="carrito-lista"></div>
        <div id="carrito-total" style="margin-top:1rem; font-weight:bold;"></div>
    </div>
    <footer>
        &copy; 2025 MIAUtomotris Online. Todos los derechos reservados. ulagos.cl
    </footer>

    <!-- Vincular script externo (ruta al archivo js donde están las funciones) -->
    <script src="js/script01.js"></script>

    <!-- Llamada para inicializar datos y renderizar productos -->
    <script>
    // inicializa datos y renderiza productos/comentarios cuando script01.js esté cargado
    (async function(){
        try {
            if (typeof initData === 'function') {
                await initData();
            }
            if (typeof renderProductos === 'function') {
                await renderProductos();
            }
            if (typeof renderComentarios === 'function') {
                renderComentarios();
            }
        } catch (e) {
            console.error('Inicialización client-side:', e);
        }
    })();

    
    function smoothScroll(event) {
        const link = event.currentTarget || event.target;
        const href = link.getAttribute('href') || '';
        // sólo interceptar anclas locales que empiezan por '#'
        if (!href.startsWith('#')) return; // dejar que enlaces normales (ej. contacto.php) funcionen
        event.preventDefault(); // sólo para anclas
        const targetId = href.substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    // abrir sidebar del carrito al hacer clic en el nav 'Carrito'
    (function(){
        const navCarrito = document.getElementById('nav-carrito');
        if (!navCarrito) return;
        navCarrito.addEventListener('click', function(e){
            e.preventDefault();
            // si la función mostrarCarritoSidebar está definida en script01.js la usamos
            if (typeof mostrarCarritoSidebar === 'function') {
                mostrarCarritoSidebar();
            } else {
                // fallback: mostrar el sidebar directamente
                const sidebar = document.getElementById('carrito-sidebar');
                if (sidebar) sidebar.style.display = 'block';
            }
        });
    })();
    </script>
</body>
</html>