// filepath: c:\xampp\htdocs\Clases-web-2025\codes_proyecto\js\script01.js
// Estado de login (usar var para exponer en window y que otras páginas vean isLoggedIn/isAdmin)
var isLoggedIn = false;
var isAdmin = false;

// Tema claro/oscuro o verde
const btn = document.getElementById('toggle-theme');
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const loginModal = document.getElementById('login-modal');
const closeLogin = document.getElementById('close-login');
const loginSubmit = document.getElementById('login-submit');
const loginUsuario = document.getElementById('login-usuario');
const loginPassword = document.getElementById('login-password');

// Registro
const registerModal = document.getElementById('register-modal');
const closeRegister = document.getElementById('close-register');
const registerSubmit = document.getElementById('register-submit');
const registerUsuario = document.getElementById('register-usuario');
const registerEmail = document.getElementById('register-email');
const registerPassword = document.getElementById('register-password');

// "Base de datos" de usuarios en localStorage
function getUsuarios() {
    return JSON.parse(localStorage.getItem('usuarios') || '[]');
}
function saveUsuario(usuario, email, password) {
    const usuarios = getUsuarios();
    usuarios.push({ usuario, email, password });
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}
function findUsuario(usuario, password) {
    const usuarios = getUsuarios();
    return usuarios.find(u => u.usuario === usuario && u.password === password);
}
function usuarioExiste(usuario) {
    const usuarios = getUsuarios();
    return usuarios.some(u => u.usuario === usuario);
}

// Productos en localStorage para edición y gestión
function getProductos() {
    return JSON.parse(localStorage.getItem('productos') || '[]');
}
function saveProductos(productos) {
    localStorage.setItem('productos', JSON.stringify(productos));
}

// Inicializar productos si no existen
// Cargar datos iniciales desde archivos JSON (si no hay datos en localStorage)
async function initData() {
    try {
        if (!localStorage.getItem('productos')) {
            const r = await fetch('json/productos.json');
            if (r.ok) {
                const prods = await r.json();
                saveProductos(prods);
            } else {
                console.error('No se pudo cargar productos.json', r.status);
            }
        }
        if (!localStorage.getItem('usuarios')) {
            const r = await fetch('json/usuarios.json');
            if (r.ok) {
                const us = await r.json();
                localStorage.setItem('usuarios', JSON.stringify(us));
            } else {
                console.error('No se pudo cargar usuarios.json', r.status);
            }
        }
        if (!localStorage.getItem('comentarios')) {
            const r = await fetch('json/comentarios.json');
            if (r.ok) {
                const comm = await r.json();
                localStorage.setItem('comentarios', JSON.stringify(comm));
            } else {
                console.error('No se pudo cargar comentarios.json', r.status);
            }
        }
    } catch (err) {
        console.error('initData error', err);
    }
}

// nueva función: obtiene productos desde el archivo JSON
async function fetchProductosFromFile() {
    try {
        // ruta relativa desde este archivo (js/) a js/json/productos.json => 'json/productos.json'
        const res = await fetch('json/productos.json', {cache: "no-store"});
        if (!res.ok) throw new Error('Fetch productos.json error ' + res.status);
        const prods = await res.json();
        return Array.isArray(prods) ? prods : [];
    } catch (err) {
        console.error('fetchProductosFromFile', err);
        return [];
    }
}

// renderProductos ahora intenta cargar primero desde localStorage,
// si no hay productos carga directamente desde productos.json
async function renderProductos() {
    const productosDiv = document.querySelector('.productos');
    if (!productosDiv) return;
    productosDiv.innerHTML = '';

    let productos = getProductos(); // desde localStorage
    if (!productos || productos.length === 0) {
        // si no hay en localStorage, intentar desde el archivo JSON
        productos = await fetchProductosFromFile();
        if (productos.length > 0) saveProductos(productos); // opcional: guarda en localStorage
    }

    productos.forEach((prod, idx) => {
        const div = document.createElement('div');
        div.className = 'producto';
        div.innerHTML = `
            <img src="${prod.img}" alt="${prod.nombre}">
            <h3 contenteditable="${isLoggedIn}">${prod.nombre}</h3>
            <p contenteditable="${isLoggedIn}">$${prod.precio} c/u</p>
            <button>Agregar al carrito</button>
            ${isLoggedIn ? `
                <button style="background:#ffc107;color:#333;margin-top:0.5rem;" class="editar-btn" data-idx="${idx}">Editar</button>
                <button style="background:#dc3545;color:#fff;margin-top:0.5rem;" class="borrar-btn" data-idx="${idx}">Borrar</button>
            ` : ''}
        `;
        productosDiv.appendChild(div);
    });

    // Asignar eventos a los botones de productos
    productosDiv.querySelectorAll('.producto button:not(.editar-btn):not(.borrar-btn)').forEach((btn, idx) => {
        btn.onclick = function() {
            const productos = getProductos();
            agregarAlCarrito(productos[idx]);
        };
    });

    // Editar producto
    productosDiv.querySelectorAll('.editar-btn').forEach(btn => {
        btn.onclick = function() {
            const idx = parseInt(btn.getAttribute('data-idx'));
            const prodDiv = btn.parentElement;
            const nombreEl = prodDiv.querySelector('h3');
            const precioEl = prodDiv.querySelector('p');
            nombreEl.contentEditable = true;
            precioEl.contentEditable = true;
            nombreEl.focus();
            btn.textContent = 'Guardar';
            btn.onclick = function() {
                const productos = getProductos();
                productos[idx].nombre = nombreEl.textContent.trim();
                productos[idx].precio = parseInt(precioEl.textContent.replace(/[^0-9]/g, '')) || 0;
                saveProductos(productos);
                renderProductos(); // ya es async pero se puede llamar sin await
            };
        };
    });

    // Borrar producto
    productosDiv.querySelectorAll('.borrar-btn').forEach(btn => {
        btn.onclick = function() {
            const idx = parseInt(btn.getAttribute('data-idx'));
            const productos = getProductos();
            productos.splice(idx, 1);
            saveProductos(productos);
            renderProductos();
        };
    });
}

btn.addEventListener('click', function() {
    if (isLoggedIn) {
        document.body.classList.toggle('dark-green');
        if(document.body.classList.contains('dark-green')) {
            btn.textContent = 'Modo verde menta';
        } else {
            btn.textContent = 'Modo verde bosque';
        }
    } else {
        document.body.classList.toggle('dark-mode');
        if(document.body.classList.contains('dark-mode')) {
            btn.textContent = 'Modo claro';
        } else {
            btn.textContent = 'Modo oscuro';
        }
    }
});

// Modal login
loginBtn.addEventListener('click', () => {
    if (!isLoggedIn) {
        loginModal.classList.add('active');
    } else {
        isLoggedIn = false;
        isAdmin = false;
        document.body.classList.remove('green-mode', 'dark-green');
        document.body.classList.remove('dark-mode');
        btn.textContent = 'Modo oscuro';
        loginBtn.textContent = 'Login';
        renderProductos().then(()=> renderComentarios()).catch(console.error);
    }
});
closeLogin.addEventListener('click', () => {
    loginModal.classList.remove('active');
});
window.addEventListener('click', (e) => {
    if(e.target === loginModal) loginModal.classList.remove('active');
    if(e.target === registerModal) registerModal.classList.remove('active');
});

// Modal registro
registerBtn.addEventListener('click', () => {
    registerModal.classList.add('active');
});
closeRegister.addEventListener('click', () => {
    registerModal.classList.remove('active');
});

// Registro
registerSubmit.addEventListener('click', function() {
    const usuario = registerUsuario.value.trim();
    const email = registerEmail.value.trim();
    const password = registerPassword.value;
    // Solicita clave de admin
    let claveAdmin = prompt('Si deseas crear una cuenta de administrador, ingresa la clave de seguridad. Si no, deja vacío y presiona aceptar.');
    let esAdmin = false;
    if (claveAdmin && claveAdmin === "miau2025") {
        esAdmin = true;
    } else if (claveAdmin && claveAdmin !== "miau2025") {
        alert('Clave de seguridad incorrecta. Solo puedes crear cuentas de usuario normales.');
        claveAdmin = '';
    }
    if (!usuario || !email || !password) {
        alert('Completa todos los campos.');
        return;
    }
    if (usuarioExiste(usuario)) {
        alert('El usuario ya existe.');
        return;
    }
    // Guarda el tipo de usuario
    const usuarios = getUsuarios();
    usuarios.push({ usuario, email, password, admin: esAdmin });
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    alert('Registro exitoso. Ahora puedes iniciar sesión.');
    registerModal.classList.remove('active');
    registerUsuario.value = '';
    registerEmail.value = '';
    registerPassword.value = '';
});

// Modifica findUsuario para guardar si es admin
function findUsuario(usuario, password) {
    const usuarios = getUsuarios();
    return usuarios.find(u => u.usuario === usuario && u.password === password);
}

// Modifica el login para activar modo admin si corresponde
loginSubmit.addEventListener('click', function() {
    const usuario = loginUsuario.value.trim();
    const password = loginPassword.value;
    const user = findUsuario(usuario, password);
    if(user) {
        isLoggedIn = true;
        isAdmin = !!user.admin;
        document.body.classList.remove('dark-mode');
        document.body.classList.add('green-mode');
        document.body.classList.remove('dark-green');
        btn.textContent = 'Modo verde bosque';
        loginBtn.textContent = 'Cerrar sesión';
        loginModal.classList.remove('active');
        loginUsuario.value = '';
        loginPassword.value = '';
        renderProductos().then(()=> renderComentarios()).catch(console.error);
    } else {
        alert('Usuario o contraseña incorrectos.');
    }
});

// Comentarios en localStorage como "json"
function getComentarios() {
    return JSON.parse(localStorage.getItem('comentarios') || '[]');
}
function saveComentarios(comentarios) {
    localStorage.setItem('comentarios', JSON.stringify(comentarios));
}

// Guardar comentario con fecha y hora
const comentarioForm = document.getElementById('comentario-form');
const comentarioText = document.getElementById('comentario-text');
const comentariosList = document.getElementById('comentarios-list');

// Permitir agregar comentarios solo si NO está logeado como admin
comentarioForm.addEventListener('submit', function(e) {
    e.preventDefault();
    if (isLoggedIn) {
        alert('El administrador no puede agregar comentarios.');
        return;
    }
    const texto = comentarioText.value.trim();
    if(texto) {
        const ahora = new Date();
        const fecha = ahora.toLocaleDateString();
        const hora = ahora.toLocaleTimeString();
        const comentario = {
            texto,
            fecha,
            hora
        };
        const comentarios = getComentarios();
        comentarios.unshift(comentario);
        saveComentarios(comentarios);
        comentarioText.value = '';
        renderComentarios();
    }
});

// Mostrar comentarios: solo ver si logeado/admin, solo agregar si usuario no logeado
function renderComentarios() {
    const comentariosList = document.getElementById('comentarios-list');
    const comentarioForm = document.getElementById('comentario-form');
    comentariosList.innerHTML = '';
    if (isLoggedIn) {
        comentarioForm.style.display = 'none'; // Oculta el formulario para admin/logeado
        const comentarios = getComentarios();
        if (comentarios.length === 0) {
            comentariosList.innerHTML = '<div class="comentario">No hay comentarios aún.</div>';
        } else {
            comentarios.forEach(com => {
                const div = document.createElement('div');
                div.className = 'comentario';
                div.innerHTML = `<strong>${com.fecha} ${com.hora}</strong><br>${com.texto}`;
                comentariosList.appendChild(div);
            });
        }
    } else {
        comentarioForm.style.display = 'block'; // Muestra el formulario para usuarios no logeados
        comentariosList.innerHTML = ''; // Oculta los comentarios si no está logeado
    }
}

// Llama a renderComentarios al cargar y al logearse/cerrar sesión
renderComentarios();
loginBtn.addEventListener('click', () => {
    if (!isLoggedIn) {
        loginModal.classList.add('active');
    } else {
        isLoggedIn = false;
        isAdmin = false;
        document.body.classList.remove('green-mode', 'dark-green');
        document.body.classList.remove('dark-mode');
        btn.textContent = 'Modo oscuro';
        loginBtn.textContent = 'Login';
        renderProductos().then(()=> renderComentarios()).catch(console.error);
    }
});

// Carrito
function getCarrito() {
    return JSON.parse(localStorage.getItem('carrito') || '[]');
}
function saveCarrito(carrito) {
    localStorage.setItem('carrito', JSON.stringify(carrito));
}
function agregarAlCarrito(producto) {
    const carrito = getCarrito();
    const existente = carrito.find(p => p.nombre === producto.nombre);
    if (existente) {
        existente.cantidad += 1;
    } else {
        carrito.push({ ...producto, cantidad: 1 });
    }
    saveCarrito(carrito);
    mostrarCarritoSidebar();
}
function mostrarCarritoSidebar() {
    const sidebar = document.getElementById('carrito-sidebar');
    const lista = document.getElementById('carrito-lista');
    const totalDiv = document.getElementById('carrito-total');
    const carrito = getCarrito();
    lista.innerHTML = '';
    let total = 0;
    carrito.forEach((item, idx) => {
        const div = document.createElement('div');
        div.style.marginBottom = '1rem';
        div.innerHTML = `
            <strong>${item.nombre}</strong> x${item.cantidad}<br>
            $${item.precio * item.cantidad}
            <button style="margin-left:10px;background:#dc3545;color:#fff;border:none;padding:0.2rem 0.7rem;border-radius:3px;cursor:pointer;" data-idx="${idx}">Eliminar</button>
        `;
        lista.appendChild(div);
        total += item.precio * item.cantidad;
    });

    // Botón para borrar todo
    if (carrito.length > 0) {
        const borrarTodoBtn = document.createElement('button');
        borrarTodoBtn.textContent = 'Vaciar carrito';
        borrarTodoBtn.style = 'background:#dc3545;color:#fff;border:none;padding:0.5rem 1rem;border-radius:4px;cursor:pointer;margin-top:1rem;';
        borrarTodoBtn.onclick = function() {
            saveCarrito([]);
            mostrarCarritoSidebar();
        };
        lista.appendChild(borrarTodoBtn);
    }

    totalDiv.textContent = 'Total: $' + total;
    sidebar.style.display = 'block';

    // ocultar botón flotante cuando el sidebar está abierto
    const floatBtn = document.getElementById('floating-cart');
    if (floatBtn) floatBtn.style.display = 'none';

    // Botones eliminar de uno en uno
    lista.querySelectorAll('button[data-idx]').forEach(btn => {
        btn.onclick = function() {
            const idx = parseInt(btn.getAttribute('data-idx'));
            let carrito = getCarrito();
            if (carrito[idx].cantidad > 1) {
                carrito[idx].cantidad -= 1;
            } else {
                carrito.splice(idx, 1);
            }
            saveCarrito(carrito);
            mostrarCarritoSidebar();
        };
    });
}

// cerrar carrito: mostrar botón flotante al cerrar
document.getElementById('cerrar-carrito').onclick = function() {
    document.getElementById('carrito-sidebar').style.display = 'none';
    const floatBtn = document.getElementById('floating-cart');
    if (floatBtn) floatBtn.style.display = '';
};

// botón flotante abre el sidebar
const floatingCartBtn = document.getElementById('floating-cart');
if (floatingCartBtn) {
    floatingCartBtn.addEventListener('click', function(e){
        e.preventDefault();
        if (typeof mostrarCarritoSidebar === 'function') {
            mostrarCarritoSidebar();
        } else {
            const sidebar = document.getElementById('carrito-sidebar');
            if (sidebar) sidebar.style.display = 'block';
            floatingCartBtn.style.display = 'none';
        }
    });
}