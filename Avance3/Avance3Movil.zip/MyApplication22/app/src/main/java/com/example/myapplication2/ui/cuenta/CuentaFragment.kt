package com.example.myapplication2.ui.cuenta

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication2.Constants
import com.example.myapplication2.LoginActivity
import com.example.myapplication2.R
import com.example.myapplication2.databinding.FragmentCuentaBinding
import org.json.JSONObject

class CuentaFragment : Fragment() {

    private var _binding: FragmentCuentaBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCuentaBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // 1. Obtener SharedPreferences
        val sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val rutUsuario = sharedPreferences.getString("user_rut", "")

        // 2. Configurar Switch de Modo Oscuro
        val currentNightMode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
        val isSystemDark = currentNightMode == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val isDarkMode = if (sharedPreferences.contains("dark_mode")) {
            sharedPreferences.getBoolean("dark_mode", false)
        } else {
            isSystemDark
        }

        binding.switchDarkMode.isChecked = isDarkMode

        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("dark_mode", isChecked).apply()
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        // 3. Cargar Datos del Usuario desde la API
        if (!rutUsuario.isNullOrEmpty()) {
            binding.etRut.setText(rutUsuario)
            cargarDatosUsuario(rutUsuario)
        } else {
            binding.etNombre.setText("Usuario no identificado")
        }

        // 4. Configurar Botón Cerrar Sesión
        binding.btnLogout.setOnClickListener {
            cerrarSesion(sharedPreferences)
        }

        // 5. Configurar Botón Actualizar (Nuevo)
        binding.btnActualizar.setOnClickListener {
            val bundle = Bundle().apply {
                putString("rut", binding.etRut.text.toString())
                putString("nombre", binding.etNombre.text.toString())
                putString("apellido", binding.etApellido.text.toString())
                putString("correo", binding.etCorreo.text.toString())
                putString("telefono", binding.etTelefono.text.toString())
                putString("direccion", binding.etDireccionid.text.toString())
                // Nuevos campos
                putString("fecha_nacimiento", binding.etFechaNacimiento.text.toString())
                putString("prevision", binding.etPrevision.text.toString())
                putString("giro", binding.etGiro.text.toString())
                putString("rol", binding.etRol.text.toString())
            }
            findNavController().navigate(R.id.action_cuenta_to_editar, bundle)
        }

        return root
    }

    private fun cargarDatosUsuario(rut: String) {
        val context = context ?: return
        val queue = Volley.newRequestQueue(context)
        val url = Constants.GET_USER_URL

        val params = JSONObject()
        params.put("rut", rut)

        val jsonObjectRequest = JsonObjectRequest(Request.Method.POST, url, params,
            { response ->
                if (_binding == null) return@JsonObjectRequest
                try {
                    val status = response.optString("status")
                    if (status == "success" || response.has("nombre")) {
                        binding.etNombre.setText(response.optString("nombre", "N/D"))
                        binding.etApellido.setText(response.optString("apellido", "N/D"))
                        binding.etCorreo.setText(response.optString("correo", "N/D"))
                        binding.etTelefono.setText(response.optString("telefono", "N/D"))
                        binding.etDireccionid.setText(response.optString("direccion", "N/D"))
                        binding.etFechaNacimiento.setText(response.optString("fecha_nacimiento", "N/D"))
                        binding.etPrevision.setText(response.optString("prevision", "N/D"))
                        binding.etGiro.setText(response.optString("giro", "N/D"))
                        binding.etRol.setText(response.optString("rol", "N/D"))
                        binding.tvBadgeRol.text = response.optString("empleado", "N/D")
                    } else {
                        Toast.makeText(context, "No se encontraron datos del usuario", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            { error ->
                if (_binding != null) {
                    Toast.makeText(context, "Error al cargar perfil", Toast.LENGTH_SHORT).show()
                }
            }
        )

        queue.add(jsonObjectRequest)
    }

    private fun cerrarSesion(sharedPreferences: SharedPreferences) {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()

        val intent = Intent(requireContext(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}