package com.example.myapplication2.ui.productos

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import org.json.JSONException

class ProductosViewModel : ViewModel() {

    private val _productos = MutableLiveData<List<Producto>>()
    val productos: LiveData<List<Producto>> = _productos

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun cargarProductos(context: Context) {
        _isLoading.value = true
        val url = Constants.GET_PRODUCTS_URL

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                _isLoading.value = false
                val listaProductos = mutableListOf<Producto>()
                try {
                    for (i in 0 until response.length()) {
                        val jsonObject = response.getJSONObject(i)
                        
                        val id = jsonObject.optInt("id", 0)
                        val nombre = jsonObject.optString("nombre", "Sin nombre")
                        val marca = jsonObject.optString("marca", "Sin marca")
                        val precio = jsonObject.optInt("precio", 0)
                        val anio = jsonObject.optString("anio", "")
                        
                        // Lógica para procesar la URL de la imagen
                        val imgRaw = jsonObject.optString("img", "")
                        var imgFinal: String? = null
                        
                        if (imgRaw.isNotEmpty() && imgRaw != "null") {
                            if (imgRaw.startsWith("media/")) {
                                imgFinal = "https://proyecto.jakrarish.net/pagina/v4/" + imgRaw
                            } else {
                                imgFinal = imgRaw
                            }
                        }
                        
                        listaProductos.add(Producto(id, nombre, marca, precio, anio, imgFinal))
                    }
                    _productos.value = listaProductos
                } catch (e: JSONException) {
                    _error.value = "Error al procesar datos: ${e.message}"
                }
            },
            { error ->
                _isLoading.value = false
                _error.value = "Error de conexión: ${error.message}"
            }
        )

        VolleySingleton.getInstance(context).addToRequestQueue(jsonArrayRequest)
    }
}
