package com.example.myapplication2.ui.cuenta

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import com.example.myapplication2.databinding.FragmentEditarCuentaBinding
import org.json.JSONObject

class EditarCuentaFragment : Fragment() {

    private var _binding: FragmentEditarCuentaBinding? = null
    private val binding get() = _binding!!
    private var userRut: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarCuentaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1. Recuperar los datos pasados desde CuentaFragment
        arguments?.let {
            userRut = it.getString("rut", "")
            binding.etNombre.setText(it.getString("nombre", ""))
            binding.etApellido.setText(it.getString("apellido", ""))
            binding.etCorreo.setText(it.getString("correo", ""))
            binding.etTelefono.setText(it.getString("telefono", ""))
            binding.etDireccion.setText(it.getString("direccion", ""))
            
            // Nuevos campos recuperados
            binding.etFechaNacimiento.setText(it.getString("fecha_nacimiento", ""))
            binding.etPrevision.setText(it.getString("prevision", ""))
            binding.etGiro.setText(it.getString("giro", ""))
            binding.etRol.setText(it.getString("rol", ""))
        }

        // 2. Configurar botón Guardar
        binding.btnGuardarCambios.setOnClickListener {
            guardarCambios()
        }

        // 3. Configurar botón Cancelar
        binding.btnCancelar.setOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun guardarCambios() {
        val url = Constants.BASE_URL + "actualizar_cuenta.php"

        val jsonBody = JSONObject().apply {
            put("rut", userRut)
            put("nombre", binding.etNombre.text.toString())
            put("apellido", binding.etApellido.text.toString())
            // Correo no editable, pero se envía si el PHP lo requiere
            put("correo", binding.etCorreo.text.toString())
            put("telefono", binding.etTelefono.text.toString())
            put("direccion", binding.etDireccion.text.toString())
            
            // Nuevos campos a actualizar
            put("fechanacimiento", binding.etFechaNacimiento.text.toString())
            put("prevision", binding.etPrevision.text.toString())
            put("giro", binding.etGiro.text.toString())
            put("rol", binding.etRol.text.toString())
        }

        val request = JsonObjectRequest(
            Request.Method.POST, url, jsonBody,
            { response ->
                val status = response.optString("status")
                val message = response.optString("message")

                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

                if (status == "success") {
                    // Volver atrás para ver los cambios
                    findNavController().navigateUp()
                }
            },
            { error ->
                Toast.makeText(context, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )

        VolleySingleton.getInstance(requireContext()).addToRequestQueue(request)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}