package com.example.myapplication2.ui.reparaciones

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.Reparacion
import com.example.myapplication2.VolleySingleton
import org.json.JSONException

class ReparacionesViewModel : ViewModel() {

    private val _reparaciones = MutableLiveData<List<Reparacion>>()
    val reparaciones: LiveData<List<Reparacion>> = _reparaciones

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun cargarReparaciones(context: Context) {
        val url = Constants.GET_REPARACIONES_URL

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                val listaReparaciones = mutableListOf<Reparacion>()
                try {
                    for (i in 0 until response.length()) {
                        val jsonObject = response.getJSONObject(i)
                        val id = jsonObject.getInt("id")
                        val descripcion = jsonObject.getString("descripcion")
                        val fecha = jsonObject.getString("fecha")
                        val costo = jsonObject.getDouble("costo")
                        val estado = jsonObject.getString("estado")
                        
                        listaReparaciones.add(Reparacion(id, descripcion, fecha, costo, estado))
                    }
                    _reparaciones.value = listaReparaciones
                } catch (e: JSONException) {
                    _error.value = "Error al procesar datos: ${e.message}"
                }
            },
            { error ->
                _error.value = "Error de conexión: ${error.message}"
            }
        )

        VolleySingleton.getInstance(context).addToRequestQueue(jsonArrayRequest)
    }
}
