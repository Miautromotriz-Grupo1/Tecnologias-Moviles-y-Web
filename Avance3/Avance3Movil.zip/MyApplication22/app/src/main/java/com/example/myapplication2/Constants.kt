package com.example.myapplication2

object Constants {
    // API en servidor remoto
    const val BASE_URL = "https://proyecto.jakrarish.net/api/" 
    const val GET_REPARACIONES_URL = BASE_URL + "reparaciones.php"
    const val POST_REPARACION_URL = BASE_URL + "crear_reparacion.php"
    const val LOGIN_URL = BASE_URL + "login.php"
    const val REGISTER_URL = BASE_URL + "register.php"
    const val RECOVERY_URL = BASE_URL + "recuperar.php"
    const val GET_USER_URL = BASE_URL + "obtener_usuario.php"
    const val GET_PRODUCTS_URL = BASE_URL + "obtener_productos.php"
}
