package com.example.myapplication2.ui.productos

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.databinding.FragmentProductosBinding

class ProductosFragment : Fragment() {

    private var _binding: FragmentProductosBinding? = null
    private val binding get() = _binding!!

    private lateinit var productosViewModel: ProductosViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProductosBinding.inflate(inflater, container, false)
        val root: View = binding.root

        productosViewModel = ViewModelProvider(this).get(ProductosViewModel::class.java)

        val sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)

        // Leer nivel de empleado (0=Cliente, 1=Empleado, 2=Admin)
        // Por defecto 0 si no existe
        val empleadoLevel = sharedPreferences.getInt("user_empleado_level", 0)
        
        // DEBUG: Mostrar mensaje temporal para verificar el nivel
        // Mostrar botón solo si es Empleado (1) o Administrador (2)
        if (empleadoLevel == 1 || empleadoLevel == 2) {
            binding.actionToAgregarProducto.visibility = View.VISIBLE
        } else {
            binding.actionToAgregarProducto.visibility = View.GONE
        }

        // 3. Configurar RecyclerView
        val adapter = ProductosAdapter()
        binding.recyclerProductos.layoutManager = LinearLayoutManager(context)
        binding.recyclerProductos.adapter = adapter

        // 4. Observar los datos y actualizar el adaptador
        productosViewModel.productos.observe(viewLifecycleOwner) { productos ->
            adapter.submitList(productos)
        }

        // 5. Cargar los datos desde la API
        productosViewModel.cargarProductos(requireContext())

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
