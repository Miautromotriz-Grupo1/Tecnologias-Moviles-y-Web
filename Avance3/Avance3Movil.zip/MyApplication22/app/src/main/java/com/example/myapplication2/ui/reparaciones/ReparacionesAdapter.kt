package com.example.myapplication2.ui.reparaciones

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.Reparacion
import com.example.myapplication2.databinding.ItemReparacionBinding

class ReparacionesAdapter : ListAdapter<Reparacion, ReparacionesAdapter.ReparacionViewHolder>(ReparacionDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReparacionViewHolder {
        val binding = ItemReparacionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ReparacionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReparacionViewHolder, position: Int) {
        val reparacion = getItem(position)
        holder.bind(reparacion)
    }

    class ReparacionViewHolder(private val binding: ItemReparacionBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(reparacion: Reparacion) {
            binding.textDescripcion.text = reparacion.descripcion
            binding.textFecha.text = reparacion.fecha
            binding.textEstado.text = reparacion.estado
            binding.textCosto.text = "$${reparacion.costo}"
        }
    }

    class ReparacionDiffCallback : DiffUtil.ItemCallback<Reparacion>() {
        override fun areItemsTheSame(oldItem: Reparacion, newItem: Reparacion): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Reparacion, newItem: Reparacion): Boolean {
            return oldItem == newItem
        }
    }
}
