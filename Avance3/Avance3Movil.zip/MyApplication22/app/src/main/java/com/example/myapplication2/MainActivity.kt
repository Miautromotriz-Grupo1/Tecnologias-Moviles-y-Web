package com.example.myapplication2

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
        val navController = navHost.navController

        // Configuración de los destinos principales (Top Level)
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_productos,
                R.id.navigation_cuenta,      // Nuevo destino: Cuenta
                R.id.navigation_reparaciones
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        val bottom: BottomNavigationView = binding.navView
        bottom.setupWithNavController(navController)

        // Listener para resaltar el ícono correcto en el BottomNavigation
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {

                R.id.navigation_productos -> {
                    bottom.menu.findItem(R.id.navigation_productos)?.isChecked = true
                }

                R.id.navigation_cuenta -> {
                    bottom.menu.findItem(R.id.navigation_cuenta)?.isChecked = true
                }

                R.id.navigation_reparaciones -> {
                    bottom.menu.findItem(R.id.navigation_reparaciones)?.isChecked = true
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
        return navHost.navController.navigateUp() || super.onSupportNavigateUp()
    }
}