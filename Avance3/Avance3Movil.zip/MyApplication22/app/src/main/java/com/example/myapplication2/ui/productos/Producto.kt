package com.example.myapplication2.ui.productos

data class Producto(
    val id: Int,
    val nombre: String,
    val marca: String,
    val precio: Int,
    val anio: String,
    val imagenUrl: String? // Nuevo campo para la imagen (puede ser nulo si no tiene)
)
