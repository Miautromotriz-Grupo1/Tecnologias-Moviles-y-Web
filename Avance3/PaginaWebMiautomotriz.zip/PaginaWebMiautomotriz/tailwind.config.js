/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './*.{php,html,js}',
    './js/*.js',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}