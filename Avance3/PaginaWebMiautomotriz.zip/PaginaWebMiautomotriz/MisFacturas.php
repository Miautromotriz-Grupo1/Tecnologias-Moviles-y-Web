<?php 


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 


?>
    <main>
        <style>
        @media print {
            .no-print {
            display: none !important;
            }
        }
        </style>
        <section class="max-w-4xl mx-auto my-8 px-4">

            <!-- Barra de busqueda -->

            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="bg-skin-card inline-flex items-center border border-skin-border rounded-2xl shadow-2xl px-3 py-2  rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 svg-text-main" viewBox="0 0 20 20" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <form method="get" class="flex items-center gap-2 w-full md:w-auto">
                    <label for="buscar" class="font-semibold text-skin-muted mr-2">Buscar:</label>
                    <input id="buscar" class="w-full md:w-80 text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border rounded-2xl shadow-2xl focus:outline-none focus:ring-2 focus:ring-sky-300" name="q"  type="text" placeholder="Escribe para filtrar por N° factura o nombre" value="<?php echo isset($_GET['q'])?htmlspecialchars($_GET['q'],ENT_QUOTES):''; ?>"  />

                    <button type="submit" id="btn-buscar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md " title="Buscar">
                        <span alt="Buscar" class="svg-text-main block w-5 h-5">
                            <?php include 'media/lupa.svg'; ?>
                        </span>
                    </button>
                        <a href="usuarios.php" id="btn-cancelar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md hover:shadow-sm inline-flex items-center" title="Limpiar búsqueda">
                            <span class="svg-text-main block w-5 h-5">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                            </span>
                        </a>
                </form>

                <div class="mt-3 md:mt-0 md:ml-auto">
                    <button id="btn-crear-fac" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow no-print">Crear Factura</button>
                </div>
            </div>

            <!-- Tabla de facturas -->
            <div class="overflow-x-auto bg-white rounded-md shadow">
                <table class="min-w-full divide-y divide-gray-200" aria-describedby="listado-facturas">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3">N° Factura</th>
                            <th class="px-4 py-3">Cliente</th>
                            <th class="px-4 py-3">Fecha Emisión</th>
                            <th class="px-4 py-3">Total</th>
                            <th class="px-4 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="listado-facturas" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <!-- Facturas cargadas dinámicamente -->
                    </tbody>
                </table>
            </div>

        </section>
    </main>
<!-- Vincular scripts externos: primero script.js (globals y UI general), luego producto.js (render productos) -->

    <!-- Modal / Plantilla de factura (mejorado) -->
    <style>
        /* Print: show only the printable invoice block */
        @media print {
            body * { visibility: hidden !important; }
            #factura-printable, #factura-printable * { visibility: visible !important; }
            #factura-printable { position: absolute; left: 0; top: 0; width: 100%; }
            /* hide interactive controls when printing */
            #fac-add-item, #btn-imprimir-fac, #btn-cerrar-fac { display: none !important; }
            /* force vehicle and para side-by-side in print */
            #factura-printable .vehicle-para-grid { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 0.5rem !important; }
            /* reduce spacing in print */
            #factura-printable .border, #factura-printable .border-gray-200 { padding: 0.35rem !important; }
            /* make inputs look like plain text in print */
            #factura-printable input, #factura-printable textarea { border: none !important; background: transparent !important; box-shadow: none !important; padding: 0 !important; }
            #factura-printable input::placeholder, #factura-printable textarea::placeholder { color: transparent !important; }
            /* shrink fonts slightly for print density */
            #factura-printable { font-size: 12px; }
            /* signature styles for print */
            #firma-container { margin-top: 1rem; }
            .print-signature-box { border: none !important; border-top: 1px solid #6b7280 !important; padding-top: 4rem !important; border-radius: 0 !important; }
            #firma-preview:not(.hidden) { max-height: 5rem; margin-top: -4rem; z-index: 10; }
            #firma-placeholder { display: none !important; }
            #firma-container .no-print { display: none !important; }

        }
    </style>

    <div id="modal-factura" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 p-6 overflow-auto">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-6xl p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-semibold text-slate-800">Factura</h2>
                <div class="flex items-center gap-2">
                    <button id="btn-guardar-fac" class="px-3 py-2 bg-sky-600 text-white rounded-md shadow-sm hover:bg-sky-700">Guardar</button>
                    <button id="btn-imprimir-fac" class="px-3 py-2 bg-emerald-600 text-white rounded-md shadow-sm hover:bg-emerald-700">Imprimir</button>
                    <button id="btn-cerrar-fac" class="px-3 py-2 bg-gray-100 text-slate-700 rounded-md hover:bg-gray-200">Cerrar</button>
                </div>
            </div>

            <div id="factura-printable" class="space-y-6 text-slate-800">
                <!-- Logo superior -->
                <div class="flex justify-center">
                    <div class="w-44 h-24 flex items-center justify-center">
                        <img src="media/logo.png" alt="LOGO" class="max-w-full max-h-full object-contain">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                    <div class="border border-gray-200 p-4 rounded-md bg-gray-50">
                        <div class="flex items-start justify-between gap-4">
                            <div class="min-w-0">
                                <div class="text-xs text-gray-600">Numero de factura</div>
                                <div class="text-lg font-semibold mt-1" id="fac-num">N° ( ID_factura )</div>

                                <div class="mt-4 text-xs text-gray-600">Fecha de emisión</div>
                                <div class="font-mono mt-1" id="fac-fecha">00/00/0000</div>

                                <div class="mt-4 text-xs text-gray-600">Fecha de vencimiento</div>
                                <div class="font-mono mt-1" id="fac-venc">00/00/0000</div>

                                <div class="mt-4 text-xs text-gray-600">Cuotas de pago</div>
                                <select id="fac-cuotas" class="w-full mt-1 p-2 border border-gray-200 rounded-md text-sm">
                                    <option value="1">1 cuota (Pago inmediato)</option>
                                    <option value="2">2 cuotas</option>
                                    <option value="3">3 cuotas</option>
                                    <option value="4">4 cuotas</option>
                                    <option value="5">5 cuotas</option>
                                    <option value="6">6 cuotas</option>
                                </select>
                            </div>

                            <div class="text-sm text-right text-gray-700">
                                <div class="font-bold">Miau-tomotriz</div>
                                <div class="text-xs text-gray-600">correo: example@gmail.com</div>
                                <div class="text-xs text-gray-600">RUT: 00.000.000-0</div>
                                <div class="text-xs text-gray-600">Codigo Postal: 5290000</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-span-1 md:col-span-2">
                        <div class="mt-0">
                            <!-- company info moved to the top-left box -->
                        </div>

                        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 vehicle-para-grid">
                            <div class="border border-gray-200 p-3 rounded-md bg-white">
                                <div class="text-sm font-medium">Datos Vehiculo:</div>
                                <div class="text-sm mt-2">
                                    <label for="veh-estado-select" class="block text-xs font-semibold text-slate-700">Estado:</label>
                                    <select id="veh-estado-select" class="w-full mt-1 p-2 border border-gray-200 rounded-md">
                                        <option value="">Seleccione...</option>
                                        <option value="revision">En revisión</option>
                                        <option value="listo">Listo</option>
                                        <option value="pendiente">Pendiente</option>
                                        <option value="solo_repuestos">Solo repuestos</option>
                                    </select>
                                </div>
                                <div class="text-sm mt-2">Mecánico encargado: <span id="veh-mecanico"><?php echo isset($nombreUsuario) && $nombreUsuario ? htmlspecialchars($nombreUsuario) : '__________'; ?></span></div>
                                <div class="text-sm mt-2">Comentario:</div>
                                <textarea id="veh-comentario" class="w-full p-2 border border-gray-200 rounded-md mt-1" rows="1"></textarea>
                            </div>
                                <div class="border border-gray-200 p-3 rounded-md bg-white">
                                    <div class="text-sm font-medium mb-2">Para</div>
                                    <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-2 gap-2">
                                        <div>
                                            <label for="para-nombre" class="block text-xs font-semibold text-slate-700">Nombre:</label>
                                            <input id="para-nombre" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="Nombre">
                                        </div>
                                        <div>
                                            <label for="para-rut" class="block text-xs font-semibold text-slate-700">RUT:</label>
                                            <input id="para-rut" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="RUT">
                                        </div>
                                        <div>
                                            <label for="para-fono" class="block text-xs font-semibold text-slate-700">Fono:</label>
                                            <input id="para-fono" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="Fono">
                                        </div>
                                        <div>
                                            <label for="para-vin" class="block text-xs font-semibold text-slate-700">VIN:</label>
                                            <input id="para-vin" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="VIN">
                                        </div>
                                        <div>
                                            <label for="para-motor" class="block text-xs font-semibold text-slate-700">N° Motor:</label>
                                            <input id="para-motor" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="N° Motor">
                                        </div>
                                        <div>
                                            <label for="para-matricula" class="block text-xs font-semibold text-slate-700">Matrícula:</label>
                                            <input id="para-matricula" class="w-full p-1.5 text-sm border border-gray-200 rounded mt-0.5" placeholder="Matrícula">
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>

                <div class="mt-2 bg-white border border-gray-100 p-2 rounded-md">
                    <table class="table-auto w-full text-sm">
                        <thead class="bg-gray-50">
                            <tr class="text-left text-sm text-gray-700 border-b">
                                <th class="px-3 py-2">Descripción</th>
                                <th class="px-3 py-2 w-24">Cantidad</th>
                                <th class="px-3 py-2 w-40">Precio unitario</th>
                                <th class="px-3 py-2 w-36 text-right">Importe</th>
                            </tr>
                        </thead>
                        <tbody id="fac-items" class="bg-white">
                            <tr class="border-b">
                                
                                <td class="px-3 py-2">Tu Producto o servicio<input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0,00</span></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="mt-3">
                        <button id="fac-add-item" class="px-3 py-2 bg-yellow-300 hover:bg-yellow-400 rounded-md">(AGREGAR MAS PRODUCTOS)</button>
                    </div>
                </div>

                <div class="mt-4 border-t pt-4 flex justify-between">
                    <!-- Columna izquierda: Firma -->
                    <div id="firma-container" class="w-1/2 max-w-xs">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Firma del Empleado</label>
                        <div class="w-64 h-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center relative print-signature-box">
                            <img id="firma-preview" class="max-h-full max-w-full hidden absolute" alt="Vista previa de la firma"/>
                            <span id="firma-placeholder" class="text-gray-400 text-xs text-center">Vista previa</span>
                        </div>
                        <div class="mt-2 no-print">
                            <input id="firma-input" name="firma_imagen" type="file" accept="image/*" class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"/>
                        </div>
                    </div>

                    <!-- Columna derecha: Totales -->
                    <div class="w-1/2 max-w-xs text-right">
                        <div class="flex justify-between text-sm">
                        <span class="text-gray-600">SubTotal</span>
                        <span id="fac-sub" class="font-mono">$ 0,00</span>
                        </div>
                        <div class="flex justify-between text-sm">
                        <span class="text-gray-600">IVA (21.00%)</span>
                        <span id="fac-iva" class="font-mono">$ 0,00</span>
                        </div>
                        <div class="flex justify-between text-lg font-semibold">
                        <span>TOTAL</span>
                        <span id="fac-total" class="font-mono">$ 0,00</span>
                        </div>
                    </div>
                    </div>
            </div>
        </div>
    </div>

    <script>
    const input = document.getElementById("firma-input");
    const preview = document.getElementById("firma-preview");
    const placeholder = document.getElementById("firma-placeholder");

    input.addEventListener("change", () => {
        const file = input.files[0];
        if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.classList.remove("hidden");
            placeholder.classList.add("hidden");
        };
        reader.readAsDataURL(file);
        } else {
        preview.src = "";
        preview.classList.add("hidden");
        placeholder.classList.remove("hidden");
        }
    });
    </script>


    <script>
        const esAdmin = <?php echo ($_SESSION['empleado'] ?? 0) == 2 ? 'true' : 'false'; ?>;

        const fmt = (n) => {
            try { return n.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); } catch(e) { return Number(n).toFixed(2); }
        };

        // Abrir modal factura
        document.getElementById('btn-crear-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            if (!modal) return;
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            // inicializar fecha
            clearFacForm(); // Limpiar formulario antes de usar
            const hoy = new Date();
            document.getElementById('modal-factura').dataset.fechaEmision = hoy.toISOString();
            document.getElementById('fac-fecha').textContent = hoy.toLocaleDateString();
            document.getElementById('fac-num').textContent = 'N° (Nuevo)';
            updateFacTotals();
            // focus first input
            document.querySelector('#fac-items .desc')?.focus();
        });

        // Listener para cuotas
        document.getElementById('fac-cuotas')?.addEventListener('change', updateVencimiento);

        // Cerrar modal
        document.getElementById('btn-cerrar-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            clearFacForm();
            modal.classList.add('hidden'); modal.style.display = 'none';
        });

        // Cerrar al clicar fuera
        document.getElementById('modal-factura')?.addEventListener('click', function(e){
            if (e.target === this){ this.classList.add('hidden'); this.style.display='none'; }
        });

        // Añadir fila
        document.getElementById('fac-add-item')?.addEventListener('click', function(e){
            e.preventDefault();
            const tbody = document.getElementById('fac-items');
            const tr = document.createElement('tr');
            tr.className = 'border-b';
            tr.innerHTML = `
                <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0,00</span></td>
            `;
            tbody.appendChild(tr);
            attachFacListeners(tr);
            tr.querySelector('.desc')?.focus();
        });

        // Recalcula importes al cambiar cantidad o precio
        function attachFacListeners(row){
            const cant = row.querySelector('.cant');
            const precio = row.querySelector('.precio');
            if (cant) cant.addEventListener('input', updateFacTotals);
            if (precio) precio.addEventListener('input', updateFacTotals);
            updateFacTotals();
        }

        // Attach listeners for initial rows
        document.querySelectorAll('#fac-items tr').forEach(r => attachFacListeners(r));

        function updateFacTotals(){
            let subtotal = 0;
            document.querySelectorAll('#fac-items tr').forEach(tr=>{
                const c = Number((tr.querySelector('.cant')||{value:0}).value) || 0;
                const p = Number((tr.querySelector('.precio')||{value:0}).value) || 0;
                const val = +(c * p);
                const impEl = tr.querySelector('.importe-val');
                if (impEl) impEl.textContent = '$ ' + fmt(val);
                subtotal += val;
            });
            const iva = +(subtotal * 0.21);
            const total = +(subtotal + iva);
            document.getElementById('fac-sub').textContent = '$ ' + fmt(subtotal);
            document.getElementById('fac-iva').textContent = '$ ' + fmt(iva);
            document.getElementById('fac-total').textContent = '$ ' + fmt(total);
        }

        function updateVencimiento() {
            const cuotas = parseInt(document.getElementById('fac-cuotas').value, 10) || 1;
            const fechaEmisionISO = document.getElementById('modal-factura').dataset.fechaEmision;
            if (!fechaEmisionISO) return;

            const fechaVencimiento = new Date(fechaEmisionISO);
            if (cuotas > 1) {
                // Añade (cuotas - 1) meses. Ej: 2 cuotas -> +1 mes.
                fechaVencimiento.setMonth(fechaVencimiento.getMonth() + (cuotas - 1));
            }
            document.getElementById('fac-venc').textContent = fechaVencimiento.toLocaleDateString();
        }

        // --- LÓGICA PARA GUARDAR Y CARGAR ---

        // Recopilar datos del formulario en un objeto
        function getFacturaData() {
            const items = [];
            document.querySelectorAll('#fac-items tr').forEach(tr => {
                items.push({
                    descripcion: tr.querySelector('.desc').value,
                    cantidad: tr.querySelector('.cant').value,
                    precio: tr.querySelector('.precio').value,
                });
            });

            const firmaSrc = document.getElementById('firma-preview').src;

            return {
                id: document.getElementById('modal-factura').dataset.facturaId || null,
                numero: document.getElementById('fac-num').textContent,
                fecha: document.getElementById('fac-fecha').textContent,
                vencimiento: document.getElementById('fac-venc').textContent,
                cuotas: document.getElementById('fac-cuotas').value,
                cliente: {
                    nombre: document.getElementById('para-nombre').value,
                    rut: document.getElementById('para-rut').value,
                    fono: document.getElementById('para-fono').value,
                    vin: document.getElementById('para-vin').value,
                    motor: document.getElementById('para-motor').value,
                    matricula: document.getElementById('para-matricula').value,
                },
                vehiculo: {
                    estado: document.getElementById('veh-estado-select').value,
                    mecanico: document.getElementById('veh-mecanico').textContent,
                    comentario: document.getElementById('veh-comentario').value,
                },
                items: items,
                firma: firmaSrc.startsWith('data:image') ? firmaSrc : null, // Solo guardar si es una imagen cargada
            };
        }

        // Guardar factura (botón Guardar)
        document.getElementById('btn-guardar-fac')?.addEventListener('click', async function() {
            await saveFactura();
        });

        // Imprimir (guarda y luego imprime)
        document.getElementById('btn-imprimir-fac')?.addEventListener('click', async function(){
            await saveFactura();
            window.print();
        });

        // Función para guardar en el servidor
        async function saveFactura() {
            const data = getFacturaData();
            if (!data.cliente.nombre) {
                alert('Por favor, ingrese el nombre del cliente.');
                return;
            }
            try {
                const res = await fetch('save_factura.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const json = await res.json();
                if (json.success) {
                    alert('Factura guardada correctamente.');
                    document.getElementById('modal-factura').dataset.facturaId = json.id; // Guardar el ID para futuras ediciones
                    document.getElementById('fac-num').textContent = 'N° ' + json.id; // Actualizar el número de factura con el ID real
                    renderFacturas(); // Actualizar la lista
                } else {
                    alert('Error al guardar: ' + (json.error || 'desconocido'));
                }
            } catch (e) {
                alert('Error de red al guardar la factura: ' + e.message);
            }
        }

        // Cargar y mostrar la lista de facturas
        async function renderFacturas() {
            const urlParams = new URLSearchParams(window.location.search);
            const rawSearchQuery = urlParams.get('q') || '';

            const tbody = document.getElementById('listado-facturas');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Cargando...</td></tr>';
            try {
                const res = await fetch('save_factura.php');
                const json = await res.json();
                if (!json.success) throw new Error(json.error);

                // Primero, ocultar las facturas marcadas como "Borrado_x"
                let facturasVisibles = json.lista.filter(factura => factura.cliente?.nombre !== 'Borrado_x');

                let facturasFiltradas = facturasVisibles;

                if (rawSearchQuery) {
                    // Limpiar búsqueda para número de factura y normalizar
                    const searchQueryNum = rawSearchQuery.toLowerCase().replace(/n°/g, '').trim();
                    const searchQuery = rawSearchQuery.toLowerCase();

                    facturasFiltradas = facturasVisibles.filter(factura => {
                        const id = String(factura.id);
                        const nombre = factura.cliente?.nombre?.toLowerCase() || '';
                        return id.includes(searchQueryNum) || nombre.includes(searchQuery);
                    });
                }

                tbody.innerHTML = '';
                if (facturasFiltradas.length === 0) {
                    const message = rawSearchQuery ? `No se encontraron facturas para "${urlParams.get('q')}".` : 'No hay facturas guardadas.';
                    tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4">${message}</td></tr>`;
                    return;
                }

                facturasFiltradas.forEach(factura => {
                    // Omitir facturas con datos incompletos para evitar errores de renderizado.
                    if (!factura || typeof factura.id === 'undefined' || !Array.isArray(factura.items)) {
                        console.warn('Omitiendo factura por datos incompletos:', factura);
                        return; // Saltar a la siguiente factura
                    }

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-2">N° ${factura.id}</td>
                        <td class="px-4 py-2">${factura.cliente?.nombre || 'Sin cliente'}</td>
                        <td class="px-4 py-2">${factura.fecha || 'N/A'}</td>
                        <td class="px-4 py-2 font-mono">$ ${fmt(factura.items.reduce((total, item) => total + (item.cantidad * item.precio) * 1.21, 0))}</td>
                        <td class="px-4 py-2 text-center no-print">
                            <div class="flex justify-center items-center space-x-2">
                            <button class="btn-ver-fac px-3 py-1 bg-gray-200 text-sm rounded hover:bg-gray-300" data-factura-id="${factura.id}">Ver</button>
                            ${esAdmin ? `<button class="btn-borrar-fac px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600" data-factura-id="${factura.id}">Borrar</button>` : ''}
                            </div>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Error al cargar facturas: ${e.message}</td></tr>`;
            }
        }

        // Borrar una factura
        async function deleteFactura(id) {
            if (!confirm(`¿Estás seguro de que quieres borrar la factura N° ${id}? Esta acción no se puede deshacer.`)) {
                return;
            }
            try {
                const res = await fetch('save_factura.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'delete', id: id, scope: esAdmin ? 'all' : 'user' })
                });
                const json = await res.json();
                if (json.success) {
                    alert('Factura borrada correctamente.');
                    renderFacturas(); // Actualizar la lista
                } else {
                    alert('Error al borrar: ' + (json.error || 'desconocido'));
                }
            } catch (e) {
                alert('Error de red al borrar la factura: ' + e.message);
            }
        }

        // Cargar una factura en el modal al hacer clic en "Ver/Editar"
        document.getElementById('listado-facturas').addEventListener('click', async function(e) {
            const targetButton = e.target;

            // Acción para borrar la factura
            if (targetButton.matches('.btn-borrar-fac')) {
                const id = targetButton.dataset.facturaId;
                if (id) {
                    deleteFactura(id);
                }
                return; // Finaliza la ejecución aquí
            }

            // Acción para ver/editar la factura
            if (targetButton.matches('.btn-ver-fac')) {
                const id = targetButton.dataset.facturaId;
                if (!id) return;

                try {
                    // Hacemos una petición GET específica para obtener solo la factura necesaria
                    const res = await fetch(`save_factura.php?id=${id}`);
                    const json = await res.json();

                    if (json.success && json.factura) {
                        const factura = json.factura;
                        clearFacForm();
                        document.getElementById('modal-factura').dataset.facturaId = factura.id;
                        
                        const fechaParts = factura.fecha.split('/'); // Asume formato dd/mm/yyyy
                        const fechaEmisionObj = new Date(fechaParts[2], fechaParts[1] - 1, fechaParts[0]);
                        document.getElementById('modal-factura').dataset.fechaEmision = fechaEmisionObj.toISOString();

                        document.getElementById('fac-num').textContent = 'N° ' + factura.id;
                        document.getElementById('fac-fecha').textContent = factura.fecha;
                        document.getElementById('para-nombre').value = factura.cliente?.nombre || '';
                        document.getElementById('para-apellido').value = factura.cliente?.apellido || '';
                        document.getElementById('para-rut').value = factura.cliente?.rut || '';
                        document.getElementById('para-fono').value = factura.cliente?.fono || '';
                        document.getElementById('para-vin').value = factura.cliente?.vin || '';
                        document.getElementById('para-motor').value = factura.cliente?.motor || '';
                        document.getElementById('para-matricula').value = factura.cliente?.matricula || '';
                        document.getElementById('veh-estado-select').value = factura.vehiculo?.estado || '';
                        document.getElementById('veh-comentario').value = factura.vehiculo?.comentario || '';
                        document.getElementById('fac-cuotas').value = factura.cuotas || '1';
                        updateVencimiento();

                        const tbody = document.getElementById('fac-items');
                        tbody.innerHTML = '';
                        factura.items.forEach(item => {
                            const tr = document.createElement('tr');
                            tr.className = 'border-b';
                            tr.innerHTML = `
                                <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value="${item.descripcion || ''}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="${item.cantidad || 0}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="${item.precio || 0}"></td>
                                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0,00</span></td>
                            `;
                            tbody.appendChild(tr);
                            attachFacListeners(tr);
                        });
                        updateFacTotals();
                        document.getElementById('modal-factura').classList.remove('hidden');
                        document.getElementById('modal-factura').style.display = 'flex';
                    } else {
                        alert('Error al cargar la factura: ' + (json.error || 'No se encontró la factura.'));
                    }
                } catch (error) {
                    alert('Error de red al cargar la factura: ' + error.message);
                }
            }
        });

        // Limpiar formulario
        function clearFacForm() {
            document.getElementById('modal-factura').dataset.facturaId = '';
            document.getElementById('modal-factura').dataset.fechaEmision = '';
            document.getElementById('factura-printable').querySelectorAll('input, textarea, select').forEach(el => el.value = '');
            document.getElementById('fac-items').innerHTML = `
                <tr class="border-b">
                    <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                    <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                    <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                    <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0,00</span></td>
                </tr>
            `;
            attachFacListeners(document.querySelector('#fac-items tr'));
            updateFacTotals();
            document.getElementById('fac-cuotas').value = '1';
            updateVencimiento();
            // Limpiar firma
            document.getElementById('firma-input').value = '';
            document.getElementById('firma-preview').src = ''; // Clear src
            document.getElementById('firma-preview').classList.add('hidden');
            document.getElementById('firma-placeholder').classList.remove('hidden');
        }

        // Carga inicial de la lista
        renderFacturas();

        // ESC para cerrar
        document.addEventListener('keydown', function(e){ if (e.key==='Escape'){ const m=document.getElementById('modal-factura'); if (m && !m.classList.contains('hidden')){ m.classList.add('hidden'); m.style.display='none'; } } });
    </script>

<?php include 'footer.php' ?>