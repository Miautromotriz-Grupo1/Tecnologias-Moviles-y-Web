# INFORME DE REVISIÓN DEL SISTEMA - MIAUtomotriz v4

**Fecha:** 08/12/2025  
**Versión:** v4  
**Revisión:** Completa (Conexiones, Autenticación, CRUD, Seguridad)

---

## 📋 RESUMEN EJECUTIVO

El sistema presenta una **arquitectura general sólida** con uso correcto de PostgreSQL, sesiones y validaciones. Se identificaron **8 mejoras prioritarias** y algunos **puntos de atención en seguridad**. La mayoría son optimizaciones que **no afectan funcionamiento crítico**.

---

## ✅ PUNTOS POSITIVOS

### 1. **Conexión a Base de Datos (conexion.php)**
- ✅ Usa PostgreSQL con `pg_connect` correctamente
- ✅ Manejo de errores básico
- ✅ Uso consistente de `pg_query_params` con placeholders ($1, $2...) — **protección SQL Injection**

### 2. **Autenticación y Sesiones**
- ✅ `session_start()` manejado correctamente en todos los archivos
- ✅ Validaciones de rol (`$_SESSION['empleado']`) implementadas
- ✅ Hash de contraseña con `password_verify()` (seguro)
- ✅ Sistema de verificación de correo con tokens y expiración

### 3. **CRUD Operations**
- ✅ `save_factura.php`: INSERT, UPDATE, DELETE con permisos de usuario
- ✅ `save_presupuesto.php`: Soft delete (marca como inactivo), no borra datos
- ✅ Control de permisos: solo creador o admin pueden editar/eliminar

### 4. **Uso Correcto de API PostgreSQL**
- ✅ `pg_query_params()` con placeholders (protección inyección SQL)
- ✅ `pg_fetch_assoc()` para obtener resultados
- ✅ `pg_num_rows()` para validar resultados

---

## ⚠️ PROBLEMAS IDENTIFICADOS

### **PRIORIDAD ALTA**

#### 1️⃣ **Lógica de Sesión Invertida en loginval.php (Línea 8)**
```php
// ❌ PROBLEMA
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}else{
     header("Location: index.php");  // ← Redirige si NO hay sesión (lógica invertida)
}
```
**Impacto:** Login no funciona. Si el usuario entra sin sesión, lo redirige a index.
**Solución:** Eliminar el `else` o invertir la lógica. Solo debería redirigir si YA existe sesión.

```php
// ✅ CORRECTO
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
```

---

#### 2️⃣ **Credenciales Hardcodeadas en conexion.php**
```php
// ❌ PROBLEMA
$usuario = "postgres";
$clave = "Ulagos2025$";
$bd = "miaucar";
```
**Impacto:** Seguridad comprometida. Las credenciales están en el código fuente.
**Solución:** Mover a archivo `.env` no versionado.

```php
// ✅ CORRECTO (usando .env)
$usuario = getenv('DB_USER') ?? 'postgres';
$clave = getenv('DB_PASS') ?? '';
$bd = getenv('DB_NAME') ?? 'miaucar';
```

O usar archivo `.env`:
```
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASS=Ulagos2025$
DB_NAME=miaucar
```

---

#### 3️⃣ **Sin Validación de Sesión en facturas.php (Línea 13)**
```php
// ❌ PROBLEMA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['server_save'])) {
    // Acceso directo sin validar $rut_empleado
    $rut_empleado = $_SESSION['rut'] ?? null;  // ← Puede ser null sin validar
```
**Impacto:** Si `$_SESSION['rut']` es null, se inserta factura sin asignar creador.
**Solución:** Validar sesión antes.

```php
// ✅ CORRECTO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['server_save'])) {
    if (!isset($_SESSION['rut']) || empty($_SESSION['rut'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'No autenticado']);
        exit;
    }
    // ...
}
```

---

#### 4️⃣ **Sin Límite de Tamaño en Firma (save_factura.php)**
```php
// ❌ PROBLEMA
$factura_obj['firma'] = 'data:' . $mtype . ';base64,' . $data;  // Sin validar tamaño
```
**Impacto:** Si la firma es muy grande (>5MB), la tabla `data` puede saturarse.
**Solución:** Limitar tamaño en servidor o guardar en filesystem.

```php
// ✅ CORRECTO
if (!empty($_FILES['firma']['tmp_name'])) {
    $tmp = $_FILES['firma']['tmp_name'];
    $size = filesize($tmp);
    if ($size > 2097152) {  // Límite 2MB
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Firma demasiado grande']);
        exit;
    }
    // ...
}
```

---

### **PRIORIDAD MEDIA**

#### 5️⃣ **Mensajes de Error Exponen Detalles SQL**
```php
// ❌ PROBLEMA
echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
```
**Impacto:** Errores SQL expuestos en JSON (información sensible para atacantes).
**Solución:** Loguear error en server, devolver mensaje genérico al cliente.

```php
// ✅ CORRECTO
if (!$result) {
    error_log('DB Error: ' . pg_last_error($conexion));
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error interno del servidor']);
    exit;
}
```

---

#### 6️⃣ **Sin CSRF Token en Formularios**
```php
// ❌ PROBLEMA
<form action="loginval.php" method="POST">
    <!-- Sin token CSRF -->
</form>
```
**Impacto:** Vulnerable a ataques Cross-Site Request Forgery.
**Solución:** Generar y validar token CSRF.

```php
// ✅ CORRECTO
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// En formulario:
<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

// En validación:
if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('Token CSRF inválido');
}
```

---

#### 7️⃣ **Sin Rate Limiting en Login**
```php
// ❌ PROBLEMA: Cualquiera puede intentar infinitas contraseñas
if (password_verify($password, $fila['contrasenia'])) {
    // Login exitoso
}
```
**Impacto:** Vulnerable a fuerza bruta.
**Solución:** Implementar rate limiting (redis o BD temporal).

```php
// ✅ CORRECTO (simple)
$key = 'login_attempts_' . $_POST['rut'];
$attempts = $_SESSION[$key] ?? 0;
if ($attempts >= 5) {
    die('Demasiados intentos. Intenta más tarde.');
}

if (!password_verify($password, $fila['contrasenia'])) {
    $_SESSION[$key] = $attempts + 1;
    // ...
} else {
    unset($_SESSION[$key]);  // Limpiar al login exitoso
}
```

---

### **PRIORIDAD BAJA (Optimizaciones)**

#### 8️⃣ **Variables No Utilizadas en registerval.php**
```php
// ❌ Variable definida pero no usada
$email = $_POST['email'] ?? '';  // Se define pero el login usa RUT, no email
```
**Solución:** Revisar si `$email` se debe usar o eliminar.

#### 9️⃣ **Funciones Duplicadas**
```php
// En registerval.php Y user_validation.php existen:
function validarRut($rut) { ... }
function formatearRut($rut) { ... }
function regresarConError($msg) { ... }
```
**Solución:** Crear archivo `helpers.php` y incluir en ambos.

```php
// ✅ helpers.php
function validarRut($rut) { /* ... */ }
function formatearRut($rut) { /* ... */ }
function regresarConError($msg) { /* ... */ }

// Luego en registerval.php y user_validation.php:
require 'helpers.php';
```

#### 🔟 **Sin Índices en Tablas**
```sql
-- ❌ Sin índices en columnas frecuentemente buscadas
CREATE TABLE factura (id SERIAL PRIMARY KEY, ...);

-- ✅ Añadir índices
CREATE INDEX idx_factura_creado_por_rut ON factura(creado_por_rut);
CREATE INDEX idx_factura_estado ON factura(estado);
CREATE INDEX idx_presupuesto_creado_por_rut ON presupuesto(creado_por_rut);
CREATE INDEX idx_presupuesto_estado ON presupuesto(estado);
```

---

## 🔍 AUDITORÍA DE SEGURIDAD

| Aspecto | Estado | Nota |
|--------|--------|------|
| **SQL Injection** | ✅ Seguro | Uso de `pg_query_params` |
| **Password Hashing** | ✅ Seguro | `password_verify()` |
| **Session Management** | ⚠️ Revisar | Lógica invertida en loginval |
| **CSRF Protection** | ❌ No implementado | Falta token CSRF |
| **Rate Limiting** | ❌ No implementado | Posible fuerza bruta en login |
| **Error Handling** | ⚠️ Expone detalles | Mostrar errores SQL al cliente |
| **Credenciales** | ❌ Hardcodeadas | Mover a `.env` |
| **SSL/HTTPS** | ❓ Desconocido | Verificar en producción |
| **Input Validation** | ⚠️ Básica | RUT validado, pero email/campos no |
| **Permisos BD** | ⚠️ Verificar | Usuario `postgres` tiene permisos totales |

---

## 📝 RECOMENDACIONES ORDENADAS POR PRIORIDAD

### **Inmediato (Bloqueantes)**
1. ✋ **Corregir loginval.php línea 8** — Login está roto
2. 🔐 **Mover credenciales a `.env`** — Seguridad crítica
3. ✅ **Validar sesión en facturas.php POST** — Evitar nulls

### **Corto Plazo (1-2 semanas)**
4. 🛡️ **Implementar CSRF tokens** — Protección básica
5. 📝 **Ocultar errores SQL** — No exponer detalles
6. 📊 **Añadir índices a tablas** — Rendimiento

### **Mediano Plazo (1 mes)**
7. 🔒 **Rate limiting en login** — Prevenir fuerza bruta
8. 📁 **Refactorizar funciones comunes** — Crear helpers.php
9. 📏 **Limitar tamaño de firmas** — Prevenir saturación

### **Futuro**
10. 📝 **Crear archivo .env.example** — Documentación
11. 🧪 **Añadir unit tests** — Cobertura de pruebas
12. 📊 **Logging centralizado** — Monitoreo de eventos

---

## 🗂️ ESTRUCTURA DE ARCHIVOS RECOMENDADA

```
v4/
├── config/
│   ├── .env                    (NO versionado)
│   ├── .env.example            (Ejemplo para documentar)
│   └── database.php            (Conexión mejorada)
├── helpers/
│   ├── validation.php          (validarRut, formatearRut)
│   ├── errors.php              (regresarConError, logging)
│   └── csrf.php                (Manejo CSRF tokens)
├── views/
│   ├── login.php
│   ├── register.php
│   └── ...
├── api/
│   ├── save_factura.php
│   ├── save_presupuesto.php
│   └── save_producto.php
├── auth/
│   ├── loginval.php
│   ├── registerval.php
│   └── user_validation.php
└── logs/                       (Directorio para logs)
```

---

## 🚀 CHECKLIST PARA IMPLEMENTAR

```
[ ] Corregir lógica de sesión en loginval.php
[ ] Crear archivo .env y .env.example
[ ] Actualizar conexion.php para leer .env
[ ] Crear archivo helpers.php con funciones comunes
[ ] Implementar CSRF tokens en formularios
[ ] Añadir validación de sesión en facturas.php POST
[ ] Validar tamaño de firmas en save_factura.php
[ ] Cambiar pg_last_error() a error_log() en todas las APIs
[ ] Crear índices en tablas principales
[ ] Implementar rate limiting en login
[ ] Crear archivo .gitignore con .env
[ ] Documentar en README.md credenciales requeridas
```

---

## 📞 CONTACTO PARA PREGUNTAS

Si deseas implementar alguna de estas mejoras, contáctame. Las prioritarias (1-3) pueden implementarse en <30 minutos.

---

**Fin del Informe de Revisión**
