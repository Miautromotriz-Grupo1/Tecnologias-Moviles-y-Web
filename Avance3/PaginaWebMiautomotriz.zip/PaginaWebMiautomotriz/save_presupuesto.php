<?php
// Endpoint para guardar, listar, actualizar y eliminar presupuestos en Postgres
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';

// Asegurar que la sesión esté iniciada
if (session_status() == PHP_SESSION_NONE) { session_start(); }

// NOTA: La tabla `presupuesto` almacena el objeto completo en la columna `data` (JSONB).
// Este endpoint trabajará solamente con `id`, `data` y `creado` para máxima compatibilidad
// con esquemas que sólo contienen esas columnas.

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rut_empleado = $_SESSION['rut'] ?? null;
    $es_admin = (($_SESSION['empleado'] ?? 0) == 2);

    // Obtener un presupuesto específico por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        // Solo seleccionamos columnas seguras: id, data, creado
        $query = 'SELECT id, data, creado FROM presupuesto WHERE id = $1';
        $res = pg_query_params($conexion, $query, [$id]);

        if ($res && pg_num_rows($res) > 0) {
            $r = pg_fetch_assoc($res);
            $data = json_decode($r['data'], true);
            if (!$data) $data = [];
            // permisos: buscar creado_por_rut dentro del JSON o fallback a 'rut' (payload antiguo)
            $owner = $data['creado_por_rut'] ?? ($data['rut'] ?? null);
            if (!$es_admin && $owner && $owner !== $rut_empleado) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Sin permisos']);
                exit;
            }
            $data['_id'] = (int)$r['id'];
            $data['_total'] = floatval($data['total'] ?? 0);
            $data['_iva'] = floatval($data['iva'] ?? 0);
            $data['_subtotal'] = floatval($data['subtotal'] ?? 0);
            $data['_fecha'] = $data['fecha'] ?? ($r['creado'] ?? null);
            $data['_creado'] = $r['creado'] ?? null;
            echo json_encode(['success' => true, 'presupuesto' => $data]);
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Presupuesto no encontrado']);
        }
        exit;
    }

    // Listar todos los presupuestos (filtrar por estado dentro del JSON si existe)
    $query = 'SELECT id, data, creado FROM presupuesto ORDER BY id DESC';
    $res = pg_query($conexion, $query);
    if (!$res) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }

    $out = [];
    while ($r = pg_fetch_assoc($res)) {
        $data = json_decode($r['data'], true);
        if (json_last_error() !== JSON_ERROR_NONE) { continue; }
        // Si el objeto contiene "estado" y es false, saltarlo
        if (isset($data['estado']) && $data['estado'] === false) continue;
        // Si no es admin, filtrar por creador (si existe en JSON). Usamos 'creado_por_rut' o 'rut' como fallback
        if (!$es_admin) {
            $owner = $data['creado_por_rut'] ?? ($data['rut'] ?? null);
            if ($owner && $owner !== $rut_empleado) continue;
            // Si owner no está presente, no mostramos el presupuesto a usuarios no-admin (mantener privacidad)
            if (!$owner) continue;
        }
        $data['_id'] = (int)$r['id'];
        $data['_total'] = floatval($data['total'] ?? 0);
        $data['_iva'] = floatval($data['iva'] ?? 0);
        $data['_subtotal'] = floatval($data['subtotal'] ?? 0);
        $data['_fecha'] = $data['fecha'] ?? ($r['creado'] ?? null);
        $data['_creado'] = $r['creado'] ?? null;
        $out[] = $data;
    }
    echo json_encode(['success' => true, 'lista' => $out]);
    exit;
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $obj = json_decode($raw, true);
    if (!$obj) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'JSON inválido']);
        exit;
    }

    $rut_empleado = $_SESSION['rut'] ?? null;
    $es_admin = (($_SESSION['empleado'] ?? 0) == 2);

    // Requerir sesión para crear presupuestos: evitamos registros anónimos.
    if (empty($rut_empleado)) {
        // Si no está autenticado, rechazamos la creación
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Debe iniciar sesión para crear presupuestos']);
        exit;
    }

    // Insertar nuevo presupuesto: almacenamos TODO el objeto en `data`.
    if (empty($obj['_id'])) {
        // Forzar que el creador sea siempre el rut de la sesión
        $obj['creado_por_rut'] = $rut_empleado;
        // Asegurarnos de otros metadatos mínimos
        if (!isset($obj['estado'])) $obj['estado'] = true;
        if (!isset($obj['fecha'])) $obj['fecha'] = date('Y-m-d');

        $json = json_encode($obj);
        $insert_sql = 'INSERT INTO presupuesto(data) VALUES($1) RETURNING id, creado';
        $result = pg_query_params($conexion, $insert_sql, [$json]);
        if (!$result) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
            exit;
        }
        $row = pg_fetch_assoc($result);
        $new_id = $row['id'];
        echo json_encode(['success' => true, 'id' => $new_id, 'creado' => $row['creado']]);
        exit;
    } else {
        // Actualizar presupuesto existente (POST con _id) — trabajamos sobre el JSON
        $id = intval($obj['_id']);
        // Obtener data actual para permisos y merge
        $owner_res = pg_query_params($conexion, 'SELECT data FROM presupuesto WHERE id=$1', [$id]);
        if (!$owner_res || pg_num_rows($owner_res) === 0) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Presupuesto no encontrado']);
            exit;
        }
        $row_old = pg_fetch_assoc($owner_res);
        $old_data = json_decode($row_old['data'], true) ?: [];
        $owner = $old_data['creado_por_rut'] ?? ($old_data['rut'] ?? null);
        if (!$es_admin && $owner && $owner !== $rut_empleado) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Sin permisos para actualizar']);
            exit;
        }

        // Merge: mantener valores existentes si no se envían
        $merged = array_merge($old_data, $obj);
        // Actualizar metadatos
        $merged['modificado'] = date('c');

        $json = json_encode($merged);
        $update_sql = 'UPDATE presupuesto SET data = $1 WHERE id = $2 RETURNING id';
        $result = pg_query_params($conexion, $update_sql, [$json, $id]);
        if (!$result) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
            exit;
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }
}

if ($method === 'DELETE') {
    $rut_empleado = $_SESSION['rut'] ?? null;
    $es_admin = (($_SESSION['empleado'] ?? 0) == 2);

    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'ID requerido']);
        exit;
    }

    $id = intval($_GET['id']);
    // Obtener data actual
    $owner_res = pg_query_params($conexion, 'SELECT data FROM presupuesto WHERE id=$1', [$id]);
    if (!$owner_res || pg_num_rows($owner_res) === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Presupuesto no encontrado']);
        exit;
    }
    $row = pg_fetch_assoc($owner_res);
    $data = json_decode($row['data'], true) ?: [];
    $owner = $data['creado_por_rut'] ?? ($data['rut'] ?? null);
    if (!$es_admin && $owner && $owner !== $rut_empleado) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Sin permisos para eliminar']);
        exit;
    }

    // Soft delete: marcar dentro del JSON
    $data['estado'] = false;
    $data['borrado_por_rut'] = $rut_empleado;
    $data['borrado_en'] = date('c');

    $del = pg_query_params($conexion, 'UPDATE presupuesto SET data = $1 WHERE id = $2', [json_encode($data), $id]);
    if (!$del) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }
    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Método no permitido']);
?>
