<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 

?>
    <main>
        <section class="max-w-4xl mx-auto my-8 px-4">

            <!-- Barra de busqueda -->




<div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <form method="get" class="flex items-center gap-2 w-full">
                    <label for="buscar" class="font-semibold mr-2">Buscar:</label>
                    <input id="buscar" name="q" type="text" placeholder="Escribe para filtrar por nombre, rut o patente" value="<?php echo isset($_GET['q'])?htmlspecialchars($_GET['q'],ENT_QUOTES):''; ?>" class="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sky-300" />

                    <button type="submit" id="btn-buscar" class="bg-white border border-gray-200 p-2 rounded-md hover:shadow-sm" title="Buscar">
                        <img src="media/lupa.webp" alt="Buscar" class="w-5 h-5">
                    </button>
                </form>

                <div class="mt-3 md:mt-0 md:ml-auto">
                <!-- Espacio para usar en u futuro -->
                </div>
            </div>



            <!-- Tabla de clientes -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3">Nombre Cliente</th>
                            <th class="px-4 py-3">RUT</th>
                            <th class="px-4 py-3">Telefono</th>
                            <th class="px-4 py-3">Patente(s)</th>
                            <th class="px-4 py-3 text-center">N° Facturas</th>
                            <th class="px-4 py-3 text-center">Consistencia de Datos</th>
                        </tr>
                    </thead>
                    <tbody id="lista-clientes" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <?php
                        // --- MODIFICACIÓN ---
                        // Manejo de búsqueda en servidor: parámetro q
                        $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';

                        if (isset($conexion) && $conexion) {
                            $rows_to_show = [];
                            $base_sql = "
                                SELECT
                                    data->'cliente'->>'rut' AS rut,
                                    -- Usamos MAX para obtener un nombre consistente para mostrar
                                    MAX(data->'cliente'->>'nombre') AS nombre,
                                    -- Agregamos y concatenamos teléfonos únicos
                                    STRING_AGG(DISTINCT data->'cliente'->>'fono', ' - ') AS telefonos,
                                    -- Agregamos y concatenamos patentes únicas
                                    STRING_AGG(DISTINCT data->'cliente'->>'matricula', ' - ') AS patentes,
                                    -- Contamos el total de facturas por RUT
                                    -- Verificamos si alguna patente es inválida
                                    COUNT(*) AS numero_facturas,
                                    -- Verificamos la consistencia de los datos del cliente (nombre y patente)
                                    CASE
                                        WHEN COUNT(DISTINCT data->'cliente'->>'nombre') > 1 THEN 'Malo'
                                        WHEN bool_or(
                                            data->'cliente'->>'matricula' IS NOT NULL AND
                                            data->'cliente'->>'matricula' != '' AND
                                            UPPER(regexp_replace(data->'cliente'->>'matricula', '[^a-zA-Z0-9]', '', 'g')) !~ '^[A-Z]{2}[0-9]{4}$' AND
                                            UPPER(regexp_replace(data->'cliente'->>'matricula', '[^a-zA-Z0-9]', '', 'g')) !~ '^[A-Z]{4}[0-9]{2}$'
                                        ) THEN 'Revisar Patente'
                                        ELSE 'Bueno'
                                    END AS consistencia_datos
                                FROM factura
                                WHERE data->'cliente'->>'rut' IS NOT NULL AND data->'cliente'->>'rut' != ''
                            ";

                            $group_by_sql = " GROUP BY data->'cliente'->>'rut' ORDER BY nombre ASC";

                            if ($q !== '') {
                                $pattern = '%' . $q . '%';
                                // Agregamos la condición de búsqueda antes del GROUP BY
                                $sql = $base_sql . " AND (data->'cliente'->>'nombre' ILIKE $1 OR data->'cliente'->>'rut' ILIKE $1 OR data->'cliente'->>'matricula' ILIKE $1)" . $group_by_sql;
                                $res = @pg_query_params($conexion, $sql, array($pattern));
                            } else {
                                // Sin búsqueda, ejecutamos la consulta completa
                                $sql = $base_sql . $group_by_sql;
                                $res = @pg_query($conexion, $sql);
                            }

                            if ($res) while ($r = pg_fetch_assoc($res)) $rows_to_show[] = $r;

                            if (count($rows_to_show) === 0) {
                                echo '<tr><td class="px-4 py-4 text-center text-sm text-gray-500" colspan="6">No se encontraron clientes en las facturas.</td></tr>';
                            } else {
                                $esc = function($v){ return htmlspecialchars((string)$v, ENT_QUOTES); };
                                foreach ($rows_to_show as $row) {
                                    $estado_clase = '';
                                    if ($row['consistencia_datos'] == 'Bueno') {
                                        $estado_clase = 'bg-green-100 text-green-800';
                                    } elseif ($row['consistencia_datos'] == 'Malo') {
                                        $estado_clase = 'bg-red-100 text-red-800';
                                    } else { // Revisar Patente
                                        $estado_clase = 'bg-yellow-100 text-yellow-800';
                                    }

                                    echo "<tr>".
                                         "<td class=\"px-4 py-2\">". $esc($row['nombre'] ?? 'N/A') ."</td>".
                                         "<td class=\"px-4 py-2\">". $esc($row['rut'] ?? 'N/A') ."</td>".
                                         "<td class=\"px-4 py-2\">". $esc($row['telefonos'] ?? 'N/A') ."</td>".                                         "<td class=\"px-4 py-2\">". $esc($row['patentes'] ?? 'N/A') ."</td>".
                                         "<td class=\"px-4 py-2 text-center\">". $esc($row['numero_facturas']) ."</td>".
                                         "<td class=\"px-4 py-2 text-center\"><span class=\"px-2 py-1 text-xs font-semibold rounded-full ". $estado_clase ."\">". $esc($row['consistencia_datos']) ."</span></td>".
                                         "</tr>";
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
    
<?php include 'footer.php' ?>