<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php';

// --- Lógica para leer datos de facturas desde la base de datos `factura` ---
$labels_ventas = [];
$datos_ventas = [];
$labels_estados = [];
$datos_estados = [];

// Colores y nombres para las categorías que mostraremos en el dashboard
$colores_estados = [
    'Listo' => '#10B981',      // Verde
    'En taller' => '#3B82F6',   // Azul
    'Otros' => '#6B7280'        // Gris
];

// 1) Ventas por día últimos 30 días (normalizamos a la columna fechaemision)
$ventas_por_dia = [];
$hoy = new DateTime();
$inicio = (new DateTime())->sub(new DateInterval('P29D'));

$sql = "SELECT fechaemision::date AS fecha, COALESCE(SUM(total),0) AS total FROM factura WHERE fechaemision >= current_date - INTERVAL '29 days' GROUP BY fecha ORDER BY fecha";
$res = pg_query($conexion, $sql);
if ($res) {
    while ($row = pg_fetch_assoc($res)) {
        // formato 'Y-m-d' desde postgres
        $fecha = $row['fecha'];
        $total = floatval($row['total']);
        $ventas_por_dia[$fecha] = $total;
    }
}

// Construir etiquetas de últimos 30 días y rellenar con 0 cuando no exista dato
$period = new DatePeriod($inicio, new DateInterval('P1D'), (int)$hoy->diff($inicio)->format('%a') + 1);
foreach ($period as $d) {
    $key = $d->format('Y-m-d');
    $labels_ventas[] = $d->format('d/m');
    $datos_ventas[] = isset($ventas_por_dia[$key]) ? round($ventas_por_dia[$key], 2) : 0;
}

// 2) Conteo de estados por vehículo (leer campo jsonb 'data' -> vehiculo -> estado)
$estados_crudos = [];
$sql2 = "SELECT COALESCE(data->'vehiculo'->> 'estado','desconocido') AS estado, COUNT(*) AS cnt FROM factura GROUP BY COALESCE(data->'vehiculo'->> 'estado','desconocido')";
$res2 = pg_query($conexion, $sql2);
if ($res2) {
    while ($row = pg_fetch_assoc($res2)) {
        $estado = trim(strtolower($row['estado']));
        $cnt = intval($row['cnt']);
        $estados_crudos[$estado] = ($estados_crudos[$estado] ?? 0) + $cnt;
    }
}

// Mapear estados crudos a categorías que queremos mostrar
$mapa = [
    'listo' => 'Listo',
    'solo_repuestos' => 'Listo',
    'pendiente' => 'En taller',
    'revision' => 'En taller'
];

$conteo_categorias = ['Listo' => 0, 'En taller' => 0, 'Otros' => 0];
foreach ($estados_crudos as $raw => $cnt) {
    if (isset($mapa[$raw])) {
        $conteo_categorias[$mapa[$raw]] += $cnt;
    } else {
        $conteo_categorias['Otros'] += $cnt;
    }
}

$labels_estados = array_keys($conteo_categorias);
$datos_estados = array_values($conteo_categorias);
?>

<main class="min-h-screen bg-gray-50 p-4 md:p-6">
    <div class="max-w-7xl mx-auto">
        <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Dashboard de Ventas y Vehículos</h1>
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Gráfico de Ventas -->
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg md:text-xl font-semibold text-gray-700">Monto de Ventas (Últimos 30 días)</h2>
                    <span class="bg-blue-100 text-blue-800 text-xs font-medium px-3 py-1 rounded-full">
                        Total: $<?php echo number_format(array_sum($datos_ventas), 0, ',', '.'); ?>
                    </span>
                </div>
                <div class="h-64 md:h-80">
                    <canvas id="graficoVentas"></canvas>
                </div>
                <div class="mt-4 text-sm text-gray-500">
                    <p>Mostrando tendencia de ventas diarias del último mes.</p>
                </div>
            </div>
            
            <!-- Gráfico de Estados de Vehículos -->
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg md:text-xl font-semibold text-gray-700">Estados de Vehículos</h2>
                    <span class="bg-green-100 text-green-800 text-xs font-medium px-3 py-1 rounded-full">
                        <?php echo array_sum($datos_estados); ?> vehículos
                    </span>
                </div>
                <div class="h-64 md:h-80">
                    <canvas id="graficoEstados"></canvas>
                </div>
                <div class="mt-4">
                    <div class="grid grid-cols-2 gap-2">
                        <?php foreach($labels_estados as $index => $estado): ?>
                        <div class="flex items-center text-sm text-gray-600">
                            <span class="w-3 h-3 rounded-full mr-2" style="background-color: <?php echo array_values($colores_estados)[$index] ?? '#CCC'; ?>"></span>
                            <span class="text-sm text-gray-600"><?php echo $estado; ?>: <?php echo $datos_estados[$index]; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Resumen Estadístico -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div class="bg-blue-50 rounded-lg p-4 border border-blue-100">
                <div class="flex items-center">
                    <div class="bg-blue-100 p-3 rounded-lg mr-4">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Monto Total (30 días)</p>
                        <p class="text-2xl font-bold text-gray-800">$<?php echo number_format(array_sum($datos_ventas), 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-green-50 rounded-lg p-4 border border-green-100">
                <div class="flex items-center">
                    <div class="bg-green-100 p-3 rounded-lg mr-4">
                        <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Vehículos Disponibles</p>
                        <p class="text-2xl font-bold text-gray-800" title="Estado 'Listo'">
                            <?php 
                            $index = array_search('Listo', $labels_estados);
                            echo ($index !== false) ? $datos_estados[$index] : 0;
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="bg-yellow-50 rounded-lg p-4 border border-yellow-100">
                <div class="flex items-center">
                    <div class="bg-yellow-100 p-3 rounded-lg mr-4">
                        <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Vehículos en Taller</p>
                        <p class="text-2xl font-bold text-gray-800" title="Estado 'En revisión'">
                            <?php 
                            $index = array_search('En taller', $labels_estados);
                            echo ($index !== false) ? $datos_estados[$index] : 0;
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Incluir Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Datos desde PHP
    const labelsVentas = <?php echo json_encode($labels_ventas); ?>;
    const datosVentas = <?php echo json_encode($datos_ventas); ?>;
    const labelsEstados = <?php echo json_encode($labels_estados); ?>;
    const datosEstados = <?php echo json_encode($datos_estados); ?>;
    const coloresPHP = <?php echo json_encode($colores_estados); ?>;
    
    // Preparar colores para el gráfico circular
    const coloresGraficoEstados = <?php echo json_encode(array_values($colores_estados)); ?>;
    
    // Gráfico de Ventas (Líneas)
    const ctxVentas = document.getElementById('graficoVentas').getContext('2d');
    new Chart(ctxVentas, {
        type: 'line',
        data: {
            labels: labelsVentas,
            datasets: [{ 
                label: 'Ventas Diarias',
                data: datosVentas,
                borderColor: '#3B82F6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#3B82F6',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                            stepSize: 1,
                            callback: function(value, index, values) {
                                return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', minimumFractionDigits: 0 }).format(value);
                            }
                        },
                    title: {
                        display: true,
                        text: 'Monto de Venta'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Fecha'
                    }
                }
            }
        }
    });
    
    // Gráfico de Estados de Vehículos (Circular)
    const ctxEstados = document.getElementById('graficoEstados').getContext('2d');
    new Chart(ctxEstados, {
        type: 'pie',
        data: {
            labels: labelsEstados,
            datasets: [{
                data: datosEstados,
                backgroundColor: coloresGraficoEstados,
                borderColor: '#FFFFFF',
                borderWidth: 2,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
});
</script>

<?php include 'footer.php'; ?>