<?php
include 'header.php';
@include 'conexion.php'; // Incluir la conexión a la base de datos

$productos = [];
if (isset($conexion) && $conexion) {
    // Consulta para obtener los ÚLTIMOS 3 productos de la base de datos
    $res = pg_query($conexion, "SELECT id, nombre, precio, img, marca, anio FROM piezas ORDER BY id DESC LIMIT 3");
    if ($res) {
        while ($row = pg_fetch_assoc($res)) {
            // Mapear las columnas de la BD a las claves que espera la plantilla
            $productos[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio' => $row['precio'],
                'imagen' => $row['img'] ?? '', // 'img' de la BD se convierte en 'imagen'
                'marca' => $row['marca'] ?? '',
                'anio' => $row['anio'] ?? '',
                'alt' => 'Imagen de ' . htmlspecialchars($row['nombre'])
            ];
        }
    } else {
        // Si la consulta falla, guardamos el error para mostrarlo.
        $db_error = "Error al cargar productos destacados: " . pg_last_error($conexion);
    }
}
?>

<main class="flex-grow max-w-7xl min-h-screen mx-auto w-full p-4 md:p-8">
    <h2 class="text-2xl font-bold mb-4">Ultimos Productos Agregados</h2>

    <!-- Contenedor de productos en formato Grid -->
    <div id="productos-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if (isset($db_error)): ?>
            <div class="col-span-full bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">¡Error!</strong>
                <span class="block sm:inline"><?php echo htmlspecialchars($db_error); ?></span>
            </div>
        <?php else: ?>
            <?php foreach ($productos as $i => $producto) : ?>
            <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg w-full p-6 transition-colors duration-300 flex flex-col h-full" data-id="<?php echo $producto['id']; ?>">
                <div class="prod-img-wrap w-full h-56 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center mb-4 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400">Imagen no disponible</div>
                    <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['alt']); ?>" class="object-cover w-full h-full relative z-10" onerror="this.style.display='none'">
                </div>
                <div class="flex-1 text-center">
                    <h3 class="text-lg font-bold mb-2"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                    <div class="text-sm text-skin-muted mb-2">
                        <span class="prod-marca"><?php echo htmlspecialchars($producto['marca'] ?? ''); ?></span>
                        <span class="prod-anio"><?php echo !empty($producto['anio']) ? ' - ' . htmlspecialchars($producto['anio']) : ''; ?></span>
                    </div>
                    <p class="text-skin-muted font-medium mb-4 text-xl">$<?php echo number_format($producto['precio'], 0, ',', '.'); ?></p>
                </div>
                <div class="mt-auto">
                    <button class="add-to-cart w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-2 rounded-lg shadow-md transition transform active:scale-95" data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>" data-precio="<?php echo htmlspecialchars($producto['precio']); ?>">
                        Agregar al carrito
                    </button>
                </div>
                <?php if (isset($esAdmin) && $esAdmin): ?>
                <div class="mt-3 flex gap-2">
                    <button class="editar-btn px-3 py-1 bg-amber-400 text-black rounded-md" data-index="<?php echo $i; ?>">Editar</button>
                    <button class="borrar-btn px-3 py-1 bg-red-500 text-white rounded-md" data-index="<?php echo $i; ?>">Eliminar</button>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="text-center mt-10">
        <a href="productos.php" class="inline-block bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-1 hover:shadow-xl">
            Ver todos los productos
        </a>
    </div>

    <!-- Sección de Presentación de la Empresa -->
    <div class="mt-16 mb-12">
        <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg p-8 md:p-10">
            <h2 class="text-3xl font-bold text-center text-skin-muted mb-8">Sobre Miau-tomotriz</h2>
            <div class="grid md:grid-cols-2 gap-8">
                
                <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                    <h3 class="text-2xl font-semibold mb-4 text-skin-main">Tu Taller Mecánico de Confianza</h3>
                    <p class="text-skin-muted mb-4">
                        En Miau-tomotriz, nos apasiona mantener tu vehículo en perfectas condiciones. Ofrecemos un servicio integral con personal certificado y equipos de última generación para garantizar la calidad y tu seguridad.
                    </p>
                    <ul class="list-disc list-inside space-y-1 text-skin-muted">
                        <li>Mantenimiento preventivo y correctivo</li>
                        <li>Diagnóstico computarizado avanzado</li>
                        <li>Reparación de frenos, motor y transmisión</li>
                        <li>Servicio eléctrico y venta de repuestos</li>
                    </ul>
                </div>
                
                <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                    <h3 class="text-2xl font-semibold mb-4 text-skin-main">Encuentra tu Próximo Vehículo</h3>
                    <p class="text-skin-muted">
                        Como automotora, te ofrecemos una selección de vehículos nuevos y seminuevos cuidadosamente inspeccionados. Nuestro compromiso es brindarte transparencia, asesoría personalizada y las mejores opciones de financiamiento para que tomes la mejor decisión.
                    </p>
                </div>
            </div>
        </div>
    </div>

</main>

<div class="fixed bottom-6 right-6 z-50">
    <button id="floating-cart" type="button" class="w-16 h-16 rounded-full bg-skin-header text-skin-text flex items-center justify-center text-3xl shadow-2xl hover:scale-110 transition-transform border-2 border-skin-accent" title="Abrir carrito">
        🛒
    </button>   
</div>

<div id="carrito-sidebar" class="fixed inset-y-0 right-0 w-80 bg-skin-header shadow-2xl z-[60] transform translate-x-full transition-transform duration-300 p-6 flex flex-col hidden border-l border-skin-border">
<!-- <div id="carrito-sidebar" class="fixed inset-y-0 right-0 z-[60] w-80  -translate-x-full bg-skin-header border-r border-white/10 p-6 shadow-2xl transition-transform duration-300 ease-in-out flex flex-col"> -->

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-bold text-skin-text">Tu Carrito</h2>
        <button id="cerrar-carrito" class="rounded-md border border-white/20 p-2 text-skin-text hover:bg-red-500/20 hover:text-red-400 hover:border-red-400 transition-colors">
                ✕
        </button>
    </div>
    
    <div id="carrito-lista" class="flex-grow overflow-y-auto space-y-4 text-skin-muted pr-2">
        </div>
    
    <div id="carrito-total" class="mt-4 pt-4 border-t border-skin-border font-bold text-xl text-skin-text text-right">
        Total: $0
    </div>
    <button class="w-full mt-4 bg-skin-accent hover:bg-skin-accent-hover text-white py-3 rounded-lg font-bold shadow-lg transition">
        Ir a Pagar
    </button>
</div>

<!-- Modal para Agregar Producto -->
<div id="add-product-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[70] hidden">
    <div class="bg-skin-card border border-skin-border rounded-lg shadow-xl p-8 w-full max-w-md mx-4">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-skin-main">Agregar Nuevo Producto</h2>
            <button id="close-add-product-modal" class="text-skin-muted hover:text-skin-main text-2xl">&times;</button>
        </div>
        <form id="add-product-form" class="space-y-4">
            <div>
                <label for="product-nombre" class="block text-sm font-medium text-skin-muted">Nombre del Producto</label>
                <input type="text" id="product-nombre" name="nombre" required class="mt-1 block w-full p-2 border border-skin-border rounded-md shadow-sm bg-skin-base text-skin-main focus:ring-skin-accent focus:border-skin-accent">
            </div>
            <div>
                <label for="product-precio" class="block text-sm font-medium text-skin-muted">Precio</label>
                <input type="number" id="product-precio" name="precio" required min="0" class="mt-1 block w-full p-2 border border-skin-border rounded-md shadow-sm bg-skin-base text-skin-main focus:ring-skin-accent focus:border-skin-accent">
            </div>
            <div>
                <label for="product-img" class="block text-sm font-medium text-skin-muted">URL de la Imagen</label>
                <input type="url" id="product-img" name="img" class="mt-1 block w-full p-2 border border-skin-border rounded-md shadow-sm bg-skin-base text-skin-main focus:ring-skin-accent focus:border-skin-accent">
            </div>
            <div>
                <label for="product-marca" class="block text-sm font-medium text-skin-muted">Marca</label>
                <input type="text" id="product-marca" name="marca" class="mt-1 block w-full p-2 border border-skin-border rounded-md shadow-sm bg-skin-base text-skin-main focus:ring-skin-accent focus:border-skin-accent">
            </div>
            <div>
                <label for="product-anio" class="block text-sm font-medium text-skin-muted">Año</label>
                <input type="number" id="product-anio" name="anio" min="1900" max="<?php echo date('Y'); ?>" class="mt-1 block w-full p-2 border border-skin-border rounded-md shadow-sm bg-skin-base text-skin-main focus:ring-skin-accent focus:border-skin-accent">
            </div>
            <button type="submit" class="w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-2 rounded-lg shadow-md transition transform active:scale-95">
                Guardar Producto
            </button>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const addProductBtn = document.getElementById('add-product-btn');
        const addProductModal = document.getElementById('add-product-modal');
        const closeAddProductModal = document.getElementById('close-add-product-modal');
        const addProductForm = document.getElementById('add-product-form');

        // Abre el modal al hacer clic en el botón "Agregar nuevo Producto"
        if (addProductBtn) {
            addProductBtn.addEventListener('click', () => {
                addProductModal.classList.remove('hidden');
            });
        }

        // Cierra el modal al hacer clic en el botón de cerrar (X)
        if (closeAddProductModal) {
            closeAddProductModal.addEventListener('click', () => {
                addProductModal.classList.add('hidden');
                addProductForm.reset(); // Limpia el formulario al cerrar
            });
        }

        // Cierra el modal si se hace clic fuera del contenido del modal
        addProductModal.addEventListener('click', (e) => {
            if (e.target === addProductModal) {
                addProductModal.classList.add('hidden');
                addProductForm.reset();
            }
        });

        // Maneja el envío del formulario para agregar un producto
        if (addProductForm) {
            addProductForm.addEventListener('submit', async (e) => {
                e.preventDefault(); // Evita el envío tradicional del formulario

                const formData = new FormData(addProductForm);
                const productData = Object.fromEntries(formData.entries());

                try {
                    const response = await fetch('add_product.php', { // Envía los datos a add_product.php
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(productData)
                    });
                    const result = await response.json();

                    if (result.success) {
                        alert('Producto agregado exitosamente!');
                        addProductModal.classList.add('hidden');
                        addProductForm.reset();
                        location.reload(); // Recarga la página para mostrar el nuevo producto
                    } else {
                        alert('Error al agregar producto: ' + result.message);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error de conexión al servidor.');
                }
            });
        }
    });
</script>
<?php include 'footer.php' ?>