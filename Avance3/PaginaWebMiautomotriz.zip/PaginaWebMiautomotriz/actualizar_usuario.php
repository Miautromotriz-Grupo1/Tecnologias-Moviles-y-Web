<?php
session_start();

// 1. SEGURIDAD: Solo Admin (nivel 2) puede entrar aquí
if (!isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    header("Location: index.php");
    exit(); 
}

// 2. CONEXIÓN
@include 'conexion.php';
if (!$conexion) { die("Error de conexión"); }

// 3. VERIFICAR POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $rut = isset($_POST['rut_original']) ? trim($_POST['rut_original']) : '';
    
    if (empty($rut)) {
        header("Location: usuarios.php?msg=error_datos");
        exit();
    }

    // --- RECIBIR DATOS ---
    $nombre   = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    

    // Validación básica de campos obligatorios
    if (empty($nombre) || empty($apellido)) {
         header("Location: verusuario.php?rut=$rut&msg=campos_vacios");
         exit();
    }

    // Validar nivel de empleado (0, 1, 2)
    $empleado = isset($_POST['empleado']) ? trim($_POST['empleado']) : null;
    if (!is_numeric($empleado) || $empleado < 0 || $empleado > 2) {
        // Si fallan los datos o intentan inyectar algo raro
        header("Location: verusuario.php?rut=$rut&msg=error_rango_empleado");
        exit();
    }

    // Datos opcionales
    $telefono        = !empty($_POST['telefono']) ? trim($_POST['telefono']) : null;
    $direccionid     = !empty($_POST['direccionid']) ? trim($_POST['direccionid']) : null;
    $fechanacimiento = !empty($_POST['fechanacimiento']) ? trim($_POST['fechanacimiento']) : null;
    $giro            = !empty($_POST['giro']) ? trim($_POST['giro']) : null;
    $rol             = !empty($_POST['rol']) ? trim($_POST['rol']) : null;
    $prevision       = !empty($_POST['prevision']) ? trim($_POST['prevision']) : null;

    // 4. CONSULTA UPDATE CORREGIDA
    // Cambios hechos:
    // 1. Agregué 'correo = $3'
    // 2. Re-enumeré los signos $ (del 4 en adelante)
    // 3. Quité la coma antes del WHERE
    
    $query = "UPDATE persona SET 
                nombre = $1, 
                apellido = $2, 
                telefono = $3, 
                direccionid = $4, 
                fechanacimiento = $5, 
                giro = $6, 
                rol = $7, 
                prevision = $8,
                empleado = $9
              WHERE rut = $10";

    // Array de parámetros (El orden debe coincidir EXACTO con los números de arriba)
    $params = array(
        $nombre,         
        $apellido,         
        $telefono,        
        $direccionid,      
        $fechanacimiento, 
        $giro,           
        $rol,           
        $prevision,        
        $empleado,         
        $rut              
    );

    $result = pg_query_params($conexion, $query, $params);

    if ($result) {
        header("Location: verusuario.php?rut=$rut&msg=actualizado");
    } else {
        // Tip: Si quieres ver el error real para depurar, descomenta la siguiente línea temporalmente:
        // die(pg_last_error($conexion)); 
        header("Location: verusuario.php?rut=$rut&msg=error_sql");
    }

} else {
    // Si intentan entrar directo por URL
    $rut_redirect = isset($_GET['rut']) ? $_GET['rut'] : '';
    header("Location: verusuario.php?rut=" . $rut_redirect);
}
?>