<?php
// 1. INICIAR SESIÓN (Para poder enviar mensajes de vuelta al login)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. DEPENDENCIAS
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'conexion.php';

// --- Función para volver al Login con error ---
function regresarAlLogin($tipo, $mensaje) {
    $_SESSION[$tipo] = $mensaje;
    header("Location: login.php");
    exit();
}

$rut = $_REQUEST['rut'] ?? '';

//  BUSCAR USUARIO EN LA BD
$sql = "SELECT rut, nombre, correo, personaveri FROM persona WHERE rut = $1";
$resultado = pg_query_params($conexion, $sql, array($rut));
$fila = pg_fetch_assoc($resultado);

if (!$resultado) {
    regresarAlLogin('error_registro', 'Error de conexión al verificar el usuario.');
}


// Si el usuario existe:
if (pg_num_rows($resultado) === 1) {

    if ($fila['personaveri']!='f'){
        $usuario = pg_fetch_assoc($resultado);
        $emailDestino = $fila['correo'];
        $nombreUsuario = $fila['nombre'];

        // 6. GENERAR TOKEN DE SEGURIDAD
        $token = bin2hex(random_bytes(16));       // Token visible para la URL
        $token_hash = hash("sha256", $token);     // Token encriptado para la BD
        
        // El token expira en 30 minutos
        $token_expires_at = date("Y-m-d H:i:s", time() + 60 * 30);

        // 7. ACTUALIZAR BD CON EL TOKEN
        $sqlUpdate = "UPDATE persona SET token_hash = $1, token_expires_at = $2 WHERE rut = $3";
        $updateResult = pg_query_params($conexion, $sqlUpdate, array($token_hash, $token_expires_at, $rut));

        if ($updateResult) {
            
            // 8. CONFIGURAR Y ENVIAR CORREO
            $mail = new PHPMailer(true);
            try {
                // Configuración del servidor (Mismos datos que en tu registro)
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; 
                $mail->SMTPAuth   = true;
                $mail->Username   = 'proyectoicinf2@gmail.com'; 
                $mail->Password   = 'zkke fpjo nxcc xejs'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                $mail->setFrom('proyectoicinf2@gmail.com', 'Soporte MIAUtomotriz');
                $mail->addAddress($emailDestino, $nombreUsuario);

                $mail->isHTML(true);
                $mail->CharSet = 'UTF-8';
                $mail->Subject = 'Restablecer contraseña - MIAUtomotriz';

                // Construcción del Link hacia recuperacuenta.php
                $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
                $host = $_SERVER['HTTP_HOST'];
                
                // IMPORTANTE: Asegúrate que esta ruta apunte a tu nuevo archivo frontend
                $path = "/pagina/v4/recuperacuenta.php"; 
                
                $link = "$protocol://$host$path?token=$token";

                $mail->Body = "
                    <h2>Hola $nombreUsuario,</h2>
                    <p>Recibimos una solicitud para restablecer tu contraseña asociada al RUT <strong>$rut</strong>.</p>
                    <p>Para crear una nueva clave, haz clic en el siguiente enlace:</p>
                    <p><a href='$link' style='font-weight:bold; color:#4F46E5;'>Restablecer mi contraseña</a></p>
                    <p><small>Este enlace es válido por 30 minutos.</small></p>
                ";

                $mail->AltBody = "Copia y pega este enlace para restablecer tu contraseña: $link";

                $mail->send();

                // --- ÉXITO ---
                // Regresamos al login con mensaje verde
                regresarAlLogin('mensaje_exito', "Se ha enviado un enlace de recuperación al correo asociado a este RUT.");

            } catch (Exception $e) {
                regresarAlLogin('error_registro', "El usuario existe, pero falló el envío del correo.");
            }

        } else {
            regresarAlLogin('error_registro', "Error interno al generar el token de recuperación.");
        }

    } else {
        regresarAlLogin('error_registro', "Usuario no verificado.");
    }
        
    }else{
    regresarAlLogin('error_registro', 'El RUT ingresado no se encuentra registrado en el sistema.');
    }
    
?>