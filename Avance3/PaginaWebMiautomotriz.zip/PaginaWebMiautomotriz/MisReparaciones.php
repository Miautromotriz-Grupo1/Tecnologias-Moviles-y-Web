<?php 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 

?>
    <main>
        <style>
        @media print {
            .no-print {
            display: none !important;
            }
        }
        </style>
        <section class="max-w-4xl mx-auto my-8 px-4">

    
            <!-- Barra de búsqueda + agregar -->


                <h2 class="text-3xl font-bold mb-8">Mi Orden de trabajo</h2>
                <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                    <div class="flex items-center mr-3">
                        <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg shadow-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                            </svg>
                        </a>
                    </div>

                    <label for="buscar" class="font-semibold mr-2">Buscar:</label>

                    <div class="flex items-center gap-2 w-full md:w-auto">
                        <input id="buscar" type="text" placeholder="Escribe para filtrar..." class="w-full md:w-80 p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sky-300" />

                        <button id="btn-buscar" class="bg-white border border-gray-200 p-2 rounded-md hover:shadow-sm" title="Buscar">
                            <img src="media/lupa.webp" alt="Buscar" class="w-5 h-5" />
                        </button>
                    </div>

                    <div class="mt-3 md:mt-0 md:ml-auto">
                        <button id="btnAgregarReparacion" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow">Agregar Reparación</button>
                    </div>
                </div>
            <div class="max-w-2xl mx-auto px-4 py-8">
            
            <!-- Tabla de facturas -->
            <div class="overflow-x-auto bg-white rounded-md shadow">
                <table class="min-w-full divide-y divide-gray-200" aria-describedby="listado-facturas">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3">Matricula</th>
                            <th class="px-4 py-3">Cliente</th>
                            <th class="px-4 py-3">Fecha</th>
                            <th class="px-4 py-3">Mantenimiento</th>
                            <th class="px-4 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="listado-facturas" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <!-- Facturas cargadas dinámicamente -->
                    </tbody>
                </table>
            </div>

        </section>

            <!-- Modal del formulario (oculto por defecto) -->
            <div id="modalFormulario" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div class="bg-white rounded-lg shadow-lg max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                    <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
                        <h3 class="text-2xl font-bold">Nueva Reparación</h3>
                        <button id="btnCerrarModal" class="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
                    </div>

                    <form id="reparacionForm" method="POST" action="" class="p-6">
                        <!-- Fecha y Matrícula -->
                        <div class="flex flex-col md:flex-row gap-6 mb-6">
                            <div class="flex-1">
                                <label for="fecha" class="block text-sm font-medium text-gray-700 mb-2">Fecha</label>
                                <input type="date" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" id="fecha" name="fecha" required>
                            </div>
                            <div class="flex-1">
                                <label for="placa" class="block text-sm font-medium text-gray-700 mb-2">Matricula del vehículo</label>
                                <input type="text" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" id="placa" name="placa" required>
                            </div>
                        </div>

                        <!-- Nombre del conductor -->
                        <div class="mb-6">
                            <label for="nombre_conductor" class="block text-sm font-medium text-gray-700 mb-2">Nombre del Cliente</label>
                            <input type="text" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" id="nombre_conductor" name="nombre_conductor" required>
                        </div>

                        <!-- Número móvil -->
                        <div class="mb-6">
                            <label for="numero_movil" class="block text-sm font-medium text-gray-700 mb-2">Número móvil</label>
                            <input type="text" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" id="numero_movil" name="numero_movil" required>
                        </div>

                        <!-- Mantenimiento efectuado -->
                        <div class="mb-6">
                            <label class="block text-sm font-medium text-gray-700 mb-3">Mantenimiento efectuado</label>
                            <div class="flex items-center mb-3">
                                <input class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" type="radio" id="preventivo" name="mantenimiento" value="preventivo" required>
                                <label class="ml-3 text-sm text-gray-700" for="preventivo">Mantenimiento Preventivo</label>
                            </div>
                            <div class="flex items-center">
                                <input class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" type="radio" id="correctivo" name="mantenimiento" value="correctivo" required>
                                <label class="ml-3 text-sm text-gray-700" for="correctivo">Mantenimiento Correctivo</label>
                            </div>
                        </div>

                        <!-- Descripción del mantenimiento -->
                        <div class="mb-6">
                            <label for="descripcion" class="block text-sm font-medium text-gray-700 mb-2">Descripción del mantenimiento efectuado</label>
                            <textarea class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" id="descripcion" name="descripcion" rows="4" required></textarea>
                        </div>

                        <!-- Cargar foto -->
                        <div class="mb-6">
                            <label for="foto" class="block text-sm font-medium text-gray-700 mb-2">Cargar foto de la factura o soporte del mantenimiento</label>
                            <input type="file" id="foto" name="foto" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept="image/*">
                        </div>

                        <!-- Firma -->
                        <div class="mb-6 no-print">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Firma del Empleado</label>
                            <div class="flex items-center gap-4">
                                <!-- Vista previa -->
                                <div class="w-48 h-24 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center overflow-hidden">
                                    <img id="firma-preview" class="max-h-full max-w-full hidden" alt="Vista previa de la firma"/>
                                    <span id="firma-placeholder" class="text-gray-400 text-xs text-center">Vista previa</span>
                                </div>
                                <!-- Campo para subir imagen de firma -->
                                <input id="firma-input" name="firma_imagen" type="file" accept="image/*" class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"/>
                            </div>
                        </div>

                        <!-- Botones -->
                        <div class="flex gap-3">
                            <button type="reset" class="px-6 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 font-medium">Limpiar</button>
                            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Enviar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        const btnAgregarReparacion = document.getElementById('btnAgregarReparacion');
        const modalFormulario = document.getElementById('modalFormulario');
        const btnCerrarModal = document.getElementById('btnCerrarModal');

        // Abrir modal
        btnAgregarReparacion.addEventListener('click', () => {
            document.getElementById('fecha').valueAsDate = new Date();
            modalFormulario.classList.remove('hidden');
        });

        // Cerrar modal
        btnCerrarModal.addEventListener('click', () => {
            modalFormulario.classList.add('hidden');
        });

        // Cerrar modal al hacer clic fuera
        modalFormulario.addEventListener('click', (e) => {
            if (e.target === modalFormulario) {
                modalFormulario.classList.add('hidden');
            }
        });

        // Lógica para la vista previa de la firma
        const firmaInput = document.getElementById('firma-input');
        const firmaPreview = document.getElementById('firma-preview');
        const firmaPlaceholder = document.getElementById('firma-placeholder');

        firmaInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    firmaPreview.src = e.target.result;
                    firmaPreview.classList.remove('hidden');
                    firmaPlaceholder.classList.add('hidden');
                }
                reader.readAsDataURL(file);
            }
        });
    </script>

<?php include 'footer.php' ?>