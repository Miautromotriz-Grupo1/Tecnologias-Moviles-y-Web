<?php
include 'header.php';
@include 'conexion.php'; // Incluir la conexión a la base de datos

// Obtener el término de búsqueda de la URL
$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
// Obtener el rango de precios
$precio_min = isset($_GET['precio_min']) && is_numeric($_GET['precio_min']) ? (int)$_GET['precio_min'] : '';
$precio_max = isset($_GET['precio_max']) && is_numeric($_GET['precio_max']) ? (int)$_GET['precio_max'] : '';

$productos = [];
if (isset($conexion) && $conexion) {
    $base_query = "SELECT id, nombre, precio, img, marca, anio FROM piezas";
    $conditions = [];
    $params = [];
    $param_count = 1;

    if (!empty($search_query)) {
        $conditions[] = "(nombre ILIKE $" . $param_count . " OR marca ILIKE $" . $param_count . ")";
        $params[] = '%' . $search_query . '%';
        $param_count++;
    }
    if ($precio_min !== '') {
        $conditions[] = "precio >= $" . $param_count;
        $params[] = $precio_min;
        $param_count++;
    }
    if ($precio_max !== '') {
        $conditions[] = "precio <= $" . $param_count;
        $params[] = $precio_max;
    }

    // Cambiamos el orden a ASC para mostrar desde el ID 1 en adelante.
    $query = $base_query . (!empty($conditions) ? " WHERE " . implode(' AND ', $conditions) : "") . " ORDER BY id ASC";
    
    // Quitamos el @ para poder ver errores si la consulta falla.
    $res = pg_query_params($conexion, $query, $params);

    if ($res) {
        while ($row = pg_fetch_assoc($res)) {
            // Mapear las columnas de la BD a las claves que espera la plantilla
            $productos[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio' => $row['precio'],
                'imagen' => $row['img'] ?? '',
                'marca' => $row['marca'] ?? '',
                'anio' => $row['anio'] ?? '',
                'alt' => 'Imagen de ' . htmlspecialchars($row['nombre'])
            ];
        }
    } else {
        // Si la consulta falla, guardamos el error para mostrarlo.
        $db_error = "Error al consultar la base de datos: " . pg_last_error($conexion);
    }
}
?>

<main class="flex-grow max-w-7xl min-h-screen mx-auto w-full p-4 md:p-8">
    <h2 class="text-3xl font-bold mb-8 text-center">Todos Nuestros Productos</h2>

    <!-- Barra de búsqueda -->
    <div class="mb-8 max-w-2xl mx-auto p-4 bg-skin-card2 rounded-lg border border-skin-border">
        <form method="get" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
            <div class="md:col-span-2">
                <label for="buscar" class="block text-sm font-medium text-skin-muted mb-1">Buscar</label>
                <input id="buscar" name="q" type="text" placeholder="Nombre o marca..." value="<?php echo htmlspecialchars($search_query); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div>
                <label for="precio_min" class="block text-sm font-medium text-skin-muted mb-1">Precio Mín.</label>
                <input id="precio_min" name="precio_min" type="number" placeholder="0" value="<?php echo htmlspecialchars($precio_min); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div>
                <label for="precio_max" class="block text-sm font-medium text-skin-muted mb-1">Precio Máx.</label>
                <input id="precio_max" name="precio_max" type="number" placeholder="Sin límite" value="<?php echo htmlspecialchars($precio_max); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div class="md:col-span-4 flex justify-end gap-2 mt-2">
                <a href="productos.php" class="bg-skin-card border border-skin-border text-skin-muted px-4 py-2 rounded-lg hover:shadow-sm" title="Limpiar búsqueda">
                    Limpiar
                </a>
                
                <?php if (isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2): ?>
                    <button id="add-product-btn" class="bg-yellow-500 hover:bg-yellow-600 border text-black px-3 py-2 rounded-lg sowhad-sm transform hover:shadow-sm flex items-center gap-2">
                        Agregar nuevo Producto
                    </button>
                <button type="submit" class="bg-skin-accent text-white px-6 py-2 rounded-lg hover:bg-skin-accent-hover shadow-sm" title="Buscar">
                    Buscar
                </button>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <!-- Contenedor de productos en formato Grid -->
    <div id="productos-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php if (isset($db_error)): ?>
            <div class="col-span-full bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">¡Error!</strong>
                <span class="block sm:inline"><?php echo htmlspecialchars($db_error); ?></span>
            </div>
        <?php elseif (empty($productos) && (empty($search_query) && $precio_min === '' && $precio_max === '')): ?>
            <p class="col-span-full text-center text-skin-muted">No hay productos en la base de datos.</p>
        <?php elseif (empty($productos)): ?>
            <p class="col-span-full text-center text-skin-muted">No se encontraron productos que coincidan con tu búsqueda.</p>
        <?php else: ?>
            <?php foreach ($productos as $i => $producto) : ?>
            <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg w-full p-6 transition-colors duration-300 flex flex-col h-full" data-id="<?php echo $producto['id']; ?>">
                <div class="prod-img-wrap w-full h-56 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center mb-4 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400">Imagen no disponible</div>
                    <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['alt']); ?>" class="object-cover w-full h-full relative z-10" onerror="this.style.display='none'">
                </div>
                <div class="flex-1 text-center">
                    <h3 class="text-lg font-bold mb-2"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                    <div class="text-sm text-skin-muted mb-2">
                        <span class="prod-marca"><?php echo htmlspecialchars($producto['marca'] ?? ''); ?></span>
                        <span class="prod-anio"><?php echo !empty($producto['anio']) ? ' - ' . htmlspecialchars($producto['anio']) : ''; ?></span>
                    </div>
                    <p class="text-skin-muted font-medium mb-4 text-xl">$<?php echo number_format($producto['precio'], 0, ',', '.'); ?></p>
                </div>
                <div class="mt-auto">
                    <button class="add-to-cart w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-2 rounded-lg shadow-md transition transform active:scale-95" data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>" data-precio="<?php echo htmlspecialchars($producto['precio']); ?>">
                        Agregar al carrito
                    </button>
                </div>
                <?php if (isset($esAdmin) && $esAdmin): ?>
                <div class="mt-3 flex gap-2">
                    <button class="editar-btn px-3 py-1 bg-amber-400 text-black rounded-md" data-index="<?php echo $i; ?>">Editar</button>
                    <button class="borrar-btn px-3 py-1 bg-red-500 text-white rounded-md" data-index="<?php echo $i; ?>">Eliminar</button>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<?php include 'footer.php' ?>