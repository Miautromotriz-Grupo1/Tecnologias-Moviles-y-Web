<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

@include 'conexion.php';

$response = ['success' => false, 'error' => 'No se pudo conectar a la base de datos.'];

if (isset($conexion) && $conexion) {
    // Verificar permisos de administrador
    $esAdmin = isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2;
    if (!$esAdmin) {
        echo json_encode(['success' => false, 'error' => 'Acceso no autorizado.']);
        exit;
    }

    $method = $_SERVER['REQUEST_METHOD'];
    $data = json_decode(file_get_contents('php://input'), true);

    try {
        // --- LÓGICA DE VALIDACIÓN DE DATOS COMÚN ---
        $nombre = $data['nombre'] ?? '';
        $precio = $data['precio'] ?? 0;
        $img = $data['img'] ?? '';
        
        // Validación de Marca: Si es vacío, enviamos NULL
        $marca = !empty($data['marca']) ? $data['marca'] : null;

        // Validación de Año (CRÍTICO PARA TU ERROR DE POSTGRES)
        // PostgreSQL DATE no acepta "" ni solo el año. 
        $anioInput = $data['anio'] ?? '';
        $anio = null;
        
        if (!empty($anioInput)) {
            // Si es solo un número (ej: 2025), lo convertimos a fecha completa: 2025-01-01
            if (is_numeric($anioInput)) {
                $anio = $anioInput . '-01-01'; 
            } else {
                // Si ya viene como fecha, lo dejamos tal cual
                $anio = $anioInput;
            }
        } 
        // Si $anioInput estaba vacío, $anio se queda como NULL, que PG sí acepta.

        if ($method === 'POST') {
            // INSERTAR
            if (!empty($nombre) && is_numeric($precio)) {
                $sql = "INSERT INTO piezas (nombre, precio, img, marca, anio) VALUES ($1, $2, $3, $4, $5)";
                // pg_query_params maneja el NULL de PHP correctamente como SQL NULL
                $result = pg_query_params($conexion, $sql, [$nombre, $precio, $img, $marca, $anio]);

                if ($result) {
                    // Recuperar el ID generado (si tu tabla tiene serial/sequence)
                    // O devolver los datos enviados
                    $response = ['success' => true]; 
                } else {
                    $response['error'] = 'Error al insertar: ' . pg_last_error($conexion);
                }
            } else {
                $response['error'] = 'Nombre y precio son obligatorios.';
            }

        } elseif ($method === 'PUT') {
            // --- ACTUALIZAR ---
            $id = $data['id'] ?? null;
            $nombre = $data['nombre'] ?? '';
            $precio = $data['precio'] ?? 0;
            $img = $data['img'] ?? '';
            $marca = !empty($data['marca']) ? $data['marca'] : null;

            // --- CORRECCIÓN CRÍTICA PARA EL AÑO ---
            // Copiamos la misma lógica que usamos en el POST
            $anioInput = $data['anio'] ?? '';
            $anio = null;
            
            if (!empty($anioInput)) {
                if (is_numeric($anioInput)) {
                    // Convertir año simple (2025) a fecha completa (2025-01-01)
                    $anio = $anioInput . '-01-01'; 
                } else {
                    $anio = $anioInput;
                }
            } 
            // Si está vacío, $anio se queda como NULL, que PostgreSQL sí acepta.
            // ----------------------------------------

            if ($id && !empty($nombre) && is_numeric($precio)) {
                $sql = "UPDATE piezas SET nombre = $1, precio = $2, img = $3, marca = $4, anio = $5 WHERE id = $6";
                // Asegúrate que el orden de las variables coincida con los $números
                $result = pg_query_params($conexion, $sql, [$nombre, $precio, $img, $marca, $anio, $id]);
                
                if ($result) {
                    $response = ['success' => true];
                } else {
                    $response['error'] = 'Error al actualizar: ' . pg_last_error($conexion);
                }
            } else {
                $response['error'] = 'Faltan datos (ID, nombre o precio).';
            }
        } elseif ($method === 'DELETE') {
            // ELIMINAR
            $id = $_GET['id'] ?? null;
            if ($id) {
                $sql = "DELETE FROM piezas WHERE id = $1";
                $result = pg_query_params($conexion, $sql, [$id]);
                if ($result) {
                    $response = ['success' => true];
                } else {
                    $response['error'] = 'Error al eliminar: ' . pg_last_error($conexion);
                }
            }
        }
    } catch (Exception $e) {
        $response['error'] = 'Excepción: ' . $e->getMessage();
    }
}

echo json_encode($response);
?>