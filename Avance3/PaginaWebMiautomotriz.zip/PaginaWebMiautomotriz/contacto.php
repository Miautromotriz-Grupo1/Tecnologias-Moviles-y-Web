<?php 
include 'header.php';


?>
<main class="bg-skin-base flex-grow">
    <div class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h1 class="text-4xl font-extrabold text-skin-muted tracking-tight sm:text-5xl">Contáctanos</h1>
            <p class="mt-4 max-w-2xl mx-auto text-lg text-skin-muted">
                Si tienes alguna pregunta, comentario o necesitas asistencia, no dudes en contactarnos a través de los siguientes medios.
            </p>
        </div>

        <div class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl overflow-hidden transition-colors duration-300">
            <?php
                // Clases base y gradiente azul por defecto
                $header_classes = 'p-8 text-white bg-gradient-to-r from-sky-500 to-cyan-400 dark:from-sky-800 dark:to-cyan-700';
                // Si es admin/empleado, reemplazamos las clases del gradiente por el verde
                if (isset($esAdmin) && ($esAdmin || $esEmpleado)) {
                    $header_classes = str_replace('from-sky-500 to-cyan-400 dark:from-sky-800 dark:to-cyan-700', 'from-green-500 to-emerald-500 dark:from-green-700 dark:to-emerald-700', $header_classes);
                }
            ?>
            <header class="<?php echo $header_classes; ?>">
                <h2 class="text-3xl font-bold">MIAUtomotriz</h2>
                <p class="text-lg opacity-90">Tu vehículo en las mejores manos</p>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
                
                <div class="space-y-6">
                    <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                        <h3 class="text-xl font-semibold mb-3 text-skin-main">Nuestros servicios</h3>
                        <ul class="list-disc list-inside space-y-1 text-skin-muted">
                            <li>Mantenimiento preventivo y correctivo</li>
                            <li>Revisión de frenos, suspensión y dirección</li>
                            <li>Diagnóstico computarizado</li>
                            <li>Cambio de aceite y filtros</li>
                            <li>Reparación de motor y transmisión</li>
                            <li>Servicio eléctrico y escáner automotriz</li>
                            <li>Venta de repuestos y accesorios</li>
                        </ul>
                    </div>

                    <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                        <h3 class="text-xl font-semibold mb-3 text-skin-main">Compromiso</h3>
                        <p class="text-skin-muted">Ofrecemos atención personalizada, transparencia total y compromiso con la seguridad y calidad en cada servicio.</p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                        <h3 class="text-xl font-semibold mb-3 text-skin-main">Información de Contacto</h3>
                        <div class="text-skin-muted space-y-1">
                            <p><strong>Dirección:</strong> Av. Los Pinos 456, Osorno, Chile</p>
                            <p><strong>Teléfono:</strong> 📞 +56 9 8765 4321</p>
                            <p><strong>Email:</strong> 🌐 Miautromotriz.contact@gmail.com</p>
                            <p><strong>Horario:</strong> 🕒 Lun - Vie: 08:30 - 18:30 | Sáb: 09:00 - 13:00</p>
                        </div>
                    </div>

                    <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                        <h3 class="text-xl font-semibold mb-3 text-skin-main">Por qué elegirnos</h3>
                        <ul class="list-disc list-inside space-y-1 text-skin-muted">
                            <li>Personal técnico certificado</li>
                            <li>Equipos de diagnóstico modernos</li>
                            <li>Presupuestos claros y justos</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'footer.php' ?>