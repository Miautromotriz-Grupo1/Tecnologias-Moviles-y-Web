<?php
// Endpoint para guardar y listar facturas en Postgres - Tabla 'factura'
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';

if (session_status() == PHP_SESSION_NONE) { 
    session_start(); 
}

// Asegurar que existan las columnas necesarias en tabla factura
pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS creado_por_rut VARCHAR(20)");
pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS data JSONB");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $obj = json_decode($raw, true);
    if (!$obj) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'JSON inválido']);
        exit;
    }
    
    $rut_empleado = $_SESSION['rut'] ?? null;
    $json = json_encode($obj);
    $id = !empty($obj['id']) ? intval($obj['id']) : null;
    
    // Calcular totales
    $subtotal = 0.0;
    $cantidad_total = 0;
    $repuestos = [];
    
    if (!empty($obj['items']) && is_array($obj['items'])) {
        foreach ($obj['items'] as $item) {
            $cant = floatval($item['cantidad'] ?? 0);
            $precio = floatval($item['precio'] ?? 0);
            $subtotal += $cant * $precio;
            $cantidad_total += (int)$cant;
            if (!empty($item['descripcion'])) {
                $repuestos[] = $item['descripcion'];
            }
        }
    }
    
    $neto = $subtotal;
    $iva_porcentaje = 0.21; // 21%
    $total = $neto + ($neto * $iva_porcentaje);
    $repuestos_str = implode(', ', array_slice($repuestos, 0, 100));
    $mecanico = $obj['vehiculo']['mecanico'] ?? null;
    
    // Parsear fecha dd/mm/yyyy a yyyy-mm-dd
    $fecha_str = $obj['fecha'] ?? date('d/m/Y');
    $fecha_parts = explode('/', $fecha_str);
    if (count($fecha_parts) == 3) {
        $fecha_emision = $fecha_parts[2] . '-' . str_pad($fecha_parts[1], 2, '0', STR_PAD_LEFT) . '-' . str_pad($fecha_parts[0], 2, '0', STR_PAD_LEFT);
    } else {
        $fecha_emision = date('Y-m-d');
    }
    
    // Actualizar o insertar
    if ($id) {
        $result = pg_query_params($conexion, 
            'UPDATE factura SET fechaemision = $1, neto = $2, iva = $3, total = $4, cantidad = $5, repuestosusados = $6, mecanicoencargado = $7, data = $8, creado_por_rut = $9 WHERE id = $10 RETURNING id',
            array($fecha_emision, $neto, $iva_porcentaje, $total, $cantidad_total, $repuestos_str, $mecanico, $json, $rut_empleado, $id)
        );
    } else {
        $result = pg_query_params($conexion,
            'INSERT INTO factura(fechaemision, neto, iva, total, cantidad, repuestosusados, mecanicoencargado, creado_por_rut, data) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id',
            array($fecha_emision, $neto, $iva_porcentaje, $total, $cantidad_total, $repuestos_str, $mecanico, $rut_empleado, $json)
        );
    }

    if (!$result) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }
    
    $row = pg_fetch_assoc($result);
    $new_id = $row['id'] ?? $id;

    echo json_encode(['success' => true, 'id' => $new_id]);
    exit;
}

if ($method === 'GET') {
    $rut_empleado = $_SESSION['rut'] ?? null;
    $es_admin = ($_SESSION['empleado'] ?? 0) == 2;
    
    // Obtener una sola factura por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        
        if ($es_admin) {
            $query = 'SELECT id, data, creado_por_rut FROM factura WHERE id = $1';
            $res = pg_query_params($conexion, $query, [$id]);
        } else {
            $query = 'SELECT id, data, creado_por_rut FROM factura WHERE id = $1 AND creado_por_rut = $2';
            $res = pg_query_params($conexion, $query, [$id, $rut_empleado]);
        }
        
        if ($res && pg_num_rows($res) > 0) {
            $r = pg_fetch_assoc($res);
            $data = json_decode($r['data'], true);
            if ($data) {
                $data['id'] = (int)$r['id'];
                $data['creado_por_rut'] = $r['creado_por_rut'];
                echo json_encode(['success' => true, 'factura' => $data]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Datos JSON inválidos']);
            }
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Factura no encontrada o sin permisos']);
        }
        exit;
    }
    
    // Obtener lista de facturas
    $scope = $_GET['scope'] ?? 'user';
    
    if ($es_admin && $scope === 'all') {
        $query = 'SELECT id, data, creado_por_rut FROM factura WHERE data IS NOT NULL ORDER BY id DESC LIMIT 100';
        $res = pg_query($conexion, $query);
    } else {
        if (!$rut_empleado) {
            echo json_encode(['success' => true, 'lista' => []]);
            exit;
        }
        $query = 'SELECT id, data, creado_por_rut FROM factura WHERE creado_por_rut = $1 AND data IS NOT NULL ORDER BY id DESC LIMIT 100';
        $res = pg_query_params($conexion, $query, array($rut_empleado));
    }
    
    if (!$res) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }
    
    $out = [];
    while ($r = pg_fetch_assoc($res)) {
        if ($r['data']) {
            $data = json_decode($r['data'], true);
            if ($data && is_array($data)) {
                $data['id'] = (int)$r['id'];
                $data['creado_por_rut'] = $r['creado_por_rut'];
                $out[] = $data;
            }
        }
    }
    echo json_encode(['success' => true, 'lista' => $out]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Método no permitido']);
?>