<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}

include 'header.php';

?>
<main class="max-w-5xl mx-auto my-8 p-4">
    <section class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl w-full  p-10 transition-colors duration-300 relative z-10">

        <!-- Apartado del Panel del Empleado -->

        <h2 class="text-3xl text-skin-muted font-bold mb-2 tracking-tight">Panel de funciones <?php if ($esAdmin){echo '- Empleados';}?></h2>

        <div class="grid grid-cols-1 md:gri d-cols-2 lg:grid-cols-3 gap-6">

            <a href="MisReparaciones.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Mi Orden de trabajo</h3>
                <p class="text-skin-text">Gestión de reparaciones y Ordenes de trabajo.</p>
            </a>

            <a href="clientes.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Clientes</h3>
                <p class="text-skin-text">Gestión básica de clientes y registros.</p>
            </a>

            <a href="inventario.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Inventario</h3>
                <p class="text-skin-text">Control de productos y servicios disponibles.</p>
            </a>

            <a href="MisFacturas.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Mis facturas</h3>
                <p class="text-skin-text">Listado de facturas emitidas.</p>
            </a>

            <a href="MisPresupuestos.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Mis presupuestos</h3>
                <p class="text-skin-text">Seguimiento de presupuestos realizados.</p>
            </a>

            <a href="reportes.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Reportes</h3>
                <p class="text-skin-text">Resumenes e informes generales.</p>
            </a>
        </div>

        <!-- Apartado del Panel del Administrador -->

        <?php if ($esAdmin): ?>
        <h2 class="text-3xl text-skin-muted pt-4 font-bold mb-2 tracking-tight">Panel de Administrador</h2>
            <div class="grid grid-cols-1 md:gri d-cols-2 lg:grid-cols-3 gap-6">

            <a href="usuarios.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Usuarios</h3>
                <p class="text-skin-text">Gestión de usuarios Totales.</p>
            </a>
            
            <a href="facturas.php" class="block p-4 bg-skin-header border border-skin-border rounded-2xl shadow-2xl w-full hover:shadow-lg transition">
                <h3 class="text-lg font-semibold text-skin-text mb-2">Facturas</h3>
                <p class="text-skin-text">Gestión de todas las Facturas.</p>
            </a>
        </div>
        <?php endif?>
    </section>
</main>

<?php include 'footer.php' ?>