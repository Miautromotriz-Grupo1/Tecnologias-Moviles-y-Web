<?php 

// --- INICIO DE LA SESIÓN Y CONTROL DE ACCESO ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Permitir acceso a admin (empleado=2) y mecanicos (empleado=1)
// Se definen variables booleanas para un control de permisos más claro en el código.
$es_admin = ($_SESSION['empleado'] ?? 0) == 2;
$es_mecanico = ($_SESSION['empleado'] ?? 0) == 1;

// Si el usuario no es ni admin ni mecánico, se le redirige a la página de inicio.
if (!$es_admin && !$es_mecanico) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

// --- MANEJO DE FORMULARIO POST (LEGACY/FALLBACK) ---
// Este bloque maneja un envío de formulario tradicional (no-AJAX).
// Actualmente, la página usa JavaScript (AJAX) para guardar, por lo que este bloque es un fallback o código legacy.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['server_save'])) {
    // Recolectar datos mínimos desde el formulario
    $cliente = [
        'nombre' => trim($_POST['cliente_nombre'] ?? ''),
        'apellido' => trim($_POST['cliente_apellido'] ?? ''),
        'rut' => trim($_POST['cliente_rut'] ?? ''),
        'fono' => trim($_POST['cliente_fono'] ?? ''),
        'vin' => trim($_POST['cliente_vin'] ?? ''),
        'motor' => trim($_POST['cliente_motor'] ?? ''),
        'matricula' => trim($_POST['cliente_matricula'] ?? ''),
    ];

    $vehiculo = [
        'estado' => trim($_POST['veh_estado'] ?? ''),
        'mecanico' => trim($_POST['veh_mecanico'] ?? ($_SESSION['nombre'] ?? '')),
        'comentario' => trim($_POST['veh_comentario'] ?? ''),
    ];

    // Items: arrays
    $items = [];
    $descs = $_POST['item_desc'] ?? [];
    $cants = $_POST['item_cant'] ?? [];
    $precios = $_POST['item_price'] ?? [];
    for ($i = 0; $i < max(count($descs), count($cants), count($precios)); $i++) {
        $desc = $descs[$i] ?? '';
        $cant = $cants[$i] ?? 0;
        $precio = $precios[$i] ?? 0;
        if ($desc === '' && floatval($cant) === 0 && floatval($precio) === 0) continue;
        $items[] = ['descripcion' => $desc, 'cantidad' => (int)$cant, 'precio' => floatval($precio)];
    }

    // Construir objeto factura similar al JS
    $factura_obj = [
        'numero' => trim($_POST['numero'] ?? ''),
        'fecha' => trim($_POST['fecha'] ?? date('d/m/Y')),
        'vencimiento' => trim($_POST['vencimiento'] ?? ''),
        'cuotas' => trim($_POST['cuotas'] ?? '1'),
        'cliente' => $cliente,
        'vehiculo' => $vehiculo,
        'items' => $items,
        'firma' => null,
    ];

    // Manejar firma subida (opcional)
    if (!empty($_FILES['firma']['tmp_name'])) {
        $tmp = $_FILES['firma']['tmp_name'];
        $mtype = mime_content_type($tmp) ?: 'image/png';
        $data = base64_encode(file_get_contents($tmp));
        $factura_obj['firma'] = 'data:' . $mtype . ';base64,' . $data;
    }

    // Calcular resumen (subtotal/total/cantidad) aquí
    $subtotal = 0.0; $cantidad_total = 0; $repuestos = [];
    foreach ($items as $it) {
        $c = isset($it['cantidad']) ? floatval($it['cantidad']) : 0;
        $p = isset($it['precio']) ? floatval($it['precio']) : 0;
        $subtotal += $c * $p;
        $cantidad_total += (int)$c;
        if (!empty($it['descripcion'])) $repuestos[] = $it['descripcion'];
    }
    $total = $subtotal * 1.21; // IVA 21%

    // Insertar en tabla `factura` usando $conexion (creada por save_factura.php si no existe)
    $json = json_encode($factura_obj);
    $mecanico = $vehiculo['mecanico'] ?? null;
    $repuestos_str = implode(', ', array_slice($repuestos, 0, 50));
    $rut_empleado = $_SESSION['rut'] ?? null;

    $insert_sql = 'INSERT INTO factura(data, total, cantidad, repuestosusados, mecanicoencargado, creado_por_rut) VALUES($1,$2,$3,$4,$5,$6) RETURNING id';
    $res = pg_query_params($conexion, $insert_sql, array($json, $total, $cantidad_total, $repuestos_str, $mecanico, $rut_empleado));
    if ($res && pg_num_rows($res) > 0) {
        $new = pg_fetch_assoc($res);
        $new_id = $new['id'];
        header('Location: facturas.php?msg=guardado&id=' . intval($new_id));
        exit;
    } else {
        header('Location: facturas.php?msg=error');
        exit;
    }
}

include 'header.php' 

?>
    <main>
        <style>
        @media print {
            .no-print, .no-print * {
            display: none !important;
            }
        }
        </style>
        <section class="max-w-6xl mx-auto my-8 px-4">

            <!-- Barra de busqueda -->

            <!-- Contenedor principal para los controles de la página: Volver, Búsqueda y Acciones -->
            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <!-- Botón para volver al menú de funciones -->
                    <a href="funciones.php" id="back-to-menu" class="bg-skin-card inline-flex items-center border border-skin-border rounded-2xl shadow-2xl px-3 py-2  rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 svg-text-main" viewBox="0 0 20 20" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <!-- Formulario de búsqueda para filtrar facturas -->
                <form method="get" class="flex items-center gap-2 w-full md:w-auto">
                    <label for="buscar" class="font-semibold text-skin-muted mr-2">Buscar:</label>
                    <input id="buscar" class="w-full md:w-80 text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border rounded-2xl shadow-2xl focus:outline-none focus:ring-2 focus:ring-sky-300" name="q"  type="text" placeholder="Filtrar por N° factura, nombre o RUT empleado" value="<?php echo isset($_GET['q'])?htmlspecialchars($_GET['q'],ENT_QUOTES):''; ?>"  />

                    <button type="submit" id="btn-buscar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md " title="Buscar">
                        <span alt="Buscar" class="svg-text-main block w-5 h-5">
                            <?php include 'media/lupa.svg'; ?>
                        </span>
                    </button>
                        <!-- Botón para limpiar la búsqueda y mostrar todas las facturas -->
                        <a href="facturas.php" id="btn-cancelar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md hover:shadow-sm inline-flex items-center" title="Limpiar búsqueda">
                            <span class="svg-text-main block w-5 h-5">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                            </span>
                        </a>
                </form>

                <div class="mt-3 md:mt-0 md:ml-auto">
                </div>
            </div>

            <!-- Tabla donde se listarán las facturas -->
            <div class="overflow-x-auto bg-white rounded-md shadow">
                <table class="min-w-full divide-y divide-gray-200" aria-describedby="listado-facturas">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3">N° Factura</th>
                            <th class="px-4 py-3">Cliente</th>
                            <th class="px-4 py-3">Creado por (RUT)</th>
                            <th class="px-4 py-3">Fecha Emisión</th>
                            <th class="px-4 py-3">Total</th>
                            <th class="px-4 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="listado-facturas" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <!-- Las filas de facturas se cargarán aquí dinámicamente con JavaScript -->
                    </tbody>
                </table>
            </div>

        </section>
    </main>

    <!-- =================================================================== -->
    <!-- ============ MODAL Y PLANTILLA DE FACTURA (HTML/CSS) ============== -->
    <!-- =================================================================== -->
    <style>
        /* --- ESTILOS ESPECÍFICOS PARA LA IMPRESIÓN --- */
        @media print {
            /* Define márgenes de la página y permite que el navegador gestione el tamaño */
            @page {
                size: auto;
                margin: 1cm;
            }

            /* Oculta todo por defecto */
            body * { visibility: hidden !important; }
            
            /* Hace visible solo el área de la factura */
            #factura-printable, #factura-printable * { visibility: visible !important; }

            /* Resetea los contenedores del modal para que no limiten el contenido */
            #modal-factura { position: static !important; overflow: visible !important; background: none !important; padding: 0 !important; }
            #modal-factura > div { max-height: none !important; overflow: visible !important; box-shadow: none !important; padding: 0 !important; }
            #factura-printable { position: static !important; width: 100%; height: auto; overflow: visible !important; box-shadow: none !important; border: none !important; }

            /* Oculta elementos no deseados en la impresión */
            .no-print, #fac-add-item, #btn-imprimir-fac, #btn-descargar-pdf, #btn-cerrar-fac, #btn-guardar-fac { display: none !important; }

            /* --- AJUSTES DE DISEÑO PARA OPTIMIZAR EL ESPACIO --- */
            /* Reduce el espaciado general y los gaps */
            #factura-printable { space-y-6: 0 !important; gap: 0.5rem !important; }
            #factura-printable > div { margin-top: 0.5rem !important; }
            #factura-printable .vehicle-para-grid { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 0.5rem !important; }
            #factura-printable .gap-4 { gap: 0.5rem !important; }
            #factura-printable .gap-8 { gap: 1rem !important; }
            #factura-printable .p-4 { padding: 0.5rem !important; }
            #factura-printable .p-3 { padding: 0.5rem !important; }
            #factura-printable .p-2 { padding: 0.25rem !important; }
            #factura-printable .px-3 { padding-left: 0.5rem !important; padding-right: 0.5rem !important; }
            #factura-printable .py-2 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
            #factura-printable .mt-1, #factura-printable .mt-2, #factura-printable .mt-3, #factura-printable .mt-4, #factura-printable .mt-6 { margin-top: 0.25rem !important; }
            #factura-printable .pt-6 { padding-top: 0.5rem !important; }
            
            /* --- CONTROL DE SALTOS DE PÁGINA --- */
            /* Evita que los bloques se corten por la mitad */
            #factura-printable tr, #factura-printable .items-section, #factura-printable .bottom-section, #factura-printable .grid > div { page-break-inside: avoid !important; }
            .print-break-after { page-break-after: always !important; }

            /* Hace que los inputs parezcan texto plano */
            #factura-printable input, #factura-printable textarea { border: none !important; background: transparent !important; box-shadow: none !important; padding: 0 !important; }
            #factura-printable input::placeholder, #factura-printable textarea::placeholder { color: transparent !important; }
            /* shrink fonts slightly for print density */
            #factura-printable { font-size: 12px; }
        }
    </style>

    <!-- Contenedor del Modal: ocupa toda la pantalla y centra el contenido. Oculto por defecto. -->
    <div id="modal-factura" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 p-6 overflow-auto">
        <!-- Contenido del Modal: el formulario de la factura en sí. -->
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-6xl p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-semibold text-slate-800">Detalle de Factura</h2>
                <div class="flex items-center gap-2">
                    <button id="btn-guardar-fac" class="px-3 py-2 bg-sky-600 text-white rounded-md shadow-sm hover:bg-sky-700">Guardar</button>
                    <button id="btn-imprimir-fac" class="px-3 py-2 bg-emerald-600 text-white rounded-md shadow-sm hover:bg-emerald-700">Imprimir</button>
                    <button id="btn-cerrar-fac" class="px-3 py-2 bg-gray-100 text-slate-700 rounded-md hover:bg-gray-200">Cerrar</button>
                </div>
            </div>

            <!-- Área imprimible de la factura -->
            <div id="factura-printable" class="space-y-6 text-slate-800">
                <!-- Cabecera: Info de la empresa y Logo -->
                <div class="flex justify-between items-start">
                    <!-- Logo a la izquierda -->
                    <div class="w-40 h-20 flex items-center justify-center">
                        <img src="media/logo.png" alt="LOGO" class="max-w-full max-h-full object-contain">
                    </div>
                    <!-- Info de la empresa a la derecha -->
                    <div class="text-sm text-gray-700 text-right">
                        <div class="font-bold text-lg">Miau-tomotriz</div>
                        <div>correo: example@gmail.com</div>
                        <div>RUT: 00.000.000-0</div>
                        <div>Codigo Postal: 5290000</div>
                    </div>
                </div>

                <!-- Sección superior: Datos de la factura y de la empresa -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                    <div class="border border-gray-200 p-4 rounded-md bg-gray-50 min-w-0">
                        <div class="text-xs text-gray-600">Numero de factura</div>
                        <div class="text-lg font-semibold mt-1" id="fac-num">N° ( ID_factura )</div>

                        <div class="mt-4 text-xs text-gray-600">Fecha de emisión</div>
                        <div class="font-mono mt-1" id="fac-fecha">00/00/0000</div>

                        <div class="mt-4 text-xs text-gray-600">Fecha de vencimiento</div>
                        <div class="font-mono mt-1" id="fac-venc">00/00/0000</div>

                        <div class="mt-4 text-xs text-gray-600">Cuotas de pago</div>
                        <select id="fac-cuotas" class="w-full mt-1 p-2 border border-gray-200 rounded-md text-sm">
                            <option value="1">1 cuota (Pago inmediato)</option>
                            <option value="2">2 cuotas</option>
                            <option value="3">3 cuotas</option>
                            <option value="4">4 cuotas</option>
                            <option value="5">5 cuotas</option>
                            <option value="6">6 cuotas</option>
                        </select>
                    </div>

                    <!-- Sección superior derecha: Datos del vehículo y del cliente -->
                    <div class="col-span-1 md:col-span-2">
                        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 vehicle-para-grid">
                            <div class="border border-gray-200 p-3 rounded-md bg-white">
                                <div class="text-sm font-medium">Datos Vehiculo:</div>
                                <div class="text-sm mt-2">
                                    <label for="veh-estado-select" class="block text-xs font-semibold text-slate-700">Estado:</label>
                                    <select id="veh-estado-select" class="w-full mt-1 p-2 border border-gray-200 rounded-md">
                                        <option value="">Seleccione...</option>
                                        <option value="revision">En revisión</option>
                                        <option value="listo">Listo</option>
                                        <option value="pendiente">Pendiente</option>
                                        <option value="solo_repuestos">Solo repuestos</option>
                                    </select>
                                </div>
                                <div class="text-sm mt-2">Mecánico encargado: <span id="veh-mecanico"><?php echo isset($nombreUsuario) && $nombreUsuario ? htmlspecialchars($nombreUsuario) : '__________'; ?></span></div>
                                <div class="text-sm mt-2">Comentario:</div>
                                <textarea id="veh-comentario" class="w-full p-2 border border-gray-200 rounded-md mt-1" rows="1"></textarea>
                            </div>

                            <div class="border border-gray-200 p-3 rounded-md bg-white">
                                <div class="text-sm font-medium">Para</div>
                                <div class="mt-2 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 items-start">
                                    <div class="col-span-2 grid grid-cols-2 gap-x-4">
                                        <div>
                                            <label for="para-nombre" class="block text-xs font-semibold text-slate-700">Nombre:</label>
                                            <input id="para-nombre" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Nombre">
                                        </div>
                                        <div>
                                            <label for="para-apellido" class="block text-xs font-semibold text-slate-700">Apellido:</label>
                                            <input id="para-apellido" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Apellido">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="para-rut" class="block text-xs font-semibold text-slate-700">Rut:</label>
                                        <input id="para-rut" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Rut">
                                    </div>
                                    <div>
                                        <label for="para-fono" class="block text-xs font-semibold text-slate-700">Fono:</label>
                                        <input id="para-fono" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Fono">
                                    </div>
                                    <div>
                                        <label for="para-vin" class="block text-xs font-semibold text-slate-700">Vin:</label>
                                        <input id="para-vin" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Vin">
                                    </div>
                                    <div>
                                        <label for="para-motor" class="block text-xs font-semibold text-slate-700">Numero del Motor:</label>
                                        <input id="para-motor" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Numero del Motor">
                                    </div>
                                    <div>
                                        <label for="para-matricula" class="block text-xs font-semibold text-slate-700">Matricula:</label>
                                        <input id="para-matricula" class="w-full p-1.5 border border-gray-200 rounded-md mt-1" placeholder="Matricula">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección de Items: Tabla con los productos o servicios de la factura -->
                <div class="items-section mt-2 bg-white border border-gray-100 p-2 rounded-md">
                    <table class="table-auto w-full text-sm">
                        <thead class="bg-gray-50">
                            <tr class="text-left text-sm text-gray-700 border-b">
                                <th class="px-3 py-2">Descripción</th>
                                <th class="px-3 py-2 w-24">Cantidad</th>
                                <th class="px-3 py-2 w-40">Precio unitario</th>
                                <th class="px-3 py-2 w-36 text-right">Importe</th>
                            </tr>
                        </thead>
                        <tbody id="fac-items" class="bg-white">
                            <!-- Las filas de items se añadirán aquí. Esta es una fila de ejemplo/plantilla. -->
                            <tr class="border-b item-row">
                                
                                <td class="px-3 py-2">Tu Producto o servicio<input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0,00</span></td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Botón para añadir más filas de items a la tabla -->
                    <div class="mt-3">
                        <button id="fac-add-item" class="px-3 py-2 bg-yellow-300 hover:bg-yellow-400 rounded-md">Añadir Producto/Servicio</button>
                    </div>
                </div>

                <!-- Sección inferior: Firma y Totales -->
                <div class="bottom-section mt-6 border-t pt-6 grid grid-cols-1 md:grid-cols-3 gap-8">
                    <!-- Columna Izquierda: Firmas -->
                    <div class="md:col-span-2">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-8">
                            <!-- Firma del Empleado -->
                            <div>
                                <div class="text-sm mb-2">Firma del Empleado</div>
                                <!-- Campo para subir imagen de firma (solo visible en pantalla) -->
                                <div class="firma-area no-print">
                                    <input id="firma-input" type="file" accept="image/*" class="border p-2 text-sm w-full" />
                                </div>
                                <!-- Vista previa de la firma -->
                                <div class="mt-2 h-24 border flex items-center justify-center overflow-hidden bg-gray-50">
                                    <img id="firma-preview" class="max-h-full max-w-full hidden" alt="Firma Empleado" />
                                    <span id="firma-placeholder" class="text-gray-400 text-xs">Vista previa firma</span>
                                </div>
                            </div>
                            <!-- Firma del Cliente -->
                            <div>
                                <div class="text-sm mb-2">Firma del Cliente</div>
                                <div class="mt-2 h-24 border flex items-end justify-center p-2 bg-gray-50">
                                    <div class="w-full border-t border-gray-400"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Columna Derecha: Totales -->
                    <div class="md:col-span-1">
                        <div class="w-full max-w-xs ml-auto text-right space-y-1">
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">SubTotal</span>
                                <span id="fac-sub" class="font-mono">$ 0,00</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">IVA (21.00%)</span>
                                <span id="fac-iva" class="font-mono">$ 0,00</span>
                            </div>
                            <div class="flex justify-between text-lg font-semibold">
                                <span>TOTAL</span>
                                <span id="fac-total" class="font-mono">$ 0,00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal genérico para notificaciones y confirmaciones -->
    <div id="modal-notificacion" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black/60 p-6">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6 transform transition-all scale-95 opacity-0" id="notificacion-contenido">
            <h3 id="notificacion-titulo" class="text-lg font-semibold text-gray-800"></h3>
            <div id="notificacion-mensaje" class="mt-2 text-sm text-gray-600"></div>
            <div id="notificacion-extra" class="mt-4"></div>
            <div id="notificacion-botones" class="mt-6 flex justify-end gap-3">
                <!-- Botones se agregarán dinámicamente -->
            </div>
        </div>
    </div>


    <!-- =================================================================== -->
    <!-- =================== SCRIPT DE LÓGICA DE FACTURAS ================== -->
    <!-- =================================================================== -->
    <script>
    // --- LÓGICA PARA LA CARGA DE LA IMAGEN DE FIRMA ---
    const input = document.getElementById("firma-input");
    const preview = document.getElementById("firma-preview");
    const placeholder = document.getElementById("firma-placeholder");

    // Cuando el usuario selecciona un archivo en el input...
    input.addEventListener("change", () => {
        const file = input.files[0];
        if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.classList.remove("hidden");
            placeholder.classList.add("hidden");
        };
        reader.readAsDataURL(file);
        } else { // Si cancela la selección, se limpia la vista previa.
        preview.src = "";
        preview.classList.add("hidden");
        placeholder.classList.remove("hidden");
        }
    });
    </script>

    <script>
        // --- VARIABLES GLOBALES Y FUNCIONES DE UTILIDAD ---

        // Variables globales para determinar permisos, inyectadas desde PHP.
        const esAdmin = <?php echo $es_admin ? 'true' : 'false'; ?>;
        const esMecanico = <?php echo $es_mecanico ? 'true' : 'false'; ?>;
        
        // Función para formatear números como moneda (sin decimales).
        const fmt = (n) => {
            try { return n.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); } catch(e) { return Number(n).toFixed(0); }
        };
        // Función para formatear números con 2 decimales.
        const fmtDec = (n) => {
            try { return n.toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); } catch(e) { return Number(n).toFixed(2); }
        }

        // --- MANEJO DE EVENTOS DEL MODAL DE FACTURA ---

        // Evento para abrir el modal al crear una nueva factura (botón no presente en esta página, pero la lógica está lista).
        document.getElementById('btn-crear-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            if (!modal) return;
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            clearFacForm(); // Limpiar formulario antes de usar
            const hoy = new Date();
            document.getElementById('modal-factura').dataset.fechaEmision = hoy.toISOString();
            document.getElementById('fac-fecha').textContent = hoy.toLocaleDateString();
            document.getElementById('fac-num').textContent = 'N° (Nuevo)';
            updateFacTotals();
            // focus first input
            document.querySelector('#fac-items .desc')?.focus();
        });

        // Cuando cambian las cuotas, se actualiza la fecha de vencimiento.
        document.getElementById('fac-cuotas')?.addEventListener('change', updateVencimiento);

        // Evento para el botón "Cerrar" del modal.
        document.getElementById('btn-cerrar-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            clearFacForm();
            modal.classList.add('hidden'); modal.style.display = 'none';
        });

        // Evento para cerrar el modal si se hace clic en el fondo oscuro.
        document.getElementById('modal-factura')?.addEventListener('click', function(e){
            if (e.target === this){ this.classList.add('hidden'); this.style.display='none'; }
        });

        // Evento para el botón "Añadir Producto/Servicio".
        document.getElementById('fac-add-item')?.addEventListener('click', function(e){
            e.preventDefault();
            const tbody = document.getElementById('fac-items');
            const tr = document.createElement('tr');
            tr.className = 'border-b item-row';
            tr.innerHTML = `
                <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0</span></td>
            `;
            tbody.appendChild(tr);
            attachFacListeners(tr);
            tr.querySelector('.desc')?.focus();
        });

        // --- LÓGICA DE CÁLCULO DE LA FACTURA ---

        // Asigna listeners a una fila de item para que los totales se recalculen automáticamente.
        function attachFacListeners(row){
            const cant = row.querySelector('.cant');
            const precio = row.querySelector('.precio');
            if (cant) cant.addEventListener('input', updateFacTotals);
            if (precio) precio.addEventListener('input', updateFacTotals);
            updateFacTotals();
        }

        // Asigna los listeners a las filas que ya existen al cargar la página.
        document.querySelectorAll('#fac-items tr').forEach(r => attachFacListeners(r));

        // Calcula y actualiza los importes de cada línea, el subtotal, IVA y total general.
        function updateFacTotals(){
            let subtotal = 0;
            document.querySelectorAll('#fac-items tr').forEach(tr=>{
                const c = Number((tr.querySelector('.cant')||{value:0}).value) || 0;
                const p = Number((tr.querySelector('.precio')||{value:0}).value) || 0;
                const val = +(c * p);
                const impEl = tr.querySelector('.importe-val'); 
                if (impEl) impEl.textContent = '$ ' + fmt(val); 
                subtotal += val;
            });
            const neto = subtotal;
            const iva_monto = +(neto * 0.21);
            const total = +(neto + iva_monto);
            document.getElementById('fac-sub').textContent = '$ ' + fmt(neto); 
            document.getElementById('fac-iva').textContent = '$ ' + fmt(iva_monto);
            document.getElementById('fac-total').textContent = '$ ' + fmt(total);
        }

        // Calcula la fecha de vencimiento basándose en la fecha de emisión y el número de cuotas.
        function updateVencimiento() {
            try {
                const cuotasInput = document.getElementById('fac-cuotas');
                if (!cuotasInput) return;
                
                const cuotas = parseInt(cuotasInput.value, 10) || 1;
                const modalElement = document.getElementById('modal-factura');
                if (!modalElement) return;
                
                const fechaEmisionISO = modalElement.dataset.fechaEmision;
                if (!fechaEmisionISO) {
                    console.warn('No hay fecha de emisión');
                    return;
                }

                // Crear fecha de forma defensiva
                let fechaVencimiento = new Date(fechaEmisionISO);
                
                // Validación
                if (!fechaVencimiento || isNaN(fechaVencimiento.getTime())) {
                    console.error('Fecha inválida, usando hoy:', fechaEmisionISO);
                    fechaVencimiento = new Date();
                }
                
                // Sumar meses solo si cuotas > 1
                if (cuotas > 1) {
                    try {
                        const diaActual = fechaVencimiento.getDate();
                        let mesResultado = fechaVencimiento.getMonth() + (cuotas - 1);
                        let añoResultado = fechaVencimiento.getFullYear();
                        
                        // Ajustar años si necesario
                        while (mesResultado > 11) {
                            mesResultado -= 12;
                            añoResultado += 1;
                        }
                        
                        // Obtener último día válido del mes resultante de forma segura
                        // Primer día del mes siguiente, menos 1 día
                        const primerDelSiguiente = new Date(añoResultado, mesResultado + 1, 1);
                        const ultimoDiaDelMes = new Date(primerDelSiguiente.getTime() - 24 * 60 * 60 * 1000).getDate();
                        
                        // Usar el día actual o el último día del mes, lo que sea menor
                        const diaFinal = Math.min(diaActual, ultimoDiaDelMes);
                        
                        // Crear la fecha final
                        fechaVencimiento = new Date(añoResultado, mesResultado, diaFinal);
                        
                        // Validar que la fecha sea válida
                        if (isNaN(fechaVencimiento.getTime())) {
                            throw new Error('Fecha calculada es inválida');
                        }
                    } catch (eInterna) {
                        console.warn('Error al sumar meses, ignorando:', eInterna);
                        // Continuar con la fecha sin sumar meses
                    }
                }
                
                // Convertir a string de forma defensiva
                let textoVencimiento = '00/00/0000';
                try {
                    textoVencimiento = fechaVencimiento.toLocaleDateString();
                } catch (eFormat) {
                    console.warn('Error al formatear fecha:', eFormat);
                }
                
                const vencElement = document.getElementById('fac-venc');
                if (vencElement) {
                    vencElement.textContent = textoVencimiento;
                }
            } catch (eExterna) {
                console.error('Error crítico en updateVencimiento (esto no debería ocurrir):', eExterna);
                const vencElement = document.getElementById('fac-venc');
                if (vencElement) {
                    vencElement.textContent = '00/00/0000';
                }
            }
        }

        // --- LÓGICA DE PERSISTENCIA (GUARDAR Y CARGAR DATOS) ---

        // Recopila todos los datos del formulario del modal y los empaqueta en un objeto JavaScript.
        function getFacturaData() {
            const items = [];
            document.querySelectorAll('#fac-items tr').forEach(tr => {
                items.push({
                    descripcion: tr.querySelector('.desc').value,
                    cantidad: tr.querySelector('.cant').value,
                    precio: tr.querySelector('.precio').value,
                });
            });

            const firmaSrc = document.getElementById('firma-preview').src;

            return {
                id: document.getElementById('modal-factura').dataset.facturaId || null,
                numero: document.getElementById('fac-num').textContent,
                fecha: document.getElementById('fac-fecha').textContent,
                vencimiento: document.getElementById('fac-venc').textContent,
                cuotas: document.getElementById('fac-cuotas').value,
                cliente: {
                    nombre: document.getElementById('para-nombre').value,
                    apellido: document.getElementById('para-apellido').value,
                    rut: document.getElementById('para-rut').value,
                    fono: document.getElementById('para-fono').value,
                    vin: document.getElementById('para-vin').value,
                    motor: document.getElementById('para-motor').value,
                    matricula: document.getElementById('para-matricula').value,
                },
                vehiculo: {
                    estado: document.getElementById('veh-estado-select').value,
                    mecanico: document.getElementById('veh-mecanico').textContent,
                    comentario: document.getElementById('veh-comentario').value,
                },
                items: items,
                firma: firmaSrc.startsWith('data:image') ? firmaSrc : null, // Solo guardar si es una imagen cargada
            };
        }

        // Evento para el botón "Guardar".
        document.getElementById('btn-guardar-fac')?.addEventListener('click', async function() {
            await saveFactura();
        });

        // Evento para el botón "Imprimir". Primero guarda los cambios y luego abre el diálogo de impresión.
        document.getElementById('btn-imprimir-fac')?.addEventListener('click', async function(){
            await saveFactura();
            prepareForPrint();
            window.print();
        });

        // Lógica para controlar los saltos de página antes de imprimir.
        function prepareForPrint() {
            const itemsTbody = document.getElementById('fac-items');
            const itemRows = itemsTbody.querySelectorAll('.item-row');
            const itemCount = itemRows.length;
            const itemsSection = document.querySelector('.items-section');

            // Limpiar clases de la ejecución anterior
            cleanupPrintClasses();

            if (itemCount > 4 && itemCount <= 8) {
                // Si hay entre 5 y 8 items, el salto va después de la tabla de items.
                itemsSection.classList.add('print-break-after');
            } else if (itemCount > 8) {
                // Si hay más de 8, el salto va después del 8vo item.
                const eighthRow = itemRows[7]; // Los arrays son base 0, así que el 8vo es el índice 7
                if (eighthRow) {
                    eighthRow.classList.add('print-break-after');
                }
            }
        }

        // Limpia las clases de salto de página después de imprimir o cancelar.
        function cleanupPrintClasses() {
            document.querySelectorAll('.print-break-after').forEach(el => el.classList.remove('print-break-after'));
        }

        // Listener para limpiar las clases después de que el diálogo de impresión se cierre.
        window.addEventListener('afterprint', cleanupPrintClasses);


        // Función asíncrona que envía los datos de la factura al servidor (save_factura.php) usando fetch.
        async function saveFactura() {
            const data = getFacturaData();
            if (!data.cliente.nombre) {
                alert('Por favor, ingrese el nombre del cliente.');
                return;
            }
            try {
                const res = await fetch('save_factura.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const json = await res.json();
                if (json.success) {
                    alert('Factura guardada correctamente.');
                    document.getElementById('modal-factura').dataset.facturaId = json.id; // Guardar el ID para futuras ediciones
                    document.getElementById('fac-num').textContent = 'N° ' + json.id; // Actualizar el número de factura con el ID real
                    renderFacturas(); // Actualizar la lista
                } else {
                    alert('Error al guardar: ' + (json.error || 'desconocido'));
                }
            } catch (e) {
                alert('Error de red al guardar la factura: ' + e.message);
            }
        }

        // Carga la lista de facturas desde el servidor y las renderiza en la tabla principal.
        async function renderFacturas() {
            const urlParams = new URLSearchParams(window.location.search);
            const rawSearchQuery = urlParams.get('q') || '';

            const tbody = document.getElementById('listado-facturas');
            tbody.innerHTML = '<tr><td colspan="6" class="text-center p-4">Cargando...</td></tr>';
            try {
                // Pide las facturas al servidor. El backend (save_factura.php) decide si devuelve todas (admin) o solo las del usuario (mecánico).
                const scope = esAdmin ? 'all' : 'user';
                const res = await fetch(`save_factura.php?scope=${scope}`);
                const json = await res.json();
                if (!json.success) throw new Error(json.error);

                // Filtra las facturas que han sido marcadas como borradas (soft delete).
                const facturasVisibles = json.lista.filter(factura => factura.cliente?.nombre !== 'Borrado_x');

                let facturasFiltradas = facturasVisibles;
                // Si hay un término de búsqueda en la URL, filtra los resultados.
                if (rawSearchQuery) {
                    const searchQuery = rawSearchQuery.toLowerCase();
                    // Limpiar búsqueda para número de factura
                    const searchQueryNum = searchQuery.replace(/n°/g, '').trim();

                    facturasFiltradas = facturasVisibles.filter(factura => {
                        const id = String(factura.id);
                        const nombre = factura.cliente?.nombre?.toLowerCase() || '';
                        const creadorRut = factura.creado_por_rut?.toLowerCase() || '';
                        return id.includes(searchQueryNum) || nombre.includes(searchQuery) || creadorRut.includes(searchQuery);
                    });
                }

                tbody.innerHTML = '';
                // Muestra un mensaje si no hay facturas que mostrar.
                if (facturasFiltradas.length === 0) {
                    const message = rawSearchQuery ? `No se encontraron facturas para "${urlParams.get('q')}".` : 'No hay facturas guardadas.';
                    tbody.innerHTML = `<tr><td colspan="6" class="text-center p-4">${message}</td></tr>`;
                    return;
                }

                facturasFiltradas.forEach(factura => {
                    // Sanity check: Omitir facturas con datos corruptos o incompletos para evitar errores de renderizado.
                    if (!factura || typeof factura.id === 'undefined' || !factura.items || !Array.isArray(factura.items)) {
                        console.warn('Omitiendo factura por datos incompletos:', factura);
                        return; // Saltar a la siguiente factura
                    }

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-2">N° ${factura.id}</td>
                        <td class="px-4 py-2">${(factura.cliente?.nombre || '') + ' ' + (factura.cliente?.apellido || '') || 'Sin cliente'}</td>
                        <td class="px-4 py-2">${factura.creado_por_rut || 'N/A'}</td>
                        <td class="px-4 py-2">${factura.fecha || 'N/A'}</td>
                        <td class="px-4 py-2 font-mono">$ ${fmt(factura.items.reduce((total, item) => total + (item.cantidad * item.precio) * 1.21, 0))}</td>
                        <td class="px-4 py-2 text-center no-print flex items-center justify-center gap-2">
                            <button class="btn-ver-fac px-3 py-1 bg-gray-200 text-sm rounded hover:bg-gray-300" data-factura-id="${factura.id}">Ver/editar</button>
                            <button class="btn-borrar-fac px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600" data-factura-id="${factura.id}">Borrar</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="6" class="text-center p-4 text-red-500">Error al cargar facturas: ${e.message}</td></tr>`;
            }
        }

        // Listener en la tabla para delegación de eventos (clicks en "Ver/Editar" y "Borrar").
        document.getElementById('listado-facturas').addEventListener('click', async function(e) {
            const botonVer = e.target.closest('.btn-ver-fac');
            const botonBorrar = e.target.closest('.btn-borrar-fac');
            if (botonVer) {
                const id = botonVer.dataset.facturaId;
                await cargarFacturaEnModal(id); // Espera a que los datos se carguen
                document.getElementById('modal-factura').classList.remove('hidden'); // Muestra el modal
                document.getElementById('modal-factura').style.display = 'flex'; // Asegura que sea visible
            } else if (botonBorrar) {
                // Lógica para el borrado suave (soft delete) de una factura.
                const id = botonBorrar.dataset.facturaId;
                if (confirm(`¿Estás seguro de que quieres borrar la factura N° ${id}? Esta acción no se puede deshacer.`)) {
                    try {
                        const res = await fetch('save_factura.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                id: id,
                                cliente: { nombre: 'Borrado_x' },
                                isSoftDelete: true
                            })
                        });
                        const json = await res.json();
                        if (json.success) {
                            alert('Factura borrada correctamente.');
                            renderFacturas(); // Actualizar la lista para que desaparezca
                        } else {
                            alert('Error al borrar la factura: ' + (json.error || 'desconocido'));
                        }
                    } catch (error) {
                        alert('Error de red al intentar borrar la factura: ' + error.message);
                    }
                }
            }
        });

        // Carga los datos de una factura por ID en el modal. Devuelve una promesa.
        async function cargarFacturaEnModal(id) {
            try {
                // Mostrar modal con la info de la factura
                console.log('=== INICIANDO CARGA DE FACTURA ID:', id, '===');
                // Pide los datos completos de una factura específica al servidor.
                const res = await fetch(`save_factura.php?id=${id}`);
                console.log('Response status:', res.status, res.ok);
                
                let jsonText = await res.text();
                console.log('Response text (primeros 200 chars):', jsonText.substring(0, 200));
                
                let json;
                try {
                    json = JSON.parse(jsonText);
                    console.log('JSON parseado exitosamente');
                } catch (eJSON) {
                    console.error('ERROR al parsear JSON:', eJSON);
                    console.error('Texto raw:', jsonText);
                    throw new Error('JSON inválido del servidor');
                }
                
                console.log('JSON.success:', json.success, 'JSON.factura exists:', !!json.factura);
                
                if (json.success && json.factura) {
                    const factura = json.factura;
                    console.log('Factura cargada, iniciando poblado del formulario');
                    // Limpia el formulario y luego lo puebla con los datos recibidos.
                    clearFacForm();

                    // Cargar firma si existe
                    if (factura.firma) {
                        document.getElementById('firma-preview').src = factura.firma;
                        document.getElementById('firma-preview').classList.remove('hidden');
                        document.getElementById('firma-placeholder').classList.add('hidden');
                    }

                    document.getElementById('modal-factura').dataset.facturaId = factura.id;
                    
                    // Parsear fecha de forma defensiva
                    try { // Intenta parsear la fecha de la factura para establecer la fecha de emisión base.
                        console.log('Iniciando parsing de fecha:', factura.fecha);
                        const fechaStr = String(factura.fecha || '');
                        console.log('fechaStr después de String():', fechaStr, 'type:', typeof fechaStr);
                        
                        let fechaParts = [];
                        let fechaParseadaExitosa = false;
                        
                        // Intentar split con barras
                        if (fechaStr.includes('/')) {
                            fechaParts = fechaStr.split('/');
                            console.log('Split con /, resultado:', fechaParts);
                        } else if (fechaStr.includes('-')) {
                            // Intentar split con guiones
                            fechaParts = fechaStr.split('-');
                            console.log('Split con -, resultado:', fechaParts);
                        } else {
                            console.warn('Fecha no contiene / ni -:', fechaStr);
                        }
                        
                        if (fechaParts.length === 3) {
                            const dia = parseInt(fechaParts[0], 10);
                            const mes = parseInt(fechaParts[1], 10);
                            const año = parseInt(fechaParts[2], 10);
                            
                            console.log('Valores parseados: dia=' + dia + ', mes=' + mes + ', año=' + año);
                            
                            // Validar rango
                            if (dia > 0 && dia <= 31 && mes > 0 && mes <= 12 && año > 1900 && año < 2100) {
                                console.log('Valores dentro de rango, creando Date(' + año + ', ' + (mes - 1) + ', ' + dia + ')');
                                const fechaEmisionObj = new Date(año, mes - 1, dia);
                                console.log('Date creado:', fechaEmisionObj.toString());
                                
                                // Validar que la fecha sea válida
                                if (fechaEmisionObj && !isNaN(fechaEmisionObj.getTime())) {
                                    console.log('Fecha válida, convertiendo a ISO...');
                                    const isoStr = fechaEmisionObj.toISOString();
                                    console.log('ISO generado:', isoStr);
                                    document.getElementById('modal-factura').dataset.fechaEmision = isoStr;
                                    fechaParseadaExitosa = true;
                                } else {
                                    console.error('Date.getTime() es NaN');
                                }
                            } else {
                                console.warn('Valores fuera de rango: dia=' + dia + ', mes=' + mes + ', año=' + año);
                            }
                        } else {
                            console.warn('fechaParts.length es ' + fechaParts.length + ', esperaba 3');
                        }
                        
                        if (!fechaParseadaExitosa) {
                            console.warn('Parsing falló, usando fecha de hoy como fallback');
                            const fallbackDate = new Date();
                            const fallbackISO = fallbackDate.toISOString();
                            console.log('Fecha fallback:', fallbackISO);
                            document.getElementById('modal-factura').dataset.fechaEmision = fallbackISO;
                        }
                    } catch (eParsingFecha) {
                        console.error('EXCEPCIÓN en parsing de fecha:', eParsingFecha);
                        console.error('Stack:', eParsingFecha.stack);
                        const fallbackDate = new Date();
                        document.getElementById('modal-factura').dataset.fechaEmision = fallbackDate.toISOString();
                    }

                    // Puebla todos los campos del formulario con los datos de la factura.
                    document.getElementById('fac-num').textContent = 'N° ' + factura.id;
                    document.getElementById('fac-fecha').textContent = factura.fecha;
                    document.getElementById('para-nombre').value = factura.cliente?.nombre || '';
                    document.getElementById('para-apellido').value = factura.cliente?.apellido || '';
                    document.getElementById('para-rut').value = factura.cliente?.rut || '';
                    document.getElementById('para-fono').value = factura.cliente?.fono || '';
                    document.getElementById('para-vin').value = factura.cliente?.vin || '';
                    document.getElementById('para-motor').value = factura.cliente?.motor || '';
                    document.getElementById('para-matricula').value = factura.cliente?.matricula || '';
                    document.getElementById('veh-estado-select').value = factura.vehiculo?.estado || '';
                    document.getElementById('veh-comentario').value = factura.vehiculo?.comentario || '';

                    const tbody = document.getElementById('fac-items');
                    document.getElementById('fac-cuotas').value = factura.cuotas || '1';
                    
                    tbody.innerHTML = '';
                    // Crea dinámicamente las filas de items.
                    if (factura.items && Array.isArray(factura.items)) {
                        factura.items.forEach(item => {
                            const tr = document.createElement('tr');
                            tr.className = 'border-b item-row';
                            tr.innerHTML = `
                                <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value="${item.descripcion || ''}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="${item.cantidad || 0}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="${item.precio || 0}"></td>
                                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0</span></td>
                            `;
                            tbody.appendChild(tr);
                            attachFacListeners(tr);
                        });
                    }
                    
                    updateFacTotals();
                    updateVencimiento();
                } else {
                    throw new Error(json.error || 'No se pudo cargar la factura');
                }
            } catch (e) {
                alert('Error al cargar factura:\n' + e.message + '\n\nMira la consola (F12) para más detalles');
                console.error('Error crítico al cargar factura:', e);
                throw e; // Rechaza la promesa para que el llamador sepa que falló.
            }
        }

        // Carga los datos de una factura por ID en el modal. Devuelve una promesa.
        async function cargarFacturaEnModal(id) {
            try {
                // Mostrar modal con la info de la factura
                console.log('=== INICIANDO CARGA DE FACTURA ID:', id, '===');
                // Pide los datos completos de una factura específica al servidor.
                const res = await fetch(`save_factura.php?id=${id}`);
                console.log('Response status:', res.status, res.ok);
                
                let jsonText = await res.text();
                console.log('Response text (primeros 200 chars):', jsonText.substring(0, 200));
                
                let json;
                try {
                    json = JSON.parse(jsonText);
                    console.log('JSON parseado exitosamente');
                } catch (eJSON) {
                    console.error('ERROR al parsear JSON:', eJSON);
                    console.error('Texto raw:', jsonText);
                    throw new Error('JSON inválido del servidor');
                }
                
                console.log('JSON.success:', json.success, 'JSON.factura exists:', !!json.factura);
                
                if (json.success && json.factura) {
                    const factura = json.factura;
                    console.log('Factura cargada, iniciando poblado del formulario');
                    // Limpia el formulario y luego lo puebla con los datos recibidos.
                    clearFacForm();

                    // Cargar firma si existe
                    if (factura.firma) {
                        document.getElementById('firma-preview').src = factura.firma;
                        document.getElementById('firma-preview').classList.remove('hidden');
                        document.getElementById('firma-placeholder').classList.add('hidden');
                    }

                    document.getElementById('modal-factura').dataset.facturaId = factura.id;
                    
                    // Parsear fecha de forma defensiva
                    try { // Intenta parsear la fecha de la factura para establecer la fecha de emisión base.
                        console.log('Iniciando parsing de fecha:', factura.fecha);
                        const fechaStr = String(factura.fecha || '');
                        console.log('fechaStr después de String():', fechaStr, 'type:', typeof fechaStr);
                        
                        let fechaParts = [];
                        let fechaParseadaExitosa = false;
                        
                        // Intentar split con barras
                        if (fechaStr.includes('/')) {
                            fechaParts = fechaStr.split('/');
                            console.log('Split con /, resultado:', fechaParts);
                        } else if (fechaStr.includes('-')) {
                            // Intentar split con guiones
                            fechaParts = fechaStr.split('-');
                            console.log('Split con -, resultado:', fechaParts);
                        } else {
                            console.warn('Fecha no contiene / ni -:', fechaStr);
                        }
                        
                        if (fechaParts.length === 3) {
                            const dia = parseInt(fechaParts[0], 10);
                            const mes = parseInt(fechaParts[1], 10);
                            const año = parseInt(fechaParts[2], 10);
                            
                            console.log('Valores parseados: dia=' + dia + ', mes=' + mes + ', año=' + año);
                            
                            // Validar rango
                            if (dia > 0 && dia <= 31 && mes > 0 && mes <= 12 && año > 1900 && año < 2100) {
                                console.log('Valores dentro de rango, creando Date(' + año + ', ' + (mes - 1) + ', ' + dia + ')');
                                const fechaEmisionObj = new Date(año, mes - 1, dia);
                                console.log('Date creado:', fechaEmisionObj.toString());
                                
                                // Validar que la fecha sea válida
                                if (fechaEmisionObj && !isNaN(fechaEmisionObj.getTime())) {
                                    console.log('Fecha válida, convertiendo a ISO...');
                                    const isoStr = fechaEmisionObj.toISOString();
                                    console.log('ISO generado:', isoStr);
                                    document.getElementById('modal-factura').dataset.fechaEmision = isoStr;
                                    fechaParseadaExitosa = true;
                                } else {
                                    console.error('Date.getTime() es NaN');
                                }
                            } else {
                                console.warn('Valores fuera de rango: dia=' + dia + ', mes=' + mes + ', año=' + año);
                            }
                        } else {
                            console.warn('fechaParts.length es ' + fechaParts.length + ', esperaba 3');
                        }
                        
                        if (!fechaParseadaExitosa) {
                            console.warn('Parsing falló, usando fecha de hoy como fallback');
                            const fallbackDate = new Date();
                            const fallbackISO = fallbackDate.toISOString();
                            console.log('Fecha fallback:', fallbackISO);
                            document.getElementById('modal-factura').dataset.fechaEmision = fallbackISO;
                        }
                    } catch (eParsingFecha) {
                        console.error('EXCEPCIÓN en parsing de fecha:', eParsingFecha);
                        console.error('Stack:', eParsingFecha.stack);
                        const fallbackDate = new Date();
                        document.getElementById('modal-factura').dataset.fechaEmision = fallbackDate.toISOString();
                    }

                    // Puebla todos los campos del formulario con los datos de la factura.
                    document.getElementById('fac-num').textContent = 'N° ' + factura.id;
                    document.getElementById('fac-fecha').textContent = factura.fecha;
                    document.getElementById('para-nombre').value = factura.cliente?.nombre || '';
                    document.getElementById('para-apellido').value = factura.cliente?.apellido || '';
                    document.getElementById('para-rut').value = factura.cliente?.rut || '';
                    document.getElementById('para-fono').value = factura.cliente?.fono || '';
                    document.getElementById('para-vin').value = factura.cliente?.vin || '';
                    document.getElementById('para-motor').value = factura.cliente?.motor || '';
                    document.getElementById('para-matricula').value = factura.cliente?.matricula || '';
                    document.getElementById('veh-estado-select').value = factura.vehiculo?.estado || '';
                    document.getElementById('veh-comentario').value = factura.vehiculo?.comentario || '';

                    const tbody = document.getElementById('fac-items');
                    document.getElementById('fac-cuotas').value = factura.cuotas || '1';
                    
                    tbody.innerHTML = '';
                    // Crea dinámicamente las filas de items.
                    if (factura.items && Array.isArray(factura.items)) {
                        factura.items.forEach(item => {
                            const tr = document.createElement('tr');
                            tr.className = 'border-b item-row';
                            tr.innerHTML = `
                                <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value="${item.descripcion || ''}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="${item.cantidad || 0}"></td>
                                <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="${item.precio || 0}"></td>
                                <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0</span></td>
                            `;
                            tbody.appendChild(tr);
                            attachFacListeners(tr);
                        });
                    }
                    
                    updateFacTotals();
                    updateVencimiento();
                } else {
                    throw new Error(json.error || 'No se pudo cargar la factura');
                }
            } catch (e) {
                alert('Error al cargar factura:\n' + e.message + '\n\nMira la consola (F12) para más detalles');
                console.error('Error crítico al cargar factura:', e);
                throw e; // Rechaza la promesa para que el llamador sepa que falló.
            }
        }

        // Resetea el formulario del modal a su estado inicial.
        function clearFacForm() {
            document.getElementById('modal-factura').dataset.facturaId = '';
            document.getElementById('modal-factura').dataset.fechaEmision = '';
            document.getElementById('factura-printable').querySelectorAll('input, textarea, select').forEach(el => el.value = '');
            document.getElementById('fac-items').innerHTML = `
                <tr class="border-b item-row">
                    <td class="px-3 py-2"><input class="w-full p-2 border border-gray-200 rounded-md desc" value=""></td>
                    <td class="px-3 py-2"><input type="number" min="0" step="1" class="w-20 p-2 border border-gray-200 rounded-md cant" value="0"></td>
                    <td class="px-3 py-2"><input type="number" min="0" step="0.01" class="w-32 p-2 border border-gray-200 rounded-md precio" value="0"></td>
                    <td class="px-3 py-2 text-right importe"><span class="importe-val">$ 0</span></td>
                </tr>
            `;
            attachFacListeners(document.querySelector('#fac-items tr'));
            updateFacTotals();
            document.getElementById('fac-cuotas').value = '1';
            updateVencimiento();
            // Limpiar firma
            document.getElementById('firma-input').value = '';
            document.getElementById('firma-preview').classList.add('hidden');
            document.getElementById('firma-placeholder').classList.remove('hidden');
        }

        // --- INICIALIZACIÓN ---
        // Carga la lista de facturas en cuanto la página está lista.
        renderFacturas();

        // Listener global para cerrar el modal con la tecla "Escape".
        document.addEventListener('keydown', function(e){ if (e.key==='Escape'){ const m=document.getElementById('modal-factura'); if (m && !m.classList.contains('hidden')){ m.classList.add('hidden'); m.style.display='none'; } } });
    </script>

<?php include 'footer.php' ?>