<?php 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 


?>
    <main>
        <section class="max-w-4xl mx-auto my-8 px-4">

            <!-- Barra de búsqueda + agregar -->
            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <label for="buscar" class="font-semibold mr-2">Buscar:</label>

                <div class="flex items-center gap-2 w-full md:w-auto">
                    <input id="buscar" type="text" placeholder="Escribe para filtrar..." class="w-full md:w-80 p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sky-300" />

                    <button id="btn-buscar" class="bg-white border border-gray-200 p-2 rounded-md hover:shadow-sm" title="Buscar">
                        <img src="media/lupa.webp" alt="Buscar" class="w-5 h-5" />
                    </button>
                </div>

                <div class="mt-3 md:mt-0 md:ml-auto">
                    <button id="btn-agregar-inv" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow">Agregar Producto</button>
                </div>
            </div>

            <!-- Tabla de inventario -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Producto</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Cantidad</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Precio Compra</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Precio Venta</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Año</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Proveedor</th>
                            <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Acciones</th>
                        </tr>
                    </thead>

                    <tbody id="listado-inventario" class="bg-white divide-y divide-gray-100">
                        <!-- Productos cargados dinámicamente -->
                    </tbody>
                </table>
            </div>

        </section>

        <!-- Modal Inventario -->
        <div id="modal-inventario" class="modal-inv fixed inset-0 z-50 hidden items-center justify-center bg-black/50">
            <div class="modal-content-inv bg-white rounded-lg p-6 w-full max-w-3xl mx-4">

                <h3 class="mb-4 text-center text-lg font-semibold">Agregar Producto</h3>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                    <div class="flex flex-col gap-2">
                        <label class="text-sm font-medium">Nombre Producto</label>
                        <input class="p-2 border rounded" type="text" id="inv-nombre">

                        <label class="text-sm font-medium">Marca</label>
                        <input class="p-2 border rounded" type="text" id="inv-marca">

                        <label class="text-sm font-medium">Cantidad</label>
                        <input class="p-2 border rounded" type="number" id="inv-cantidad">

                        <label class="text-sm font-medium">Año</label>
                        <input class="p-2 border rounded" type="number" id="inv-anio">
                    </div>

                    <div class="flex flex-col gap-2">
                        <label class="text-sm font-medium">Precio Compra</label>
                        <input class="p-2 border rounded" type="number" id="inv-precio-compra">

                        <label class="text-sm font-medium">Precio Venta</label>
                        <input class="p-2 border rounded" type="number" id="inv-precio-venta">

                        <label class="text-sm font-medium">Fecha de Compra</label>
                        <input class="p-2 border rounded" type="date" id="inv-fecha-compra">

                        <label class="text-sm font-medium">Proveedor</label>
                        <input class="p-2 border rounded" type="text" id="inv-provedor">
                    </div>

                    <div class="md:col-span-2 flex flex-col gap-2">
                        <label class="text-sm font-medium">Descripción</label>
                        <input class="p-2 border rounded w-full" type="text" id="inv-descripcion">
                    </div>

                    <div class="md:col-span-2 text-center mt-4">
                        <button id="inv-guardar" class="btn-inv px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded mr-2">Agregar</button>
                        <button id="inv-cancelar" class="btn-inv cancelar px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded mr-2">Cancelar</button>
                        <button id="inv-limpiar" class="btn-inv limpiar px-4 py-2 bg-yellow-400 hover:bg-yellow-500 rounded">Limpiar</button>
                    </div>

                </div>

            </div>
        </div>
    </main>
    
<?php include 'footer.php' ?>