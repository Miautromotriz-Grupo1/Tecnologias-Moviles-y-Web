<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['rut'])) {
    header("Location: index.php");
    exit(); 
}

include 'header.php'; 
?>
<main class="flex-grow flex items-center justify-center px-4 relative ">

    <div class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl w-full max-w-lg p-8 sm:p-10 transition-colors duration-300 relative z-10">
        
        <div class="text-center mb-8">
            <h2 class="text-3xl text-skin-muted font-bold mb-2 tracking-tight">Crear Cuenta</h2>
            <p class="text-skin-muted text-sm">Únete a MIAUtomotriz en segundos</p>
            <?php if(isset($_SESSION['error_registro'])): ?>
                    <span class="absolute left-1/4 right-1/4 inline-block items-center  text-xs rounded  text-red-700 border border-red-700">
                        <?php echo ($_SESSION['error_registro']);?>
                    </span>
                    <?php unset($_SESSION['error_registro']);?>
            <?php endif; ?>
        </div>

        <form action="registerval.php" method="post" class="space-y-5">
            
            <div class="relative group">
                <label for="rut" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">RUT</label>
                <input type="text" id="rut" name="rut" placeholder="12345678-9" required
                    class="w-full  px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div class="relative group">
                    <label for="nombre" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Nombre</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
                </div>
                <div class="relative group">
                    <label for="apellido" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Apellido</label>
                    <input type="text" id="apellido" name="apellido" placeholder="Tu apellido" required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
                </div>
            </div>

            <div class="relative group">
                <label for="email" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Correo Electrónico</label>
                <input type="email" id="email" name="email" placeholder="ejemplo@correo.com" required
                    class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
            </div>

            <div class="relative group">
                <label for="password" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Contraseña</label>
                <div class="relative">
                    <input type="password" id="password" name="password" placeholder="••••••••" required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
                    <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-skin-muted hover:text-skin-accent transition-colors font-semibold focus:outline-none">
                        <span id="toggleText">Mostrar</span>
                    </button>
                </div>
            </div>

            <div class="relative group">
                <label for="password-repeat" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Repetir Contraseña</label>
                <div class="relative">
                    <input type="password" id="password-repeat" name="password-repeat" placeholder="••••••••" required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all">
                    <button type="button" onclick="togglePassword_repeat()" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-skin-muted hover:text-skin-accent transition-colors font-semibold focus:outline-none">
                        <span id="toggleText_repeat">Mostrar</span>
                    </button>
                </div>
            </div>

            <button type="submit" class="w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 mt-2">
                Registrarse
            </button>

            <div class="text-center text-sm mt-6">
                <p class="text-skin-muted">
                    ¿Ya tienes una cuenta? 
                    <a href="login.php" class="text-skin-accent font-bold hover:underline hover:text-skin-accent-hover transition-colors">Inicia sesión aquí</a>
                </p>
            </div>
        </form>
    </div>

</main>

<?php include 'footer.php' ?>