// Producto: carga, render y gestión CRUD
// Depende de globals: isAdmin, agregarAlCarrito (definidos en script.js / header.php)

(function(){
    // --- 1. Inyección del HTML del Modal ---
    const modalHTML = `
    <div id="modal-producto" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
        <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <div class="relative transform overflow-hidden rounded-lg bg-skin-card text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg border border-skin-border">
                <div class="px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                    <h3 class="text-xl font-semibold leading-6 text-skin-muted mb-4" id="modal-title">Administrar Producto</h3>
                    <form id="form-producto" class="space-y-4">
                        <input type="hidden" id="prod-id">
                        <div>
                            <label class="block text-sm font-medium text-skin-muted">Nombre *</label>
                            <input type="text" id="prod-nombre" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 bg-skin-base text-skin-muted border" required>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-skin-muted">Precio *</label>
                                <input type="number" id="prod-precio" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 bg-skin-base text-skin-muted border" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-skin-muted">Año (opcional)</label>
                                <input type="number" id="prod-anio" placeholder="Ej: 2025" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 bg-skin-base text-skin-muted border">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-skin-muted">Marca (opcional)</label>
                            <input type="text" id="prod-marca" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 bg-skin-base text-skin-muted border">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-skin-muted">URL Imagen</label>
                            <input type="text" id="prod-img" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 bg-skin-base text-skin-muted border">
                        </div>
                    </form>
                </div>
                <div class="bg-skin-header px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                    <button type="button" id="btn-save-modal" class="inline-flex w-full justify-center rounded-md bg-skin-accent px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-opacity-90 sm:ml-3 sm:w-auto">Guardar</button>
                    <button type="button" id="btn-close-modal" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto">Cancelar</button>
                </div>
            </div>
        </div>
    </div>`;

    if (!document.getElementById('modal-producto')) {
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    // --- 2. Funciones del Modal ---
    const modal = document.getElementById('modal-producto');
    const form = document.getElementById('form-producto');
    const btnSave = document.getElementById('btn-save-modal');
    const btnClose = document.getElementById('btn-close-modal');

    function openModal(data = null) {
        modal.classList.remove('hidden');
        if (data) {
            document.getElementById('modal-title').textContent = 'Editar Producto';
            document.getElementById('prod-id').value = data.id || '';
            document.getElementById('prod-nombre').value = data.nombre || '';
            document.getElementById('prod-precio').value = data.precio || '';
            document.getElementById('prod-marca').value = data.marca || '';
            document.getElementById('prod-anio').value = data.anio || '';
            document.getElementById('prod-img').value = data.img || '';
        } else {
            document.getElementById('modal-title').textContent = 'Nuevo Producto';
            form.reset();
            document.getElementById('prod-id').value = '';
        }
    }

    function closeModal() {
        modal.classList.add('hidden');
    }

    if (btnClose) btnClose.addEventListener('click', closeModal);

    // --- 3. Lógica de Guardado (Fetch) ---
    if (btnSave) {
        btnSave.addEventListener('click', async function() {
            const id = document.getElementById('prod-id').value;
            const nombre = document.getElementById('prod-nombre').value.trim();
            const precio = parseInt(document.getElementById('prod-precio').value) || 0;
            const marca = document.getElementById('prod-marca').value.trim();
            const anio = document.getElementById('prod-anio').value.trim();
            const img = document.getElementById('prod-img').value.trim() || 'https://via.placeholder.com/300?text=Sin+Imagen';

            if (!nombre || precio <= 0) {
                alert('Por favor ingresa un nombre y un precio válido.');
                return;
            }

            const method = id ? 'PUT' : 'POST';
            const payload = { id, nombre, precio, marca, anio, img };

            try {
                const res = await fetch('save_producto.php', {
                    method: method,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();

                if (data.success) {
                    closeModal();
                    window.location.reload(); 
                } else {
                    alert('Error: ' + data.error);
                }
            } catch (err) {
                console.error(err);
                alert('Error de conexión al guardar.');
            }
        });
    }

    // --- 4. Renderizado de Productos (Listeners) ---
    window.renderProductos = async function() {
        const container = document.getElementById('productos-container');
        if (!container) return;
        
        const cards = container.querySelectorAll('.bg-skin-card');
        
        cards.forEach(card => {
            // Botón Agregar al Carrito
            const addBtn = card.querySelector('.add-to-cart');
            if (addBtn && !addBtn._hasHandler) {
                addBtn.addEventListener('click', function() {
                    const nombre = this.dataset.nombre;
                    const precio = parseInt(this.dataset.precio);
                    if (typeof window.agregarAlCarrito === 'function') {
                        window.agregarAlCarrito({ nombre, precio });
                    }
                });
                addBtn._hasHandler = true;
            }

            // Botón Editar (Admin)
            const editBtn = card.querySelector('.editar-btn');
            if (editBtn && !editBtn._hasHandler) {
                editBtn.addEventListener('click', function() {
                    const prodDiv = this.closest('.bg-skin-card');
                    const data = {
                        id: prodDiv.dataset.id,
                        nombre: prodDiv.querySelector('h3').textContent.trim(),
                        precio: prodDiv.querySelector('p').textContent.replace(/[^0-9]/g, ''),
                        marca: prodDiv.querySelector('.prod-marca') ? prodDiv.querySelector('.prod-marca').textContent : '',
                        // Limpiamos el texto del año para dejar solo números
                        anio: prodDiv.querySelector('.prod-anio') ? prodDiv.querySelector('.prod-anio').textContent.replace(/[^0-9]/g, '') : '',
                        img: prodDiv.querySelector('img').src
                    };
                    openModal(data);
                });
                editBtn._hasHandler = true;
            }

            // Botón Borrar (Admin)
            const delBtn = card.querySelector('.borrar-btn');
            if (delBtn && !delBtn._hasHandler) {
                delBtn.addEventListener('click', async function() {
                    if (!confirm('¿Eliminar este producto permanentemente?')) return;
                    
                    const prodDiv = this.closest('.bg-skin-card');
                    const id = prodDiv.dataset.id;
                    
                    try {
                        const res = await fetch(`save_producto.php?id=${id}`, { method: 'DELETE' });
                        const data = await res.json();
                        if (data.success) {
                            prodDiv.remove();
                        } else {
                            alert('Error: ' + data.error);
                        }
                    } catch (e) {
                        alert('Error de red al eliminar');
                    }
                });
                delBtn._hasHandler = true;
            }
        });
    };

    // --- 5. Inicialización ---
    document.addEventListener('DOMContentLoaded', () => {
        window.renderProductos();

        // AQUÍ ESTABA EL ERROR:
        // Eliminamos la lógica que ocultaba el botón. Confiamos 100% en PHP.
        const mainAddBtn = document.getElementById('add-product-btn');
        if (mainAddBtn) {
            // Clonamos para limpiar eventos anteriores
            const newBtn = mainAddBtn.cloneNode(true);
            mainAddBtn.parentNode.replaceChild(newBtn, mainAddBtn);
            
            newBtn.addEventListener('click', (e) => {
                e.preventDefault();
                openModal(); // Solo abrir modal
            });
            // ELIMINADO: if (!window.isAdmin) newBtn.style.display = 'none';
        }
    });

})();