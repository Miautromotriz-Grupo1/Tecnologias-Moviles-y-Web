<?php 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 

?>
    <main>

        <section class="max-w-6xl mx-auto my-8 px-4">

            <!-- Barra de búsqueda + agregar -->



            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <label for="buscar" class="font-semibold mr-2">Buscar:</label>

                <div class="flex items-center gap-2 w-full md:w-auto">
                    <input id="buscar" type="text" placeholder="Escribe para filtrar..." class="w-full md:w-80 p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sky-300" />

                    <button id="btn-buscar" class="bg-white border border-gray-200 p-2 rounded-md hover:shadow-sm" title="Buscar">
                        <img src="media/lupa.webp" alt="Buscar" class="w-5 h-5" />
                    </button>
                </div>

                <div class="mt-3 md:mt-0 md:ml-auto">
                    <button id="btn-agregar-inv" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow">Crear Presupuesto</button>
                </div>
            </div>

            <!-- Tabla de inventario -->
            <div class="overflow-x-auto bg-white rounded-md shadow">
                <table class="w-full table-auto divide-y divide-gray-200" aria-describedby="listado-presupuestos">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3 w-1/6">Cliente</th>
                            <th class="px-4 py-3 w-1/6">Rut</th>
                            <th class="px-4 py-3 w-1/5">Correo</th>
                            <th class="px-4 py-3 w-1/6">Contacto</th>
                            <th class="px-4 py-3 w-1/6">Fecha Realizada</th>
                            <th class="px-4 py-3">Total</th>
                            <th class="px-4 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="listado-presupuestos" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <!-- Productos cargados dinámicamente -->
                    </tbody>
                </table>
            </div>

        </section>

        <div id="modal-presupuesto" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 p-4">
            <div class="bg-white rounded-lg shadow-lg w-full max-w-4xl p-6 max-h-[90vh] overflow-auto">

               <!-- Encabezado + Imagen -->
                <div class="flex items-center gap-4 mb-3">
                    <div class="flex-shrink-0">
                        <div class="w-50 h-20">
                            <img src="media/logo.png" alt="Logo" class="w-full h-full object-contain"/>
                        </div>
                    </div>
                    <h2 class="text-xl font-semibold">Presupuesto mano de obra y materiales</h2>
                </div>
                <!-- Datos del cliente -->
                <h3 class="text-lg font-semibold mt-4">Datos del cliente</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    <div class="space-y-2">
                        <label class="block text-sm font-medium">Cliente</label>
                        <input type="text" id="pre-cliente" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">RUT</label>
                        <input type="text" id="pre-rut" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Correo</label>
                        <input type="email" id="pre-correo" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Dirección</label>
                        <input type="text" id="pre-direccion" class="w-full p-2 border rounded-md">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-sm font-medium">Fecha</label>
                        <input type="date" id="pre-fecha" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Numero de contacto 1</label>
                        <input type="text" id="pre-contacto1" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Numero de contacto 2</label>
                        <input type="text" id="pre-contacto2" class="w-full p-2 border rounded-md">
                    </div>
                </div>

                <div class="border-t my-4"></div>

                <!-- Datos del Vehiculo -->
                <h3 class="text-lg font-semibold mt-2">Información del vehiculo</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    <div class="space-y-2">
                        <label class="block text-sm font-medium">Marca</label>
                        <input type="text" id="pre-marca" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Modelo</label>
                        <input type="text" id="pre-modelo" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Año</label>
                        <input type="number" id="pre-anio" class="w-full p-2 border rounded-md">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-sm font-medium">Tipo</label>
                        <input type="text" id="pre-tipo" class="w-full p-2 border rounded-md">

                        <label class="block text-sm font-medium">Matricula</label>
                        <input type="text" id="pre-matricula" class="w-full p-2 border rounded-md">
                    </div>                  
                </div>

                <div class="border-t my-4"></div>

                <!-- Tabla de materiales -->
                <h3 class="text-lg font-semibold mt-2">Materiales, repuestos y trabajos</h3>

                <div class="mt-2 overflow-x-auto">
                    <table id="tabla-items" class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr class="text-left text-sm text-gray-700">
                                <th class="px-3 py-2">Descripción</th>
                                <th class="px-3 py-2">Cantidad</th>
                                <th class="px-3 py-2">Nota</th>
                                <th class="px-3 py-2">Valor neto</th>
                                <th class="px-3 py-2">Total neto</th>
                            </tr>
                        </thead>
                        <tbody id="items-body" class="bg-white divide-y divide-gray-100"></tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <button id="add-item" class="mt-2 px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded">Agregar Fila</button>
                </div>

                <!-- Totales -->
                 <div class="mt-4 space-y-1 text-right">
                    <p class="text-sm">SubTotal: <span class="font-medium">$<span id="pre-subtotal">0</span></span></p>
                    <p class="text-sm">IVA (19%): <span class="font-medium">$<span id="pre-iva">0</span></span></p>
                    <p class="text-lg font-semibold">Total (Iva incluido): <span id="pre-total">0</span></p>
                 </div>

                <!-- Botones -->
                <div class="text-right mt-6 space-x-2">
                    <button id="pre-guardar" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded">Guardar</button>
                    <button id="pre-cancelar" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded">Cancelar</button>
                    <button id="pre-limpiar" class="px-4 py-2 bg-yellow-400 hover:bg-yellow-500 rounded">Limpiar</button>
                </div>
            </div>
        </div>

    </main>
<!-- Vincular scripts externos: primero script.js (globals y UI general), luego producto.js (render productos) -->

    <!-- Autocalcular total de cada fila + subtotal + iva -->
    <script>
        function calcularTotales(){
            let subtotal = 0;
            document.querySelectorAll('.item-total').forEach(t => { subtotal += Number(t.textContent || 0); });
            const iva = Math.round(subtotal * 0.19);
            const total = subtotal + iva;
            document.getElementById('pre-subtotal').textContent = subtotal;
            document.getElementById('pre-iva').textContent = iva;
            document.getElementById('pre-total').textContent = total;
        }

        document.addEventListener('input', function(e){
            if (e.target.classList.contains('item-cant') || e.target.classList.contains('item-valor')) {
                const fila = e.target.closest('tr');
                const cant = Number(fila.querySelector('.item-cant').value) || 0;
                const valor = Number(fila.querySelector('.item-valor').value) || 0;
                fila.querySelector('.item-total').textContent = (cant * valor);
                calcularTotales();
            }
        });

        // Modal element
        const modalPresu = document.getElementById('modal-presupuesto');

        // Abrir modal
        document.getElementById('btn-agregar-inv').addEventListener('click', function(){
            modalPresu.classList.remove('hidden');
            modalPresu.style.display = 'flex';
            const first = document.getElementById('pre-cliente'); if(first) first.focus();
        });

        // Cerrar (botón)
        document.getElementById('pre-cancelar').addEventListener('click', function(){
            modalPresu.classList.add('hidden');
            modalPresu.style.display = 'none';
        });

        // Cerrar haciendo clic fuera del contenido (backdrop)
        modalPresu.addEventListener('click', function(e){
            if (e.target === modalPresu){
                modalPresu.classList.add('hidden');
                modalPresu.style.display = 'none';
            }
        });

        // Cerrar con Escape
        document.addEventListener('keydown', function(e){
            if (e.key === 'Escape' && !modalPresu.classList.contains('hidden')){
                modalPresu.classList.add('hidden');
                modalPresu.style.display = 'none';
            }
        });

        // Añadir fila
        document.getElementById('add-item').onclick = function(){
            const body = document.getElementById('items-body');
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" class="item-desc p-1 border rounded w-full"></td>
                <td><input type="number" class="item-cant p-1 border rounded" value="1" min="0"></td>
                <td><input type="text" class="item-nota p-1 border rounded"></td>
                <td><input type="number" class="item-valor p-1 border rounded" value="0" min="0"></td>
                <td class="item-total">0</td>
            `;
            body.appendChild(tr);
        }

        // Guardar presupuesto en el servidor (POST JSON)
        document.getElementById('pre-guardar').addEventListener('click', async function(){
            const cliente = document.getElementById('pre-cliente').value.trim();
            if (!cliente) return alert('Debe ingresar el nombre del cliente');
            const filas = document.querySelectorAll('#items-body tr');
            const items = [];
            filas.forEach(fila => {
                items.push({
                    descripcion: fila.querySelector('.item-desc').value.trim(),
                    cantidad: Number(fila.querySelector('.item-cant').value) || 0,
                    nota: fila.querySelector('.item-nota').value.trim(),
                    valor: Number(fila.querySelector('.item-valor').value) || 0,
                    total: Number(fila.querySelector('.item-total').textContent) || 0
                });
            });
            if (items.length === 0) return alert('Debe ingresar al menos 1 item al presupuesto');
            
            // Verificar si es INSERT o UPDATE
            const presupuestoId = document.getElementById('modal-presupuesto').dataset.presupuestoId;
            
            const payload = {
                cliente: cliente,
                rut: document.getElementById('pre-rut').value.trim(),
                correo: document.getElementById('pre-correo').value.trim(),
                direccion: document.getElementById('pre-direccion').value.trim(),
                fecha: document.getElementById('pre-fecha').value,
                contacto1: document.getElementById('pre-contacto1').value.trim(),
                contacto2: document.getElementById('pre-contacto2').value.trim(),
                marca: document.getElementById('pre-marca').value.trim(),
                modelo: document.getElementById('pre-modelo').value.trim(),
                anio: document.getElementById('pre-anio').value,
                tipo: document.getElementById('pre-tipo').value.trim(),
                matricula: document.getElementById('pre-matricula').value.trim(),
                items: items,
                subtotal: Number(document.getElementById('pre-subtotal').textContent) || 0,
                iva: Number(document.getElementById('pre-iva').textContent) || 0,
                total: Number(document.getElementById('pre-total').textContent) || 0,
                creado: new Date().toLocaleString()
            };
            
            // Si es actualización, agregar el ID
            if (presupuestoId) {
                payload._id = parseInt(presupuestoId);
            }

            try {
                const res = await fetch('save_presupuesto.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (json.success) {
                    alert('Presupuesto guardado correctamente');
                    document.getElementById('modal-presupuesto').classList.add('hidden');
                    document.getElementById('modal-presupuesto').style.display = 'none';
                    document.getElementById('pre-limpiar').click();
                    document.getElementById('modal-presupuesto').dataset.presupuestoId = '';
                    renderPresupuestos();
                } else {
                    alert('Error guardando: ' + (json.error || 'desconocido'));
                }
            } catch (e) {
                alert('Error de red: ' + e.message);
            }
        });

        // Renderizar presupuestos desde servidor
        async function renderPresupuestos() {
            const tbody = document.getElementById('listado-presupuestos');
            tbody.innerHTML = '<tr><td colspan="7">Cargando...</td></tr>';
            try {
                const res = await fetch('save_presupuesto.php');
                const json = await res.json();
                if (!json.success) throw new Error(json.error || 'error');
                const lista = json.lista || [];
                tbody.innerHTML = '';
                lista.forEach((p, index) => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-2">${escapeHtml(p.cliente)}</td>
                        <td class="px-4 py-2">${escapeHtml(p.rut || '')}</td>
                        <td class="px-4 py-2 break-words">${escapeHtml(p.correo || '')}</td>
                        <td class="px-4 py-2">${escapeHtml(p.contacto1 || '')}</td>
                        <td class="px-4 py-2">${escapeHtml(p._fecha || '')}</td>
                        <td class="px-4 py-2">$${escapeHtml(String(p._total || 0))}</td>
                        <td class="px-4 py-2">
                            <div class="flex items-center justify-center gap-2">                                <button class="btn-modificar px-3 py-1 bg-amber-400 text-black text-sm rounded hover:bg-amber-500" data-id="${p._id}">Ver/Editar</button>
                                <button class="btn-eliminar px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600" data-id="${p._id}">Eliminar</button>
                            </div>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch (e) {
                tbody.innerHTML = '<tr><td colspan="7">Error al cargar presupuestos</td></tr>';
                console.error(e);
            }
        }

        // Util: escape
        function escapeHtml(s){ if (!s) return ''; return String(s).replace(/[&<>"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]); }

        // Toggle dropdown menu
        document.addEventListener('click', function(e){
            if (e.target.classList.contains('dropdown-toggle')){
                const menu = e.target.nextElementSibling;
                const allMenus = document.querySelectorAll('.dropdown-menu');
                allMenus.forEach(m => m.classList.add('hidden'));
                if (menu) menu.classList.remove('hidden');
            } else if (!e.target.closest('.dropdown-menu') && !e.target.closest('.dropdown-toggle')){
                document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.add('hidden'));
            }
        });

        // Modificar presupuesto
        document.addEventListener('click', async function(e){
            if (e.target.classList.contains('btn-modificar')){
                const id = e.target.dataset.id;
                try {
                    const res = await fetch('save_presupuesto.php?id='+id);
                    const json = await res.json();
                    if (json.success && json.presupuesto){
                        const p = json.presupuesto;
                        loadPresupuestoToModal(p, false);
                        document.getElementById('modal-presupuesto').dataset.presupuestoId = p._id;
                        document.getElementById('pre-guardar').style.display = 'block';
                        document.getElementById('modal-presupuesto').classList.remove('hidden');
                        document.getElementById('modal-presupuesto').style.display = 'flex';
                    } else {
                        alert('Error al cargar: '+(json.error||''));
                    }
                } catch(err){
                    alert('Error de red: '+err.message);
                }
            }
        });

        // Cargar presupuesto al modal
        function loadPresupuestoToModal(p, readonly){
            document.getElementById('pre-cliente').value = p.cliente || '';
            document.getElementById('pre-rut').value = p.rut || '';
            document.getElementById('pre-correo').value = p.correo || '';
            document.getElementById('pre-direccion').value = p.direccion || '';
            document.getElementById('pre-fecha').value = p.fecha || '';
            document.getElementById('pre-contacto1').value = p.contacto1 || '';
            document.getElementById('pre-contacto2').value = p.contacto2 || '';
            document.getElementById('pre-marca').value = p.marca || '';
            document.getElementById('pre-modelo').value = p.modelo || '';
            document.getElementById('pre-anio').value = p.anio || '';
            document.getElementById('pre-tipo').value = p.tipo || '';
            document.getElementById('pre-matricula').value = p.matricula || '';
            
            const itemsBody = document.getElementById('items-body');
            itemsBody.innerHTML = '';
            (p.items || []).forEach(item => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><input type="text" class="item-desc p-1 border rounded w-full" value="${escapeHtml(item.descripcion || '')}" ${readonly?'readonly':''}></td>
                    <td><input type="number" class="item-cant p-1 border rounded" value="${item.cantidad || 0}" min="0" ${readonly?'readonly':''}></td>
                    <td><input type="text" class="item-nota p-1 border rounded" value="${escapeHtml(item.nota || '')}" ${readonly?'readonly':''}></td>
                    <td><input type="number" class="item-valor p-1 border rounded" value="${item.valor || 0}" min="0" ${readonly?'readonly':''}></td>
                    <td class="item-total">${item.total || 0}</td>
                `;
                itemsBody.appendChild(tr);
            });
            calcularTotales();
        }

        // Eliminar presupuesto
        document.addEventListener('click', async function(e){
            if (e.target.classList.contains('btn-eliminar')){
                const id = e.target.dataset.id;
                if (!confirm('¿Eliminar presupuesto?')) return;
                try {
                    const res = await fetch('save_presupuesto.php?id='+id, { method: 'DELETE' });
                    const json = await res.json();
                    if (json.success){
                        alert('Presupuesto eliminado');
                        renderPresupuestos();
                    } else {
                        alert('Error: '+(json.error||''));
                    }
                } catch (err){
                    alert('Error de red');
                }
            }
        });

        // Inicial
        renderPresupuestos();
        
        // Limpiar formulario del modal
        function clearPresupuestoForm(){
            ['pre-cliente','pre-rut','pre-correo','pre-direccion','pre-fecha','pre-contacto1','pre-contacto2','pre-marca','pre-modelo','pre-anio','pre-tipo','pre-matricula'].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
            const body = document.getElementById('items-body'); if (body) body.innerHTML = '';
            calcularTotales();
        }
        const btnLimpiar = document.getElementById('pre-limpiar'); if (btnLimpiar) btnLimpiar.addEventListener('click', clearPresupuestoForm);
    </script>
    
        

<?php include 'footer.php' ?>