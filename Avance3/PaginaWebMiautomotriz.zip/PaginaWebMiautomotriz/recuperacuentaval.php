<?php
require 'conexion.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function regresarLoginConError($mensaje) {
    $_SESSION['error_registro'] = $mensaje; 
    header("Location: login.php");       
    exit();                                 
}
function regresarConError($mensaje,$token) {
    $_SESSION['error_registro'] = $mensaje; 
    header("Location: recuperacuenta.php?token=$token");       
    exit();                                 
}
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $token_hash = hash("sha256", $token);

    $query = "SELECT * FROM persona WHERE token_hash = $1";
    $result = pg_query_params($conexion, $query, array($token_hash));

    if (pg_num_rows($result) > 0) {
        $user = pg_fetch_assoc($result);

        $token_expires_at = strtotime($user['token_expires_at']);
        
        if ($token_expires_at > time()) {
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $password = $_POST['password'];
                    $password_repeat = $_POST['password-repeat'];
                    if ($password !== $password_repeat) {
                        regresarConError("Las contraseñas no coinciden.",$token);
                    }else {
                        $password_hashed = password_hash($password, PASSWORD_DEFAULT);
                        $query = "UPDATE persona SET contrasenia = $2 WHERE rut = $1";
                        $result = pg_query_params($conexion, $query, array($user['rut'],$password_hashed));

                        $rut=$user['rut'];
                        
                        if ($result) {
                            $_SESSION['mensaje_exito'] = "Contraseña actualizada. Ya puedes iniciar sesión.";
                            header("Location: login.php");
                            exit();
                        }else{
                            regresarConError("$password $rut",$token);
                        }
                    }
                }
        } else {    
            regresarLoginConError("El token ha expirado.");
        }
    } else {
        regresarLoginConError("Token inválido.");
    }
} else {
    regresarLoginConError("No se ha proporcionado un token.");
}
?>
