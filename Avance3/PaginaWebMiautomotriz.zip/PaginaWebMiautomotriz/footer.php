<!-- Vincular scripts externos: primero script.js (globals y UI general), luego producto.js (render productos) -->

<!-- Quitamos 'defer' de script.js para asegurar que se cargue antes que los scripts que dependen de él -->
<script src="js/script.js?v=<?php echo filemtime('js/script.js'); ?>"></script>
<script src="js/producto.js?v=<?php echo filemtime('js/producto.js'); ?>"></script>

<!-- Centralizamos todas las llamadas de inicialización aquí -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Esta función inicializa el carrusel y los listeners de las tarjetas de producto.
        if (typeof window.renderProductos === 'function') {
            window.renderProductos();
        }
        // Esta función renderiza los comentarios (si aplica en la página).
        if (typeof window.renderComentarios === 'function') {
            window.renderComentarios();
        }
    });
</script>
        
    
</body>
<footer class="flex justify-center">
        &copy; 2025 MIAUtomotriz
    </footer>
</html>