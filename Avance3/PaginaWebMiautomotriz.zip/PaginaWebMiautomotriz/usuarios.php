<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

include 'header.php' 

?>
    <main>
        <section class="max-w-5xl mx-auto my-10 px-4">

            <!-- Barra de busqueda -->
            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="bg-skin-card inline-flex items-center border border-skin-border rounded-2xl shadow-2xl px-3 py-2  rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 svg-text-main" viewBox="0 0 20 20" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <form method="get" class="flex items-center gap-2 w-full md:w-auto">
                    <label for="buscar" class="font-semibold text-skin-muted mr-2">Buscar:</label>
                    <input id="buscar" class="w-full md:w-80 text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border rounded-2xl shadow-2xl focus:outline-none focus:ring-2 focus:ring-sky-300" name="q"  type="text" placeholder="Escribe para filtrar por nombre o rut" value="<?php echo isset($_GET['q'])?htmlspecialchars($_GET['q'],ENT_QUOTES):''; ?>"  />

                    <button type="submit" id="btn-buscar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md " title="Buscar">
                        <span alt="Buscar" class="svg-text-main block w-5 h-5">
                            <?php include 'media/lupa.svg'; ?>
                        </span>
                    </button>
                        <a href="usuarios.php" id="btn-cancelar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md hover:shadow-sm inline-flex items-center" title="Limpiar búsqueda">
                            <span class="svg-text-main block w-5 h-5">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                            </span>
                        </a>
                </form>

                <div class="mt-3 md:mt-0 md:ml-auto">
                <!-- Espacio para usar en u futuro -->
                </div>
            </div>

            <!-- Tabla de clientes -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
                    <thead class="bg-skin-card2">
                        <tr class="text-left text-sm font-medium text-skin-muted">
                            <th class="px-4 py-3">Rut</th>
                            <th class="px-4 py-3">Nombre</th>
                            <th class="px-4 py-3">Apellido</th>
                            <th class="px-4 py-3">Telefono</th>
                            <th class="px-4 py-3">Correo</th>
                            <th class="px-4 py-3">DirecciónID</th>
                            <th class="px-4 py-3">Tipo</th>
                            <th class="px-4 py-3 text-center">Accion</th>
                        </tr>
                    </thead>
                    <tbody id="lista-clientes" class="bg-skin-card divide-y divide-gray-100 text-sm text-skin-muted">
                        <?php
                        // Manejo de búsqueda en servidor: parámetro q
                        $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';

                        if (isset($conexion) && $conexion) {
                            $rows_to_show = [];

                            if ($q !== '') {
                                // Intentamos consulta preparada por nombre o rut
                                $pattern = '%' . $q . '%';
                                $res = @pg_query_params($conexion, "SELECT * FROM persona ORDER BY nombre DESC", array($pattern));

                                if ($res !== false) {
                                    while ($r = pg_fetch_assoc($res)) $rows_to_show[] = $r;
                                } else {
                                    // La consulta falló (posible esquema distinto). Traemos todo y filtramos en PHP.
                                    $res_all = @pg_query($conexion, "SELECT * FROM persona ORDER BY rut DESC");
                                    if ($res_all) {
                                        while ($r = pg_fetch_assoc($res_all)) {
                                            // construir campos para comparar
                                            $nombre = strtolower((string)($r['nombre']));
                                            $rut = strtolower((string)($r['rut']));
                                            if (stripos($nombre.$rut, $q) !== false) $rows_to_show[] = $r;
                                        }
                                    }
                                }
                            } else {
                                // Sin query: listamos todos
                                $res = @pg_query($conexion, "SELECT * FROM persona ORDER BY nombre DESC");
                                if ($res) while ($r = pg_fetch_assoc($res)) $rows_to_show[] = $r;
                            }

                            if (count($rows_to_show) === 0) {
                                echo '<tr><td class="px-4 py-4 text-center text-sm" colspan="5">No hay usuarios registrados</td></tr>';
                            } else {
                                $esc = function($v){ return htmlspecialchars((string)$v, ENT_QUOTES); };
                                foreach ($rows_to_show as $row) {
                                    $rut = $row['rut'];
                                    $nombre = $row['nombre'];
                                    $apellido = $row['apellido'];
                                    $telefono = $row['telefono'];
                                    $correo = $row['correo'];
                                    $direccionid = $row['direccionid'];
                                    $personaveri = $row['personaveri'];
                                    $empleado = $row['empleado'];

                                    echo "<tr>".
                                        "<td class=\"px-4 py-2\">". $esc($rut) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($nombre) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($apellido) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($telefono) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($correo) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($direccionid) ."</td>".
                                        "<td class=\"px-4 py-2\">". $esc($empleado) ."-". $esc($personaveri) ."</td>".
                                        "<td class=\"px-4 py-2 flex justify-center gap-2\">".
                                            "<a href=\"verusuario.php?rut=". $esc($rut) ."\" class=\"bg-skin-card border border-skin-border p-2 rounded-lg hover:shadow-md transition-shadow\" title=\"Ver usuario\">".
                                                "<span class=\"svg-text-main block w-5 h-5\">".
                                                    // Asegúrate de usar include correctamente aquí, o pon el SVG directo si prefieres
                                                    file_get_contents('media/ver.svg') . 
                                                "</span>".
                                            "</a>".

                                            // BOTÓN ELIMINAR (Abre modal)
                                            "<button onclick=\"confirmarEliminar('". $esc($rut) ."')\" class=\"bg-skin-card border border-skin-border p-2 rounded-lg hover:shadow-md transition-shadow text-red-500\" title=\"Eliminar usuario\">".
                                                "<span class=\" block w-5 h-5\" style=\"fill: red ;\">".
                                                    file_get_contents('media/eliminar.svg') .
                                                "</span>".
                                            "</button>".
                                        "</td>".
                                    "</tr>";
                                }
                            }
                        } else {
                            echo '<tr><td class="px-4 py-4 text-center text-sm text-red-500" colspan="5">No se pudo conectar a la base de datos</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

<div id="modal-eliminar" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        <div class="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity" aria-hidden="true" onclick="cerrarModal()"></div>

        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div class="inline-block align-bottom bg-skin-card rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-skin-border">
            <div class="bg-skin-card px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-skin-main" id="modal-title">Eliminar Usuario</h3>
                        <div class="mt-2">
                            <p class="text-sm text-skin-muted">
                                ¿Estás seguro de que deseas eliminar este usuario? Esta acción no se puede deshacer.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-skin-card2 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <a id="btn-confirmar-eliminar" href="#" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm">
                    Eliminar
                </a>
                <button type="button" onclick="cerrarModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-skin-border shadow-sm px-4 py-2 bg-skin-card text-base font-medium text-skin-main hover:text-skin-muted focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>
    
<?php include 'footer.php' ?>