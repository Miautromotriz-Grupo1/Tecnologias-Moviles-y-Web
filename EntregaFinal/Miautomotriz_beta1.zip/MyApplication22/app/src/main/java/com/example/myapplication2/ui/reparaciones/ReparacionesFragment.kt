package com.example.myapplication2.ui.reparaciones

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.databinding.FragmentReparacionesBinding

class ReparacionesFragment : Fragment() {

    private var _binding: FragmentReparacionesBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ReparacionesViewModel
    private lateinit var adapter: ReparacionesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReparacionesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        viewModel = ViewModelProvider(this).get(ReparacionesViewModel::class.java)

        setupRecyclerView()

        viewModel.reparaciones.observe(viewLifecycleOwner) { reparaciones ->
            adapter.submitList(reparaciones)
            // Show/Hide empty view if needed
        }

        viewModel.error.observe(viewLifecycleOwner) { errorMsg ->
            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
        }

        viewModel.cargarReparaciones(requireContext())

        return root
    }

    private fun setupRecyclerView() {
        adapter = ReparacionesAdapter()
        binding.recyclerReparaciones.layoutManager = LinearLayoutManager(context)
        binding.recyclerReparaciones.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
