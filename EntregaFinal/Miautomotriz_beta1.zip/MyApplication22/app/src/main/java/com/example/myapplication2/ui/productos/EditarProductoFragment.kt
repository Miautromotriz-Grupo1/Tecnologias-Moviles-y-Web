package com.example.myapplication2.ui.productos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import com.example.myapplication2.databinding.FragmentEditarProductoBinding
import org.json.JSONObject

class EditarProductoFragment : Fragment() {

    private var _binding: FragmentEditarProductoBinding? = null
    private val binding get() = _binding!!

    private val args: EditarProductoFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditarProductoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val producto = args.producto
        
        // Poblar todos los campos con los datos del producto
        binding.etNombre.setText(producto.nombre)
        binding.etImg.setText(producto.imagenUrl ?: "")
        binding.etPrecio.setText(producto.precio.toString())
        
        // --- CAMPOS QUE AHORA SÍ SE VAN A MOSTRAR (porque ya los leímos del JSON) ---
        binding.etMarca.setText(producto.marca)
        binding.etAnio.setText(producto.anio)
        binding.etCategoria.setText(producto.categoria ?: "")
        binding.etStock.setText(producto.stock?.toString() ?: "")
        binding.etBodega.setText(producto.nBodega ?: "")
        binding.etPrecioC.setText(producto.precioCompra?.toString() ?: "")

        // --- LÓGICA DE UI MEJORADA ---
        // Si es servicio, ocultamos la opción de producto y los campos de producto
        if (producto.isServicio) {
            binding.rbServicio.isChecked = true
            binding.rbProducto.isVisible = false // Oculta opción "Producto"
            binding.layoutProductoFields.isVisible = false
        } else {
            // Si es producto, ocultamos la opción de servicio y mostramos los campos
            binding.rbProducto.isChecked = true
            binding.rbServicio.isVisible = false // Oculta opción "Servicio"
            binding.layoutProductoFields.isVisible = true
        }

        binding.btnGuardar.setOnClickListener {
            actualizarProducto(producto)
        }
    }

    private fun actualizarProducto(producto: Producto) {
        val nombre = binding.etNombre.text.toString().trim()
        val img = binding.etImg.text.toString().trim()
        val precioVenta = binding.etPrecio.text.toString().trim()

        if (nombre.isEmpty() || precioVenta.isEmpty()) {
            Toast.makeText(context, "Nombre y Precio de Venta son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val params = JSONObject()
        try {
            params.put("id", producto.id)
            params.put("nombre", nombre)
            params.put("precio_v", precioVenta)
            params.put("img", img)
            
            if (producto.isServicio) {
                params.put("servicio", 1)
                // Para servicios, enviamos valores válidos por defecto para evitar error 22P02 en Postgres
                params.put("marca", "Servicio")
                params.put("anio", JSONObject.NULL) // Enviar null para fecha/año
                params.put("categoria", "Servicio")
                params.put("cantidad", 0)
                params.put("precio_c", 0)
                params.put("n_bodega", 1) // Enviar entero válido, no string vacía
            } else {
                // Es un producto, validamos y enviamos todos los campos
                val precioCompra = binding.etPrecioC.text.toString().trim()
                val marca = binding.etMarca.text.toString().trim()
                val anio = binding.etAnio.text.toString().trim()
                val categoria = binding.etCategoria.text.toString().trim()
                val nBodega = binding.etBodega.text.toString().trim()
                val cantidad = binding.etStock.text.toString().trim()

                if (precioCompra.isEmpty() || marca.isEmpty() || anio.isEmpty() || categoria.isEmpty() || nBodega.isEmpty() || cantidad.isEmpty()) {
                    Toast.makeText(context, "Todos los campos del producto son obligatorios", Toast.LENGTH_SHORT).show()
                    return
                }

                params.put("servicio", 0)
                params.put("marca", marca)
                params.put("anio", anio)
                params.put("categoria", categoria)
                params.put("cantidad", cantidad)
                params.put("precio_c", precioCompra)
                params.put("n_bodega", nBodega)
            }

        } catch (e: Exception) {
            Toast.makeText(context, "Error al construir la solicitud: ${e.message}", Toast.LENGTH_SHORT).show()
            return
        }

        val url = Constants.UPDATE_CATALOGO_URL
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, params,
            { response ->
                Toast.makeText(context, response.optString("mensaje", "Actualizado con éxito"), Toast.LENGTH_LONG).show()
                findNavController().popBackStack()
            },
            { error ->
                 val errorMsg = if (error.networkResponse != null && error.networkResponse.data != null) {
                    String(error.networkResponse.data)
                } else {
                    error.message ?: "Error desconocido"
                }
                Toast.makeText(context, "Error al actualizar: $errorMsg", Toast.LENGTH_LONG).show()
            }
        )

        VolleySingleton.getInstance(requireContext()).addToRequestQueue(jsonObjectRequest)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}