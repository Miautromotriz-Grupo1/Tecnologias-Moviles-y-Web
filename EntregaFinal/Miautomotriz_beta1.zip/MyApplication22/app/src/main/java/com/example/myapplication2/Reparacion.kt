package com.example.myapplication2

data class Reparacion(
    val id: Int,
    val descripcion: String,
    val fecha: String,
    val costo: Double,
    val estado: String
)
