package com.example.myapplication2.ui.productos

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplication2.R
import java.text.NumberFormat
import java.util.Locale

// Se agrega el callback onEditarProducto al constructor
class ProductosAdapter(
    private val onAgregarCarrito: (Producto) -> Unit,
    private val onEditarProducto: (Producto) -> Unit
) : ListAdapter<Producto, ProductosAdapter.ProductoVH>(ProductoDiffCallback()) {

    inner class ProductoVH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvNombre: TextView = view.findViewById(R.id.tvNombre)
        private val tvMarca: TextView = view.findViewById(R.id.tvMarca)
        private val tvPrecio: TextView = view.findViewById(R.id.tvPrecio)
        private val tvAnio: TextView = view.findViewById(R.id.tvAnio)
        private val ivProducto: ImageView = view.findViewById(R.id.ivProducto)
        private val btnEditar: ImageButton = view.findViewById(R.id.button_editar)
        private val btnAgregar: ImageButton = view.findViewById(R.id.button_agregar)

        fun bind(producto: Producto) {
            tvNombre.text = producto.nombre
            tvMarca.text = producto.marca

            val format = NumberFormat.getCurrencyInstance(Locale("es", "CL"))
            tvPrecio.text = format.format(producto.precio)

            tvAnio.text = "Año: ${producto.anio}"

            // Cargar imagen con Glide
            if (!producto.imagenUrl.isNullOrEmpty() && producto.imagenUrl != "null") {
                Glide.with(itemView.context)
                    .load(producto.imagenUrl)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_delete)
                    .into(ivProducto)
            } else {
                ivProducto.setImageResource(android.R.drawable.ic_menu_gallery)
            }

            // Verificar permisos para mostrar el botón de editar
            val sharedPreferences = itemView.context.getSharedPreferences("UserSession", Context.MODE_PRIVATE)
            val userLevel = sharedPreferences.getInt("user_empleado_level", 0)

            if (userLevel >= 1) { // Empleados (1) y Admins (2) pueden ver
                btnEditar.visibility = View.VISIBLE
                btnEditar.setOnClickListener {
                    onEditarProducto(producto)
                }
            } else {
                btnEditar.visibility = View.GONE
            }

            // Configurar click listener para agregar al carrito
            btnAgregar.setOnClickListener {
                onAgregarCarrito(producto)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_producto, parent, false)
        return ProductoVH(v)
    }

    override fun onBindViewHolder(holder: ProductoVH, position: Int) {
        holder.bind(getItem(position))
    }
}

class ProductoDiffCallback : DiffUtil.ItemCallback<Producto>() {
    override fun areItemsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem == newItem
    }
}
