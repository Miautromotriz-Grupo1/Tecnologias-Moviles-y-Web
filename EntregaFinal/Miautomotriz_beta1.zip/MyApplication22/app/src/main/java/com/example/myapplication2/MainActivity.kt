package com.example.myapplication2

import android.content.Context
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Ocultar la ActionBar globalmente para toda la app
        supportActionBar?.hide()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
        val navController = navHost.navController
        
        val sharedPref = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val nivelEmpleado = sharedPref.getInt("user_empleado_level", 0)

        val bottom: BottomNavigationView = binding.navView
        
        val itemFunciones = bottom.menu.findItem(R.id.navigation_funciones)
        if (itemFunciones != null) {
            itemFunciones.isVisible = (nivelEmpleado == 1 || nivelEmpleado == 2)
        }

        // Configuración de navegación sin ActionBar
        bottom.setupWithNavController(navController)
    }
}
