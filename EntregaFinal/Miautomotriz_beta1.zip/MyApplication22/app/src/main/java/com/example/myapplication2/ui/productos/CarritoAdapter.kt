package com.example.myapplication2.ui.productos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.R
import java.text.NumberFormat
import java.util.Locale

class CarritoAdapter(
    private val onEliminarClick: (Producto) -> Unit
) : ListAdapter<Producto, CarritoAdapter.CarritoVH>(CarritoDiffCallback()) {

    inner class CarritoVH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvNombre: TextView = view.findViewById(R.id.tvNombreCarrito)
        private val tvMarca: TextView = view.findViewById(R.id.tvMarcaCarrito)
        private val tvPrecio: TextView = view.findViewById(R.id.tvPrecioCarrito)
        private val btnEliminar: ImageButton = view.findViewById(R.id.btnEliminarCarrito)

        fun bind(producto: Producto) {
            tvNombre.text = producto.nombre
            tvMarca.text = producto.marca
            val format = NumberFormat.getCurrencyInstance(Locale("es", "CL"))
            tvPrecio.text = format.format(producto.precio)
            
            btnEliminar.setOnClickListener {
                onEliminarClick(producto)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarritoVH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_carrito, parent, false)
        return CarritoVH(v)
    }

    override fun onBindViewHolder(holder: CarritoVH, position: Int) {
        holder.bind(getItem(position))
    }
}

class CarritoDiffCallback : DiffUtil.ItemCallback<Producto>() {
    override fun areItemsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        // En el carrito permitimos múltiples instancias del mismo producto.
        // Como usamos una lista mutable en el Fragment y pasamos una copia, 
        // DiffUtil se encargará. Sin embargo, para eliminaciones precisas de duplicados,
        // lo ideal sería tener un ID único de item de carrito.
        // Por ahora, asumimos que se elimina la primera instancia que coincida o usamos referencia.
        return oldItem === newItem 
    }

    override fun areContentsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem == newItem
    }
}
