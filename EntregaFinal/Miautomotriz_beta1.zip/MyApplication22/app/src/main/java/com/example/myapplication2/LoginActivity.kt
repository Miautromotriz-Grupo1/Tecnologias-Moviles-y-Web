package com.example.myapplication2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONException
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    // Variable para controlar el tiempo del último clic y evitar dobles toques
    private var ultimoClick: Long = 0
    // Cola de peticiones única para toda la actividad
    private lateinit var requestQueue: RequestQueue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // --- 1. VERIFICAR SESIÓN EXISTENTE ---
        val sharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        if (sharedPreferences.getBoolean("is_logged_in", false)) {
            // Si el usuario ya está logueado, ir directo al Main
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        setContentView(R.layout.activity_login)

        // Inicializamos la cola de Volley una sola vez
        requestQueue = Volley.newRequestQueue(this)

        val etRut = findViewById<TextInputEditText>(R.id.etRut)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val btnRecuperar = findViewById<Button>(R.id.btnrecuperacuenta)

        // --- IR A REGISTRO ---
        btnRegister.setOnClickListener {
            val intent = Intent(this, RegistroActivity::class.java)
            startActivity(intent)
        }

        // --- LÓGICA RECUPERAR CONTRASEÑA ---
        btnRecuperar.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ultimoClick < 1500) {
                return@setOnClickListener
            }
            ultimoClick = SystemClock.elapsedRealtime()

            val rutIngresado = etRut.text.toString().trim()

            if (rutIngresado.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese su RUT para recuperar la contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnRecuperar.isEnabled = false
            btnRecuperar.text = "Enviando..."

            val url = Constants.RECOVERY_URL
            val params = JSONObject()
            try {
                params.put("rut", rutIngresado)
            } catch (e: JSONException) {
                e.printStackTrace()
            }

            val jsonObjectRequest = JsonObjectRequest(Request.Method.POST, url, params,
                { response ->
                    btnRecuperar.isEnabled = true
                    btnRecuperar.text = "Recuperar Contraseña"

                    try {
                        val status = if (response.has("status")) response.getString("status") else ""
                        val message = if (response.has("message")) response.getString("message") else ""

                        if (status.equals("success", ignoreCase = true)) {
                            Toast.makeText(this@LoginActivity, "Solicitud enviada. Revisa tu correo.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@LoginActivity, message, Toast.LENGTH_LONG).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(this@LoginActivity, "Error procesando respuesta del servidor", Toast.LENGTH_SHORT).show()
                    }
                },
                { error ->
                    btnRecuperar.isEnabled = true
                    btnRecuperar.text = "Recuperar Contraseña"
                    val errorMsg = error.message ?: "Error de conexión o tiempo de espera"
                    Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show()
                }
            )

            jsonObjectRequest.retryPolicy = DefaultRetryPolicy(
                25000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            requestQueue.add(jsonObjectRequest)
        }

        // --- LÓGICA LOGIN ---
        btnLogin.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ultimoClick < 1000) {
                return@setOnClickListener
            }
            ultimoClick = SystemClock.elapsedRealtime()

            val rutIngresado = etRut.text.toString().trim()
            val passwordIngresado = etPassword.text.toString().trim()

            if (rutIngresado.isEmpty() || passwordIngresado.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese rut y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnLogin.isEnabled = false
            btnLogin.text = "Conectando..."

            val url = Constants.LOGIN_URL
            val params = JSONObject()
            params.put("rut", rutIngresado)
            params.put("password", passwordIngresado)

            val jsonObjectRequest = JsonObjectRequest(Request.Method.POST, url, params,
                { response ->
                    btnLogin.isEnabled = true
                    btnLogin.text = "Ingresar"
                    try {
                        val status = response.optString("status")
                        val message = response.optString("message")

                        if (status.equals("success", ignoreCase = true)) {
                            // --- 2. GUARDAR SESIÓN EN SHAREDPREFERENCES ---
                            val editor = sharedPreferences.edit()
                            editor.putBoolean("is_logged_in", true)
                            editor.putString("user_rut", rutIngresado)
                            
                            // GUARDAR NIVEL DE EMPLEADO (0=Cliente, 1=Empleado, 2=Admin)
                            if (response.has("empleado")) {
                                val nivelEmpleado = response.optInt("empleado", 0)
                                editor.putInt("user_empleado_level", nivelEmpleado)
                            } else {
                                // Si no viene el campo, asumir cliente por seguridad
                                editor.putInt("user_empleado_level", 0)
                            }
                            
                            // Si devuelve el nombre
                            if (response.has("nombre")) {
                                editor.putString("user_name", response.getString("nombre"))
                            }
                            
                            editor.apply()

                            Toast.makeText(this@LoginActivity, "Bienvenido", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@LoginActivity, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else if (status.equals("unauthorized", ignoreCase = true)) {
                            Toast.makeText(this@LoginActivity, "Usuario no autorizado", Toast.LENGTH_LONG).show()
                        } else {
                            val msg = if (message.isNotEmpty()) message else "Credenciales incorrectas"
                            Toast.makeText(this@LoginActivity, msg, Toast.LENGTH_LONG).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(this@LoginActivity, "Error procesando respuesta", Toast.LENGTH_LONG).show()
                    }
                },
                { error ->
                    btnLogin.isEnabled = true
                    btnLogin.text = "Ingresar"
                    Toast.makeText(this, "Error de conexión", Toast.LENGTH_LONG).show()
                }
            )

            jsonObjectRequest.retryPolicy = DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            requestQueue.add(jsonObjectRequest)
        }
    }
}
