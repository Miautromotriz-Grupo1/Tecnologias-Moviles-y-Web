package com.example.myapplication2.ui.productos

import java.io.Serializable

data class Producto(
    val id: Int,
    val nombre: String,
    val marca: String,
    val precio: Int,
    val anio: String,
    val imagenUrl: String?,
    val stock: Int?,
    val categoria: String?,
    val isServicio: Boolean,
    val precioCompra: Int?,
    val nBodega: String?
) : Serializable
