package com.example.myapplication2.ui.productos

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import org.json.JSONException

class ProductosViewModel : ViewModel() {

    private val _productos = MutableLiveData<List<Producto>>()
    val productos: LiveData<List<Producto>> = _productos

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // Función para cargar datos (Productos o Servicios según la URL)
    fun cargarDatos(context: Context, isServicio: Boolean = false) {
        _isLoading.value = true
        // Seleccionamos URL dependiendo del tipo
        val url = if (isServicio) Constants.GET_SERVICIO_URL else Constants.GET_PRODUCTS_URL

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                _isLoading.value = false
                val listaProductos = mutableListOf<Producto>()
                try {
                    for (i in 0 until response.length()) {
                        val jsonObject = response.getJSONObject(i)
                        
                        Log.d("ProductosViewModel", "JSON ($i): $jsonObject")

                        val id = jsonObject.optInt("id", 0)
                        val nombre = jsonObject.optString("nombre", "Sin nombre")
                        
                        // Si es servicio, podría no tener marca, manejamos fallback
                        val marca = jsonObject.optString("marca", if(isServicio) "Servicio" else "Sin marca")
                        
                        // Parseo de precio robusto, dando prioridad a 'precio_v'
                        val precioStr = jsonObject.optString("precio_v", jsonObject.optString("precio", "0"))
                        val precio = parsePrecio(precioStr)

                        val anio = jsonObject.optString("anio", "")
                        
                        // Lógica para procesar la URL de la imagen
                        val imgRaw = jsonObject.optString("img", "")
                        var imgFinal: String? = null
                        
                        if (imgRaw.isNotEmpty() && imgRaw != "null") {
                            if (imgRaw.startsWith("media/")) {
                                imgFinal = "https://proyecto.jakrarish.net/pagina/v4/" + imgRaw
                            } else {
                                imgFinal = imgRaw
                            }
                        }
                        // Tu API devuelve 'cantidad', lo mapeamos a 'stock'
                        val stock = jsonObject.optInt("stock", jsonObject.optInt("cantidad", 0))
                        val categoria = jsonObject.optString("categoria", "")

                        // Determinamos si es servicio basado en el campo 'servicio' del JSON o el parámetro
                        val isServicioItem = jsonObject.optInt("servicio", if (isServicio) 1 else 0) == 1
                        
                        // Lectura de los nuevos campos que devuelve tu API
                        val precioCompra = jsonObject.optInt("precio_c", 0)
                        val nBodega = jsonObject.optString("n_bodega", "")

                        listaProductos.add(Producto(id, nombre, marca, precio, anio, imgFinal, stock, categoria, isServicioItem, precioCompra, nBodega))
                    }
                    _productos.value = listaProductos
                } catch (e: JSONException) {
                    _error.value = "Error al procesar datos: ${e.message}"
                    Log.e("ProductosViewModel", "Error JSON", e)
                }
            },
            { error ->
                _isLoading.value = false
                _error.value = "Error de conexión: ${error.message}"
                Log.e("ProductosViewModel", "Error Volley", error)
            }
        )

        VolleySingleton.getInstance(context).addToRequestQueue(jsonArrayRequest)
    }

    // Mantenemos retrocompatibilidad si alguien llama a cargarProductos
    fun cargarProductos(context: Context) {
        cargarDatos(context, isServicio = false)
    }

    private fun parsePrecio(precioRaw: String?): Int {
        if (precioRaw.isNullOrEmpty() || precioRaw == "null") {
            Log.w("ProductosViewModel", "¡ALERTA! El campo 'precio' vino NULO o vacío.")
            return 0
        }
        
        return try {
            var limpio = precioRaw.replace("$", "").replace(" ", "").trim()
            limpio = limpio.replace(",", ".")
            val valorDouble = limpio.toDouble()
            valorDouble.toInt()
        } catch (e: Exception) {
            Log.e("ProductosViewModel", "Error parseando precio '$precioRaw': ${e.message}")
            0
        }
    }
}
