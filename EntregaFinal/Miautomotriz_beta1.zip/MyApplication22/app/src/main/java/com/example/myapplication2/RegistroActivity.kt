package com.example.myapplication2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        // Referencias a la UI
        val btnCrear = findViewById<Button>(R.id.btnCrearCuenta)
        val tvVolver = findViewById<TextView>(R.id.tvVolverLogin)

        val etRut = findViewById<EditText>(R.id.etRutRegistro)
        val etNombre = findViewById<EditText>(R.id.etNombreRegistro)
        val etApellido = findViewById<EditText>(R.id.etApellidoRegistro)

        // IMPORTANTE: Asegúrate de tener estos ID en tu activity_registro.xml
        // La API PHP requiere correo y confirmación de contraseña.
        val etCorreo = findViewById<EditText>(R.id.etCorreoRegistro)
        val etPass = findViewById<EditText>(R.id.etPassRegistro)
        val etPassRepeat = findViewById<EditText>(R.id.etPassRepeatRegistro)

        // Volver al Login
        tvVolver.setOnClickListener {
            finish()
        }

        // Botón Registrarse
        btnCrear.setOnClickListener {
            val rutRaw = etRut.text.toString().trim()
            val nombre = etNombre.text.toString().trim()
            val apellido = etApellido.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val pass = etPass.text.toString().trim()
            val passRepeat = etPassRepeat.text.toString().trim()

            // 1. Validaciones Locales
            if (rutRaw.isEmpty() || nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (pass != passRepeat) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!validarRut(rutRaw)) {
                etRut.error = "RUT inválido"
                Toast.makeText(this, "El RUT ingresado no es válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Deshabilitar botón para evitar doble click
            btnCrear.isEnabled = false
            btnCrear.text = "Registrando..."

            val queue = Volley.newRequestQueue(this)
            val url = Constants.REGISTER_URL

            // 3. Crear JSON para enviar
            val params = JSONObject()
            try {
                params.put("rut", rutRaw)
                params.put("nombre", nombre)
                params.put("apellido", apellido)
                params.put("correo", correo)
                params.put("password", pass)
                params.put("password-repeat", passRepeat)
            } catch (e: JSONException) {
                e.printStackTrace()
            }

            // 4. Enviar Petición
            val jsonObjectRequest = JsonObjectRequest(Request.Method.POST, url, params,
                { response ->
                    btnCrear.isEnabled = true
                    btnCrear.text = "Crear Cuenta"

                    try {
                        val status = if (response.has("status")) response.getString("status") else ""
                        val message = if (response.has("message")) response.getString("message") else ""

                        if (status.equals("success", ignoreCase = true)) {
                            // Registro exitoso
                            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
                            // Volver al login automáticamente
                            finish()
                        } else {
                            // Error enviado por el PHP (ej: Rut duplicado)
                            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(applicationContext, "Error procesando respuesta", Toast.LENGTH_LONG).show()
                    }
                },
                { error ->
                    btnCrear.isEnabled = true
                    btnCrear.text = "Crear Cuenta"
                    val errorMsg = error.message ?: "Error de conexión con el servidor"
                    Toast.makeText(applicationContext, errorMsg, Toast.LENGTH_LONG).show()
                }
            )
            jsonObjectRequest.retryPolicy = com.android.volley.DefaultRetryPolicy(
                20000, // Tiempo de espera: 20 segundos (suficiente para enviar el correo)
                0,     // Número de reintentos: 0 (para evitar el doble registro)
                com.android.volley.DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )
            queue.add(jsonObjectRequest)
        }
    }

    // Función para validar RUT chileno (Mantenemos tu lógica que estaba bien)
    private fun validarRut(rut: String): Boolean {
        var rutLimpio = rut.replace(".", "").replace("-", "")
        if (rutLimpio.length < 2) return false

        val dvIngresado = rutLimpio.takeLast(1).uppercase()
        val cuerpo = rutLimpio.dropLast(1)

        val rutNumerico = cuerpo.toIntOrNull() ?: return false

        var suma = 0
        var multiplicador = 2
        var aux = rutNumerico

        while (aux > 0) {
            suma += (aux % 10) * multiplicador
            aux /= 10
            multiplicador++
            if (multiplicador > 7) multiplicador = 2
        }

        val resto = 11 - (suma % 11)
        val dvCalculado = when (resto) {
            11 -> "0"
            10 -> "K"
            else -> resto.toString()
        }

        return dvIngresado == dvCalculado
    }
}