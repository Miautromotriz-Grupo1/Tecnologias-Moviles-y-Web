package com.example.myapplication2.ui.usuarios

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import org.json.JSONException

class UsuariosViewModel : ViewModel() {

    private val _usuarios = MutableLiveData<List<Usuario>>()
    val usuarios: LiveData<List<Usuario>> = _usuarios

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun cargarUsuarios(context: Context) {
        _isLoading.value = true
        _error.value = null

        val request = JsonArrayRequest(
            Request.Method.GET,
            Constants.GET_USUARIOS_URL,
            null,
            { response ->
                _isLoading.value = false
                val lista = mutableListOf<Usuario>()
                try {
                    for (i in 0 until response.length()) {
                        val obj = response.getJSONObject(i)

                        // Convertir el nivel de empleado (int) a texto
                        val nivelEmpleado = obj.optInt("empleado", 0)
                        val rolTexto = when (nivelEmpleado) {
                            1 -> "Empleado"
                            2 -> "Administrador"
                            else -> "Cliente"
                        }

                        val usuario = Usuario(
                            rut = obj.optString("rut", "Sin RUT"),
                            nombre = obj.optString("nombre", "Sin Nombre"),
                            apellido = obj.optString("apellido", ""),
                            correo = obj.optString("correo", "Sin Correo"),
                            telefono = obj.optString("telefono", ""),
                            direccion = obj.optString("direccionid", ""), // Mapear direccionid a direccion
                            personaveri = obj.optString("personaveri", ""),
                            empleado = rolTexto
                        )
                        lista.add(usuario)
                    }
                    _usuarios.value = lista
                    if (lista.isEmpty()) {
                        _error.value = "No se encontraron usuarios."
                    }

                } catch (e: JSONException) {
                    _isLoading.value = false
                    _error.value = "Error al procesar la respuesta del servidor: ${e.message}"
                    e.printStackTrace()
                }
            },
            { error ->
                _isLoading.value = false
                val networkResponse = error.networkResponse
                val statusCode = networkResponse?.statusCode ?: "N/A"
                val errorMessage = try {
                    String(networkResponse?.data ?: ByteArray(0))
                } catch (e: Exception) {
                    error.message ?: "Error desconocido"
                }
                _error.value = "Error de red ($statusCode): $errorMessage"
                error.printStackTrace()
            }
        )

        VolleySingleton.getInstance(context).addToRequestQueue(request)
    }
}
