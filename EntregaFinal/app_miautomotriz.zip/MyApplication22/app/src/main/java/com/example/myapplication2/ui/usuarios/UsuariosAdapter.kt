package com.example.myapplication2.ui.usuarios

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.databinding.ItemUsuarioBinding

class UsuariosAdapter(
    private var usuarios: List<Usuario>,
    private val onEditarClick: (Usuario) -> Unit
) : RecyclerView.Adapter<UsuariosAdapter.UsuarioViewHolder>() {

    inner class UsuarioViewHolder(private val binding: ItemUsuarioBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(usuario: Usuario) {
            binding.tvNombreUsuario.text = "${usuario.nombre} ${usuario.apellido}"
            binding.tvCorreoUsuario.text = usuario.correo
            binding.tvRutUsuario.text = "RUT: ${usuario.rut}"
            // Mostrar el texto del rol/empleado en lugar del número de nivel
            binding.tvNivelUsuario.text = "Rol: ${usuario.empleado ?: "Cliente"}"

            binding.btnEditarUsuario.setOnClickListener {
                onEditarClick(usuario)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val binding = ItemUsuarioBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return UsuarioViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        holder.bind(usuarios[position])
    }

    override fun getItemCount(): Int = usuarios.size

    fun actualizarLista(nuevaLista: List<Usuario>) {
        usuarios = nuevaLista
        notifyDataSetChanged()
    }
}
