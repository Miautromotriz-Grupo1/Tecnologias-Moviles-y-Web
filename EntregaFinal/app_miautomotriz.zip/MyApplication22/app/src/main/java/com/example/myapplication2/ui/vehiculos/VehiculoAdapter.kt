package com.example.myapplication2.ui.vehiculos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.R
import com.example.myapplication2.ui.vehiculos.Vehiculo

class VehiculoAdapter(
    private var vehiculos: List<Vehiculo>,
    private val onDeleteClick: (Vehiculo) -> Unit // Callback para eliminar
) : RecyclerView.Adapter<VehiculoAdapter.VehiculoViewHolder>() {

    class VehiculoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvMarcaModelo: TextView = itemView.findViewById(R.id.tvMarcaModelo)
        val tvPatente: TextView = itemView.findViewById(R.id.tvPatente)
        val tvAnio: TextView = itemView.findViewById(R.id.tvAnio)
        val tvColor: TextView = itemView.findViewById(R.id.tvColor)
        val tvClienteName: TextView? = itemView.findViewById(R.id.tvCliente)
        val btnEliminar: ImageButton = itemView.findViewById(R.id.btnEliminarVehiculo)
        val btnEditar: ImageButton = itemView.findViewById(R.id.btnEditarVehiculo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VehiculoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_vehiculo, parent, false)
        return VehiculoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VehiculoViewHolder, position: Int) {
        val vehiculo = vehiculos[position]
        holder.tvMarcaModelo.text = "${vehiculo.marca_car} ${vehiculo.modelo_car}"
        holder.tvPatente.text = "Patente: ${vehiculo.matricula}"
        holder.tvAnio.text = "Año: ${vehiculo.anio_car}"
        holder.tvColor.text = "Color: ${vehiculo.color_car}"

        // Ocultar el TextView del cliente
        holder.tvClienteName?.visibility = View.INVISIBLE
        
        // Ocultar el botón de editar
        holder.btnEditar.visibility = View.INVISIBLE
        
        // Configurar listener para eliminar
        holder.btnEliminar.setOnClickListener {
            onDeleteClick(vehiculo)
        }
    }

    override fun getItemCount() = vehiculos.size

    fun updateData(newVehiculos: List<Vehiculo>) {
        vehiculos = newVehiculos
        notifyDataSetChanged()
    }
}
