package com.example.myapplication2.ui.vehiculos

import java.io.Serializable

data class Vehiculo(
    val id_car: String,
    val marca_car: String,
    val modelo_car: String,
    val anio_car: String,
    val vin_vehiculo: String,
    val color_car: String,
    val tipodevehiculo: String,
    val matricula: String,
    val persona: String,
    val kilometraje: Int,
    val n_chasis: String
) : Serializable