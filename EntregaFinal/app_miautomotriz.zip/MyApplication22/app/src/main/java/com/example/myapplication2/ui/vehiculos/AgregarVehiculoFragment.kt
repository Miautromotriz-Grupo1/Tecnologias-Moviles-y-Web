package com.example.myapplication2.ui.vehiculos

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication2.Constants
import com.example.myapplication2.databinding.FragmentAgregarVehiculoBinding
import org.json.JSONObject

class AgregarVehiculoFragment : Fragment() {

    private var _binding: FragmentAgregarVehiculoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarVehiculoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnGuardarVehiculo.setOnClickListener {
            guardarVehiculo()
        }
    }

    private fun guardarVehiculo() {
        val sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userRut = sharedPreferences.getString("user_rut", null)

        if (userRut == null) {
            Toast.makeText(context, "Error: No se pudo obtener el RUT del usuario.", Toast.LENGTH_LONG).show()
            return
        }

        // Recoger datos del formulario
        val patente = binding.etPatente.text.toString().trim()
        val marca = binding.etMarca.text.toString().trim()
        val modelo = binding.etModelo.text.toString().trim()
        val anio = binding.etAnio.text.toString().trim()
        val color = binding.etColor.text.toString().trim()
        val vin = binding.etVin.text.toString().trim()
        val tipoVehiculo = binding.etTipoVehiculo.text.toString().trim()

        if (patente.isEmpty() || marca.isEmpty() || modelo.isEmpty() || anio.isEmpty()) {
            Toast.makeText(context, "Patente, Marca, Modelo y Año son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        // Crear objeto JSON para enviar a la API
        val params = JSONObject()
        params.put("matricula", patente)
        params.put("marca_car", marca)
        params.put("modelo_car", modelo)
        params.put("anio_car", anio)
        params.put("color_car", color)
        params.put("vin_vehiculo", vin)
        params.put("tipodevehiculo", tipoVehiculo)
        params.put("personaid", userRut) // La API espera el RUT del dueño del auto

        val request = JsonObjectRequest(
            Request.Method.POST,
            Constants.ADD_VEHICULO_URL,
            params,
            { response ->
                Log.d("AgregarVehiculo", "Response: $response")
                Toast.makeText(context, "Vehículo guardado exitosamente", Toast.LENGTH_LONG).show()
                // Regresar a la pantalla anterior (lista de vehículos)
                findNavController().navigateUp()
            },
            { error ->
                Log.e("AgregarVehiculo", "Error: ${error.message}", error)
                Toast.makeText(context, "Error al guardar el vehículo: ${error.message}", Toast.LENGTH_LONG).show()
            }
        )

        // Añadir la solicitud a la cola de Volley
        Volley.newRequestQueue(requireContext()).add(request)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
