package com.example.myapplication2.ui.funciones

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.databinding.FragmentFuncionesBinding

class FuncionesFragment : Fragment() {

    private var _binding: FragmentFuncionesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFuncionesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        binding.btnUsuarios.setOnClickListener {
            val action = FuncionesFragmentDirections.actionFuncionesToUsuarios()
            findNavController().navigate(action)
        }

        binding.btnPresupuestos.setOnClickListener {
            val action = FuncionesFragmentDirections.actionFuncionesToPresupuestos()
            findNavController().navigate(action)
        }

        binding.btnPresupuestosTotales.setOnClickListener {
            val action = FuncionesFragmentDirections.actionFuncionesToPresupuestosTotales()
            findNavController().navigate(action)
        }

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Es más seguro acceder a las vistas después de que se hayan creado.
        checkUserRole()
    }

    private fun checkUserRole() {
        val sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userLevel = sharedPreferences.getInt("user_empleado_level", 0) // 0: Cliente, 1: Empleado, 2: Admin

        // El panel de administrador solo es visible para el nivel 2
        if (userLevel == 2) {
            binding.tvTituloAdmin.visibility = View.VISIBLE
            binding.rowAdmin1.visibility = View.VISIBLE
            binding.rowAdmin2.visibility = View.VISIBLE
        } else {
            binding.tvTituloAdmin.visibility = View.GONE
            binding.rowAdmin1.visibility = View.GONE
            binding.rowAdmin2.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
