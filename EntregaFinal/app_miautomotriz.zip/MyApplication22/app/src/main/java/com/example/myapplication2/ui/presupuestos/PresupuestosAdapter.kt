package com.example.myapplication2.ui.presupuestos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.Presupuesto
import com.example.myapplication2.R
import java.text.NumberFormat
import java.util.Locale

class PresupuestosAdapter(
    private var presupuestos: List<Presupuesto>,
    private val onDetalleClick: (Presupuesto) -> Unit
) : RecyclerView.Adapter<PresupuestosAdapter.PresupuestoViewHolder>() {

    class PresupuestoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCodigo: TextView = itemView.findViewById(R.id.tvCodigoPresupuesto)
        val tvPatente: TextView = itemView.findViewById(R.id.tvPatenteVehiculo)
        val tvDescripcion: TextView = itemView.findViewById(R.id.tvDescripcionPresupuesto)
        val tvMonto: TextView = itemView.findViewById(R.id.tvMontoPresupuesto)
        val tvEstado: TextView = itemView.findViewById(R.id.tvEstadoPresupuesto)
        val btnVerDetalle: Button = itemView.findViewById(R.id.btnVerDetalle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PresupuestoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_presupuesto, parent, false)
        return PresupuestoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PresupuestoViewHolder, position: Int) {
        val presupuesto = presupuestos[position]
        
        holder.tvCodigo.text = "ID: ${presupuesto.id}"
        holder.tvPatente.text = "VIN: ${presupuesto.vinVehiculo ?: "N/A"}"
        holder.tvDescripcion.text = presupuesto.observaciones ?: "Sin observaciones"
        
        // Formatear monto a moneda chilena
        val format = NumberFormat.getCurrencyInstance(Locale("es", "CL"))
        holder.tvMonto.text = format.format(presupuesto.total)

        // Lógica para estado booleano (true = Aprobado, false = Pendiente)
        if (presupuesto.estado) {
            holder.tvEstado.text = "Aprobado"
            holder.tvEstado.setBackgroundResource(android.R.color.holo_green_dark)
        } else {
            holder.tvEstado.text = "Pendiente"
            holder.tvEstado.setBackgroundResource(R.drawable.bg_status_pending) // Asegúrate de que este drawable exista
        }

        holder.btnVerDetalle.setOnClickListener {
            onDetalleClick(presupuesto)
        }
    }

    override fun getItemCount() = presupuestos.size

    fun updateList(newList: List<Presupuesto>) {
        presupuestos = newList
        notifyDataSetChanged()
    }
}
