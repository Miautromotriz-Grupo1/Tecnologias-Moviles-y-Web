package com.example.myapplication2.ui.presupuestos

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.Presupuesto
import com.example.myapplication2.databinding.FragmentPresupuestosTotalesBinding

class PresupuestosTotalesFragment : Fragment() {

    private var _binding: FragmentPresupuestosTotalesBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: PresupuestosTotalesViewModel
    private lateinit var adapter: PresupuestosAdapter
    private var listaPresupuestosFull: List<Presupuesto> = listOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this).get(PresupuestosTotalesViewModel::class.java)

        _binding = FragmentPresupuestosTotalesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupRecyclerView()
        setupSearch()
        observeViewModel()

        return root
    }

    private fun setupRecyclerView() {
        adapter = PresupuestosAdapter(listOf()) { presupuesto ->
            Toast.makeText(requireContext(), "Detalle de: ${presupuesto.id}", Toast.LENGTH_SHORT).show()
        }
        binding.rvPresupuestos.layoutManager = LinearLayoutManager(context)
        binding.rvPresupuestos.adapter = adapter
    }

    private fun setupSearch() {
        binding.etBuscarPresupuesto.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filtrarPresupuestos(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filtrarPresupuestos(texto: String) {
        val textoBusqueda = texto.lowercase()
        val listaFiltrada = if (textoBusqueda.isEmpty()) {
            listaPresupuestosFull
        } else {
            listaPresupuestosFull.filter {
                it.id.toString().contains(textoBusqueda) ||
                (it.vinVehiculo?.lowercase()?.contains(textoBusqueda) == true)
            }
        }
        adapter.updateList(listaFiltrada)
    }

    private fun observeViewModel() {
        viewModel.presupuestos.observe(viewLifecycleOwner) { presupuestos ->
            listaPresupuestosFull = presupuestos
            val textoActual = binding.etBuscarPresupuesto.text.toString()
            if (textoActual.isNotEmpty()) {
                filtrarPresupuestos(textoActual)
            } else {
                adapter.updateList(presupuestos)
            }
            
            binding.tvNoData.visibility = if (presupuestos.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBarPresupuestos.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
