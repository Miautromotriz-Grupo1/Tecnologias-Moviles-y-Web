package com.example.myapplication2.ui.vehiculos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.R
import com.example.myapplication2.ui.vehiculos.Vehiculo

class VehiculosAdapter(
    private var vehiculos: List<Vehiculo>,
    private val onItemClick: (Vehiculo) -> Unit
) : RecyclerView.Adapter<VehiculosAdapter.VehiculoViewHolder>() {

    class VehiculoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvPatente: TextView = view.findViewById(R.id.tvPatente)
        val tvMarcaModelo: TextView = view.findViewById(R.id.tvMarcaModelo)
        val tvColor: TextView = view.findViewById(R.id.tvColor)
        val tvCliente: TextView = view.findViewById(R.id.tvCliente)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VehiculoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_vehiculo, parent, false)
        return VehiculoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VehiculoViewHolder, position: Int) {
        val vehiculo = vehiculos[position]
        holder.tvPatente.text = vehiculo.matricula
        holder.tvMarcaModelo.text = "${vehiculo.marca_car} ${vehiculo.modelo_car} - ${vehiculo.anio_car}"
        holder.tvColor.text = "Color: ${vehiculo.color_car}"
        holder.tvCliente.text = "Cliente: ${vehiculo.persona}"

        holder.itemView.setOnClickListener { onItemClick(vehiculo) }
    }

    override fun getItemCount() = vehiculos.size

    fun updateData(newVehiculos: List<Vehiculo>) {
        vehiculos = newVehiculos
        notifyDataSetChanged()
    }
}
