package com.example.myapplication2.ui.productos

data class Servicio(
    val id: Int,
    val nombre: String,
    val marca: String,
    val precio: Int,
    val imagenUrl: String?,
    val categoria: String?
)
