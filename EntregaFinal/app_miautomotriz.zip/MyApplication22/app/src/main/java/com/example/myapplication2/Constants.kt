package com.example.myapplication2

object Constants {
    // API en servidor remoto
    const val BASE_URL = "https://proyecto.jakrarish.net/api/" 
    const val GET_REPARACIONES_URL = BASE_URL + "reparaciones.php"
    const val POST_REPARACION_URL = BASE_URL + "crear_reparacion.php"

    const val LOGIN_URL = BASE_URL + "login.php"
    const val REGISTER_URL = BASE_URL + "register.php"
    const val RECOVERY_URL = BASE_URL + "recuperar.php"
    const val GET_USER_URL = BASE_URL + "obtener_usuario.php"
    const val GET_PRODUCTS_URL = BASE_URL + "obtener_productos.php"
    const val GET_SERVICIO_URL = BASE_URL + "obtener_servicios.php"
    const val SET_CATALOGO_ULR = BASE_URL + "insertar_catalogo.php"
    const val UPDATE_CATALOGO_URL = BASE_URL + "actualizar_catalogo.php"
    const val GET_USUARIOS_URL = BASE_URL + "obtener_usuarios.php"
    const val DEL_FROM_CATALOGO_URL = BASE_URL + "eliminar_del_catalogo.php"

    const val GET_ALL_VEHICULOS_URL = BASE_URL + "obtener_all_vehiculos.php"
    const val GET_VEHICULO_ID_URL = BASE_URL + "obtener_vehiculo.php"
    const val GET_VEHICULOS_BY_PERSONA_URL = BASE_URL + "obtener_vehiculos_persona.php"
    const val ADD_VEHICULO_URL = BASE_URL + "insertar_vehiculo.php"
    const val UPDATE_VEHICULO_URL = BASE_URL + "actualizar_vehiculo.php"
    const val DELETE_VEHICULO_URL = BASE_URL + "eliminar_vehiculo.php"
    const val GET_PRESUPUESTO_BY_RUT_URL = BASE_URL + "obtener_presupuesto_by_rut.php"
    const val GET_PRESUPUESTOS_URL = BASE_URL + "obtener_presupuestos.php"

}
