package com.example.myapplication2.ui.usuarios

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.databinding.FragmentUsuariosBinding

class UsuariosFragment : Fragment() {

    private var _binding: FragmentUsuariosBinding? = null
    private val binding get() = _binding!!

    private val viewModel: UsuariosViewModel by viewModels()
    private lateinit var adapter: UsuariosAdapter
    private var listaUsuariosFull: List<Usuario> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUsuariosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupSearch()
        observeViewModel()

        viewModel.cargarUsuarios(requireContext())
    }

    private fun setupRecyclerView() {
        adapter = UsuariosAdapter(emptyList()) { usuario ->
            // TODO: Implementar navegación a pantalla de edición de usuario
            Toast.makeText(context, "Editar ${usuario.nombre}", Toast.LENGTH_SHORT).show()
        }
        binding.rvUsuarios.layoutManager = LinearLayoutManager(context)
        binding.rvUsuarios.adapter = adapter
    }

    private fun setupSearch() {
        binding.etBuscarUsuario.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filtrarUsuarios(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filtrarUsuarios(texto: String) {
        val textoFiltrado = texto.lowercase().trim()
        val listaFiltrada = if (textoFiltrado.isEmpty()) {
            listaUsuariosFull
        } else {
            listaUsuariosFull.filter { usuario ->
                usuario.nombre.lowercase().contains(textoFiltrado) ||
                usuario.apellido.lowercase().contains(textoFiltrado) ||
                usuario.rut.lowercase().contains(textoFiltrado)
            }
        }
        adapter.actualizarLista(listaFiltrada)
    }

    private fun observeViewModel() {
        viewModel.usuarios.observe(viewLifecycleOwner) {
            listaUsuariosFull = it
            // Si hay texto en el buscador, filtrar sobre la nueva lista, si no, mostrar todo
            val textoBusqueda = binding.etBuscarUsuario.text.toString()
            if (textoBusqueda.isNotEmpty()) {
                filtrarUsuarios(textoBusqueda)
            } else {
                adapter.actualizarLista(it)
            }
        }

        viewModel.isLoading.observe(viewLifecycleOwner) {
            binding.progressBarUsuarios.isVisible = it
        }

        viewModel.error.observe(viewLifecycleOwner) {
            if (it != null) {
                Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
