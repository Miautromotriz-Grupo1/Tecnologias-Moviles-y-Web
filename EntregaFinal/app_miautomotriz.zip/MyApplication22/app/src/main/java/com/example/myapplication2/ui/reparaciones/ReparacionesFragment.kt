package com.example.myapplication2.ui.reparaciones

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication2.R
import com.example.myapplication2.databinding.FragmentReparacionesBinding

class ReparacionesFragment : Fragment() {

    private var _binding: FragmentReparacionesBinding? = null
    // This property is only valid between onCreateView and onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReparacionesBinding.inflate(inflater, container, false)
        val root: View = binding.root

        binding.btnOrdenTrabajo.setOnClickListener {
            Toast.makeText(context, "Orden de Trabajo presionado", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la navegación a la pantalla de Orden de Trabajo
        }

        binding.btnVehiculo.setOnClickListener {
             findNavController().navigate(R.id.action_reparaciones_to_vehiculos)
        }

        binding.btnPresupuesto.setOnClickListener {
            Toast.makeText(context, "Presupuesto presionado", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la navegación a la pantalla de Presupuesto
        }

        binding.btnFactura.setOnClickListener {
            Toast.makeText(context, "Factura presionado", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la navegación a la pantalla de Factura
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
