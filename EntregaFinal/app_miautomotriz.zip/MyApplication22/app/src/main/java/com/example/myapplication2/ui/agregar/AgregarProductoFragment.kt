package com.example.myapplication2.ui.agregar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.example.myapplication2.Constants
import com.example.myapplication2.VolleySingleton
import com.example.myapplication2.databinding.FragmentAgregarProductoBinding
import org.json.JSONObject

class AgregarProductoFragment : Fragment() {

    private var _binding: FragmentAgregarProductoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAgregarProductoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rgTipo.setOnCheckedChangeListener { _, checkedId ->
            binding.layoutProductoFields.isVisible = checkedId == binding.rbProducto.id
        }

        binding.btnGuardar.setOnClickListener {
            guardarItem()
        }
    }

    private fun guardarItem() {
        val isProducto = binding.rbProducto.isChecked

        val nombre = binding.etNombre.text.toString().trim()
        val img = binding.etImg.text.toString().trim()
        val precioVenta = binding.etPrecio.text.toString().trim()

        if (nombre.isEmpty() || precioVenta.isEmpty()) {
            Toast.makeText(context, "Nombre y Precio Venta son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        // Si es producto, validamos los campos extra
        val precioCompra = binding.etPrecioC.text.toString().trim()
        val marca = binding.etMarca.text.toString().trim()
        val anio = binding.etAnio.text.toString().trim()
        val categoria = binding.etCategoria.text.toString().trim()
        val nBodega = binding.etBodega.text.toString().trim()
        val cantidad = binding.etStock.text.toString().trim()

        if (isProducto) {
            if (precioCompra.isEmpty() || marca.isEmpty() || anio.isEmpty() || categoria.isEmpty() || nBodega.isEmpty() || cantidad.isEmpty()) {
                Toast.makeText(context, "Todos los campos del producto son obligatorios", Toast.LENGTH_SHORT).show()
                return
            }
        }

        val url = Constants.SET_CATALOGO_ULR
        val params = JSONObject()

        try {
            params.put("nombre", nombre)
            params.put("precio", precioVenta) // PHP espera 'precio', no 'precio_v'
            params.put("img", img)

            if (isProducto) {
                params.put("servicio", 0)
                params.put("marca", marca)
                params.put("anio", anio)
                params.put("categoria", categoria)
                params.put("stock", cantidad) // PHP espera 'stock', no 'cantidad'

                // Campos adicionales que mencionaste (aunque el PHP actual no los use todos, los enviamos)
                params.put("precio_c", precioCompra)
                params.put("n_bodega", nBodega)
            } else {
                params.put("servicio", 1)
                params.put("categoria", "servicio")
                params.put("marca", "Miutomotriz")

                // Valores por defecto para campos numéricos requeridos
                params.put("stock", 0)
                params.put("anio", 0)
                params.put("precio_c", 0)
                params.put("n_bodega", 0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error al crear JSON", Toast.LENGTH_SHORT).show()
            return
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, params,
            { response ->
                val mensaje = response.optString("mensaje", "Guardado con éxito")
                Toast.makeText(context, mensaje, Toast.LENGTH_LONG).show()
                findNavController().popBackStack()
            },
            { error ->
                val errorMsg = if (error.networkResponse != null && error.networkResponse.data != null) {
                    String(error.networkResponse.data)
                } else {
                    error.message ?: "Error desconocido"
                }
                Toast.makeText(context, "Error al guardar: $errorMsg", Toast.LENGTH_LONG).show()
            }
        )

        VolleySingleton.getInstance(requireContext()).addToRequestQueue(jsonObjectRequest)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}