package com.example.myapplication2

import com.google.gson.annotations.SerializedName

// Modelo de datos que coincide con el JSON de la API
data class Presupuesto(
    @SerializedName("id") val id: Int,
    @SerializedName("nombre_cli") val nombreCliente: String?,
    @SerializedName("apellido_cli") val apellidoCliente: String?,
    @SerializedName("rut_cli") val rutCliente: String,
    @SerializedName("total") val total: Float,
    @SerializedName("iva") val iva: Float,
    @SerializedName("subtotal") val subtotal: Float,
    @SerializedName("fecha") val fecha: String,
    @SerializedName("telefono1_cli") val telefono: String?,
    @SerializedName("correo_cli") val correo: String?,
    @SerializedName("vin_vehiculo") val vinVehiculo: String?,
    @SerializedName("direccion_cli") val direccion: String?,
    @SerializedName("estado") val estado: Boolean,
    @SerializedName("observaciones") val observaciones: String?,
    @SerializedName("notas") val notas: String?,
    @SerializedName("creado") val creado: String
)
