package com.example.myapplication2.ui.presupuestos

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication2.Constants
import com.example.myapplication2.Presupuesto
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PresupuestosViewModel(application: Application) : AndroidViewModel(application) {

    private val _presupuestos = MutableLiveData<List<Presupuesto>>()
    val presupuestos: LiveData<List<Presupuesto>> = _presupuestos

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        cargarPresupuestosDesdeApi()
    }

    private fun cargarPresupuestosDesdeApi() {
        _isLoading.value = true

        // --- CORRECCIÓN FINAL ---
        // Nombre del archivo de preferencias: "UserSession" (con mayúsculas, como en LoginActivity y otros fragments)
        val sharedPreferences = getApplication<Application>().getSharedPreferences(
            "UserSession", // Nombre correcto encontrado en el proyecto
            Context.MODE_PRIVATE
        )
        val rutUsuario = sharedPreferences.getString("user_rut", null) 

        if (rutUsuario.isNullOrEmpty()) {
            Log.e(
                "PresupuestosViewModel",
                "RUT de usuario no encontrado en SharedPreferences 'UserSession' con clave 'user_rut'"
            )
            _isLoading.value = false
            return
        }

        val url = Constants.GET_PRESUPUESTO_BY_RUT_URL + "?creado_por_rut=" + rutUsuario

        val request = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                try {
                    val gson = Gson()
                    val type = object : TypeToken<List<Presupuesto>>() {}.type
                    val listaPresupuestos: List<Presupuesto> =
                        gson.fromJson(response.toString(), type)
                    _presupuestos.value = listaPresupuestos
                } catch (e: Exception) {
                    Log.e("PresupuestosViewModel", "Error parseando JSON: ${e.message}")
                } finally {
                    _isLoading.value = false
                }
            },
            { error ->
                Log.e("PresupuestosViewModel", "Error en la petición: ${error.message}")
                _isLoading.value = false
            }
        )

        Volley.newRequestQueue(getApplication()).add(request)
    }
}
