package com.example.myapplication2.ui.productos

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication2.R
import com.example.myapplication2.databinding.FragmentProductosBinding
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.NumberFormat
import java.util.Locale

class ProductosFragment : Fragment() {

    private var _binding: FragmentProductosBinding? = null
    private val binding get() = _binding!!

    private lateinit var productosViewModel: ProductosViewModel
    
    // Componentes del carrito
    private var carritoAdapter: CarritoAdapter? = null
    private val listaCarrito = mutableListOf<Producto>()
    private var recyclerCarrito: RecyclerView? = null
    private var tvTotalCarrito: TextView? = null
    private var btnFinalizarCompra: Button? = null

    // Estado para controlar qué pestaña se muestra
    private var isShowingServicios = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProductosBinding.inflate(inflater, container, false)
        val root: View = binding.root

        try {
            productosViewModel = ViewModelProvider(this).get(ProductosViewModel::class.java)

            // Usamos context seguro
            val contextSafe = context ?: requireContext()
            val sharedPreferences = contextSafe.getSharedPreferences("UserSession", Context.MODE_PRIVATE)

            val empleadoLevel = sharedPreferences.getInt("user_empleado_level", 0)
            
            // Botón flotante para agregar nuevos items (solo admins/empleados)
            if (empleadoLevel == 1 || empleadoLevel == 2) {
                binding.actionToAgregarProducto.visibility = View.VISIBLE
            } else {
                binding.actionToAgregarProducto.visibility = View.GONE
            }

            // Configuración segura del Carrito
            configurarCarrito(root)
            
            // Cargar carrito guardado
            cargarCarritoDePreferencias()

            val adapter = ProductosAdapter(
                onAgregarCarrito = { producto ->
                    agregarAlCarrito(producto)
                },
                onEditarProducto = { producto ->
                    val action = ProductosFragmentDirections.actionProductosToEditar(producto)
                    findNavController().navigate(action)
                }
            )
            
            binding.recyclerProductos.layoutManager = LinearLayoutManager(context)
            binding.recyclerProductos.adapter = adapter

            // Observamos cambios
            productosViewModel.productos.observe(viewLifecycleOwner) { productos ->
                adapter.submitList(productos)
            }

            // Configuración de Tabs (Productos / Servicios)
            configurarTabs(contextSafe, adapter)

            // Carga inicial (Productos)
            productosViewModel.cargarDatos(contextSafe, false)
            binding.textProducto.text = "Productos"
            
            binding.actionToAgregarProductoAlCarrito.setOnClickListener {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.END)
                } else {
                    binding.drawerLayout.openDrawer(GravityCompat.END)
                }
            }
            
            // Navegación a Agregar Producto
            binding.actionToAgregarProducto.setOnClickListener {
                findNavController().navigate(R.id.action_productos_to_agregar)
            }

        } catch (e: Exception) {
            Log.e("ProductosFragment", "Error en onCreateView", e)
            Toast.makeText(context, "Error al iniciar: ${e.message}", Toast.LENGTH_LONG).show()
        }

        return root
    }

    private fun configurarTabs(context: Context, adapter: ProductosAdapter) {
        val colorPrimary = android.util.TypedValue()
        context.theme.resolveAttribute(android.R.attr.colorPrimary, colorPrimary, true)
        
        val textColorSecondary = android.util.TypedValue()
        context.theme.resolveAttribute(android.R.attr.textColorSecondary, textColorSecondary, true)

        binding.btnTabProductos.setOnClickListener {
            if (isShowingServicios) {
                isShowingServicios = false
                actualizarEstiloTabs(context)
                binding.textProducto.text = "Productos"
                productosViewModel.cargarDatos(context, false)
            }
        }

        binding.btnTabServicios.setOnClickListener {
            if (!isShowingServicios) {
                isShowingServicios = true
                actualizarEstiloTabs(context)
                binding.textProducto.text = "Servicios"
                productosViewModel.cargarDatos(context, true)
            }
        }
    }

    private fun actualizarEstiloTabs(context: Context) {
        val colorPrimary = android.util.TypedValue()
        context.theme.resolveAttribute(android.R.attr.colorPrimary, colorPrimary, true)
        
        // Colores seguros si falla la resolución de atributos
        val primaryColor = if (colorPrimary.resourceId != 0) context.getColor(colorPrimary.resourceId) else 0xFF6200EE.toInt()
        val grayColor = 0xFF757575.toInt()

        if (isShowingServicios) {
            // Activar Servicios
            binding.btnTabServicios.setTextColor(primaryColor)
            binding.btnTabServicios.setTypeface(null, Typeface.BOLD)
            
            // Desactivar Productos
            binding.btnTabProductos.setTextColor(grayColor)
            binding.btnTabProductos.setTypeface(null, Typeface.NORMAL)
        } else {
            // Activar Productos
            binding.btnTabProductos.setTextColor(primaryColor)
            binding.btnTabProductos.setTypeface(null, Typeface.BOLD)
            
            // Desactivar Servicios
            binding.btnTabServicios.setTextColor(grayColor)
            binding.btnTabServicios.setTypeface(null, Typeface.NORMAL)
        }
    }

    private fun configurarCarrito(root: View) {
        try {
            recyclerCarrito = root.findViewById(R.id.recyclerCarrito)
            tvTotalCarrito = root.findViewById(R.id.tvTotalCarrito)
            btnFinalizarCompra = root.findViewById(R.id.btnFinalizarCompra)

            carritoAdapter = CarritoAdapter { producto ->
                eliminarDelCarrito(producto)
            }
            
            recyclerCarrito?.layoutManager = LinearLayoutManager(context)
            recyclerCarrito?.adapter = carritoAdapter
            
            btnFinalizarCompra?.setOnClickListener {
                if (listaCarrito.isEmpty()) {
                    Toast.makeText(context, "El carrito está vacío", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Compra finalizada (simulada)", Toast.LENGTH_SHORT).show()
                    listaCarrito.clear()
                    guardarCarritoEnPreferencias()
                    actualizarCarritoUI()
                    binding.drawerLayout.closeDrawer(GravityCompat.END)
                }
            }
        } catch (e: Exception) {
            Log.e("ProductosFragment", "Error configurando UI carrito", e)
        }
    }

    private fun agregarAlCarrito(producto: Producto) {
        listaCarrito.add(producto)
        actualizarCarritoUI()
        guardarCarritoEnPreferencias()
        Toast.makeText(context, "${producto.nombre} agregado", Toast.LENGTH_SHORT).show()
    }
    
    private fun eliminarDelCarrito(producto: Producto) {
        listaCarrito.remove(producto) 
        actualizarCarritoUI()
        guardarCarritoEnPreferencias()
        Toast.makeText(context, "Producto eliminado", Toast.LENGTH_SHORT).show()
    }

    private fun actualizarCarritoUI() {
        try {
            carritoAdapter?.submitList(ArrayList(listaCarrito))
            
            var total = 0
            for (p in listaCarrito) {
                total += p.precio
            }
            
            val format = NumberFormat.getCurrencyInstance(Locale("es", "CL"))
            tvTotalCarrito?.text = "Total: ${format.format(total)}"
        } catch (e: Exception) {
            Log.e("ProductosFragment", "Error actualizando UI", e)
        }
    }
    
    private fun guardarCarritoEnPreferencias() {
        if (!isAdded || context == null) return
        try {
            val sharedPreferences = requireContext().getSharedPreferences("CarritoCompras", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            val gson = Gson()
            val json = gson.toJson(listaCarrito)
            editor.putString("lista_productos", json)
            editor.apply()
        } catch (e: Exception) {
            Log.e("ProductosFragment", "Error guardando carrito", e)
        }
    }

    private fun cargarCarritoDePreferencias() {
        if (!isAdded || context == null) return
        try {
            val sharedPreferences = requireContext().getSharedPreferences("CarritoCompras", Context.MODE_PRIVATE)
            val json = sharedPreferences.getString("lista_productos", null)
            
            if (json != null) {
                val gson = Gson()
                val type = object : TypeToken<MutableList<Producto>>() {}.type
                val productosGuardados: MutableList<Producto> = gson.fromJson(json, type)
                
                listaCarrito.clear()
                listaCarrito.addAll(productosGuardados)
                actualizarCarritoUI()
            }
        } catch (e: Exception) {
            Log.e("ProductosFragment", "Error cargando carrito", e)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}