package com.example.myapplication2.ui.presupuestos

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication2.Presupuesto
import com.example.myapplication2.databinding.FragmentPresupuestosBinding

class PresupuestosFragment : Fragment() {

    private var _binding: FragmentPresupuestosBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: PresupuestosViewModel
    private lateinit var adapter: PresupuestosAdapter
    private var listaPresupuestosFull: List<Presupuesto> = listOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this).get(PresupuestosViewModel::class.java)

        _binding = FragmentPresupuestosBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupRecyclerView()
        setupSearch()
        observeViewModel()

        return root
    }

    private fun setupRecyclerView() {
        adapter = PresupuestosAdapter(listOf()) { presupuesto ->
            // Acción al hacer clic en "Ver Detalle"
            Toast.makeText(requireContext(), "Detalle de: ${presupuesto.id}", Toast.LENGTH_SHORT).show()
            // Aquí podrías navegar a un fragmento de detalle si lo deseas
        }
        binding.rvPresupuestos.layoutManager = LinearLayoutManager(context)
        binding.rvPresupuestos.adapter = adapter
    }

    private fun setupSearch() {
        binding.etBuscarPresupuesto.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filtrarPresupuestos(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filtrarPresupuestos(texto: String) {
        val textoBusqueda = texto.lowercase()
        val listaFiltrada = if (textoBusqueda.isEmpty()) {
            listaPresupuestosFull
        } else {
            listaPresupuestosFull.filter {
                it.id.toString().contains(textoBusqueda) ||
                (it.vinVehiculo?.lowercase()?.contains(textoBusqueda) == true)
            }
        }
        adapter.updateList(listaFiltrada)
    }

    private fun observeViewModel() {
        viewModel.presupuestos.observe(viewLifecycleOwner) { presupuestos ->
            listaPresupuestosFull = presupuestos
            // Si ya hay texto en el buscador, filtrar inmediatamente
            val textoActual = binding.etBuscarPresupuesto.text.toString()
            if (textoActual.isNotEmpty()) {
                filtrarPresupuestos(textoActual)
            } else {
                adapter.updateList(presupuestos)
            }
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBarPresupuestos.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
