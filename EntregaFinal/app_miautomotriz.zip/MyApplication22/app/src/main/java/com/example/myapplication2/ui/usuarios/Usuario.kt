package com.example.myapplication2.ui.usuarios

import java.io.Serializable

data class Usuario(
    val rut: String,
    val nombre: String,
    val apellido: String,
    val correo: String,
    val telefono: String?,
    val direccion: String?,
    val personaveri: String?,
    val empleado: String? // Texto para mostrar (Cliente, Empleado, etc.)
) : Serializable
