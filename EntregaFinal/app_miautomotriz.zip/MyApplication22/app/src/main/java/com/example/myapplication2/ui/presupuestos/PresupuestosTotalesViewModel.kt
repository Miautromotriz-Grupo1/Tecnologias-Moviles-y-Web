package com.example.myapplication2.ui.presupuestos

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication2.Constants
import com.example.myapplication2.Presupuesto
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PresupuestosTotalesViewModel(application: Application) : AndroidViewModel(application) {

    private val _presupuestos = MutableLiveData<List<Presupuesto>>()
    val presupuestos: LiveData<List<Presupuesto>> = _presupuestos

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        cargarTodosLosPresupuestos()
    }

    private fun cargarTodosLosPresupuestos() {
        _isLoading.value = true

        val url = Constants.GET_PRESUPUESTOS_URL

        val request = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                try {
                    val gson = Gson()
                    val type = object : TypeToken<List<Presupuesto>>() {}.type
                    val listaPresupuestos: List<Presupuesto> =
                        gson.fromJson(response.toString(), type)
                    _presupuestos.value = listaPresupuestos
                } catch (e: Exception) {
                    Log.e("PresupuestosTotalesVM", "Error parseando JSON: ${e.message}")
                } finally {
                    _isLoading.value = false
                }
            },
            { error ->
                Log.e("PresupuestosTotalesVM", "Error en la petición: ${error.message}")
                _isLoading.value = false
            }
        )

        Volley.newRequestQueue(getApplication()).add(request)
    }
}
