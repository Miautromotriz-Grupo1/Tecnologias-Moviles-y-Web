package com.example.myapplication2.ui.vehiculos

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication2.Constants
import com.example.myapplication2.ui.vehiculos.Vehiculo
import com.example.myapplication2.databinding.FragmentVehiculosBinding
import org.json.JSONException
import org.json.JSONObject

class VehiculosFragment : Fragment() {

    private var _binding: FragmentVehiculosBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: VehiculoAdapter
    private val vehiculosList = mutableListOf<Vehiculo>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVehiculosBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupRecyclerView()
        setupListeners()
        loadVehiculos()

        return root
    }

    private fun setupRecyclerView() {
        adapter = VehiculoAdapter(vehiculosList) { vehiculo ->
            deleteVehiculo(vehiculo.id_car)
        }
        binding.recyclerViewVehiculos.layoutManager = LinearLayoutManager(context)
        binding.recyclerViewVehiculos.adapter = adapter
    }

    private fun setupListeners() {
        binding.fabAddVehiculo.setOnClickListener {
            // Aquí iría la navegación a la pantalla de agregar vehículo
            Toast.makeText(context, "Agregar Vehículo presionado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteVehiculo(idVehiculo: String) {
        val url = Constants.DELETE_VEHICULO_URL
        Log.d("DeleteVehiculo", "Request URL for POST: $url with ID: $idVehiculo")

        val request = object : StringRequest(Request.Method.POST, url,
            { response ->
                try {
                    // Intenta parsear la respuesta como JSON para un manejo más robusto
                    val jsonResponse = JSONObject(response)
                    if (jsonResponse.has("success")) {
                        Log.d("DeleteVehiculo", "Success response: $response")
                        Toast.makeText(context, "Vehículo eliminado correctamente", Toast.LENGTH_SHORT).show()
                        loadVehiculos() // Recargar la lista de vehículos
                    } else {
                        val errorMessage = jsonResponse.optString("error", "Error desconocido del servidor.")
                        Log.e("DeleteVehiculo", "Server error: $errorMessage")
                        Toast.makeText(context, "Error al eliminar: $errorMessage", Toast.LENGTH_LONG).show()
                    }
                } catch (e: JSONException) {
                    // Si la respuesta no es un JSON, puede ser un mensaje de error o éxito en texto plano.
                    Log.d("DeleteVehiculo", "Non-JSON response: $response")
                    Toast.makeText(context, "Vehículo eliminado. Respuesta: $response", Toast.LENGTH_SHORT).show()
                    loadVehiculos()
                }
            },
            { error ->
                var errorMessage = "Error de red al intentar eliminar."
                val networkResponse = error.networkResponse
                if (networkResponse != null && networkResponse.data != null) {
                    val errorData = String(networkResponse.data)
                    Log.e("DeleteVehiculo", "Volley error body: $errorData")
                    errorMessage = "Error del servidor: $errorData"
                } else {
                    Log.e("DeleteVehiculo", "Volley error: ${error.message}")
                }
                Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["id_car"] = idVehiculo
                return params
            }
        }
        
        Volley.newRequestQueue(requireContext()).add(request)
    }


    private fun loadVehiculos() {
        val sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userRut = sharedPreferences.getString("user_rut", "")

        if (userRut.isNullOrEmpty()) {
            Toast.makeText(context, "No se encontró sesión de usuario", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.tvEmpty.visibility = View.GONE

        val url = "${Constants.GET_VEHICULOS_BY_PERSONA_URL}?persona=$userRut"
        Log.d("VehiculosFragment", "Request URL: $url")

        val request = JsonArrayRequest(Request.Method.GET, url, null,
            { response ->
                binding.progressBar.visibility = View.GONE
                vehiculosList.clear()
                try {
                    for (i in 0 until response.length()) {
                        val item = response.getJSONObject(i)
                        
                        val vehiculo = Vehiculo(
                            id_car = item.optString("id_car", ""),
                            marca_car = item.optString("marca_car", "Sin marca"),
                            modelo_car = item.optString("modelo_car", "Sin modelo"),
                            anio_car = item.optString("anio_car", "0"),
                            vin_vehiculo = item.optString("vin_vehiculo", ""),
                            color_car = item.optString("color_car", ""),
                            tipodevehiculo = item.optString("tipodevehiculo", ""),
                            matricula = item.optString("matricula", "Sin matrícula"),
                            persona = item.optString("personaid", ""),
                            kilometraje = item.optInt("kilometraje", 0),
                            n_chasis = item.optString("n_chasis", "")
                        )
                        vehiculosList.add(vehiculo)
                    }
                    adapter.notifyDataSetChanged()

                    if (vehiculosList.isEmpty()) {
                        binding.tvEmpty.text = "No hay vehículos registrados"
                        binding.tvEmpty.visibility = View.VISIBLE
                    }
                } catch (e: JSONException) {
                    Log.e("VehiculosFragment", "Error parsing JSON", e)
                    Toast.makeText(context, "Error al procesar los datos", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                binding.progressBar.visibility = View.GONE
                Log.e("VehiculosFragment", "Error fetching data", error)
                Toast.makeText(context, "Error al cargar vehículos: ${error.message}", Toast.LENGTH_SHORT).show()
                binding.tvEmpty.text = "Error de conexión"
                binding.tvEmpty.visibility = View.VISIBLE
            }
        )

        Volley.newRequestQueue(requireContext()).add(request)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
