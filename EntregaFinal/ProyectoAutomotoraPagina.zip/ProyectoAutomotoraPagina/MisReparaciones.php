<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar sesión y permisos (Empleados y Admin)
if (!isset($_SESSION['empleado']) || !in_array($_SESSION['empleado'], [1, 2])) {
    header("Location: index.php");
    exit(); 
}

include 'conexion.php';
include 'header.php';
?>

<main class="min-h-screen bg-skin-base">
    <section class="max-w-6xl mx-auto py-8 px-4">
        <!-- Encabezado y Botones -->
        <div class="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <div class="flex items-center gap-4">
                <a href="funciones.php" class="inline-flex items-center px-3 py-2 bg-skin-card border border-skin-border hover:bg-skin-base rounded-lg shadow-sm transition-colors duration-200 text-skin-muted">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                    </svg>
                    Volver
                </a>
                <h1 class="text-2xl font-bold text-gray-800">Mis Reparaciones</h1>
            </div>

            <button id="btn-nueva-reparacion" class="px-4 py-2 bg-skin-accent hover:bg-skin-accent-hover text-white rounded-lg shadow transition-colors duration-200 font-medium flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Nueva Orden de Trabajo
            </button>
        </div>

        <!-- Listado de Reparaciones -->
        <div class="bg-skin-card rounded-lg shadow border border-skin-border overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full table-auto divide-y divide-skin-border">
                    <thead class="bg-skin-base">
                        <tr class="text-left text-sm font-medium text-gray-500">
                            <th class="px-6 py-3">ID</th>
                            <th class="px-6 py-3">Cliente</th>
                            <th class="px-6 py-3">Vehículo</th>
                            <th class="px-6 py-3">Fecha Entrega</th>
                            <th class="px-6 py-3 text-right">Total Estimado</th>
                            <th class="px-6 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="lista-reparaciones" class="divide-y divide-skin-border text-sm">
                        <!-- Se llena dinámicamente con JS -->
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-gray-500">Cargando reparaciones...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- Modal Formulario de Reparación -->
    <div id="modal-reparacion" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
        <div class="bg-skin-card rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            
            <!-- Header Modal -->
            <div class="px-6 py-4 border-b border-skin-border flex justify-between items-center bg-skin-base">
                <h2 class="text-xl font-bold text-gray-800" id="modal-title">Nueva Orden de Trabajo</h2>
                <button id="btn-cerrar-modal" class="text-gray-500 hover:text-gray-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <!-- Body Modal (Scrollable) -->
            <div class="p-6 overflow-y-auto flex-1">
                <form id="form-reparacion" class="space-y-6">
                    <input type="hidden" id="rep-id" name="id">

                    <!-- Buscador de Cotización -->
                    <div class="bg-blue-50 p-4 rounded-lg border border-blue-100">
                        <label class="block text-sm font-medium text-blue-800 mb-2">Cargar datos desde Cotización</label>
                        <div class="flex gap-2">
                            <input type="number" id="search-cotizacion" placeholder="Ingrese N° de Cotización" class="flex-1 p-2 border border-blue-200 rounded focus:ring-2 focus:ring-blue-500 outline-none">
                            <button type="button" id="btn-importar-cotizacion" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors font-medium flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" /></svg>
                                Buscar
                            </button>
                        </div>
                    </div>

                    <!-- Sección 1: Datos Generales -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Fecha Estimada de Entrega</label>
                            <input type="date" id="rep-fecha" name="fecha" class="w-full p-2 border border-skin-border rounded-lg bg-skin-base focus:ring-2 focus:ring-skin-accent focus:border-transparent" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Imagen Referencial (URL)</label>
                            <input type="text" id="rep-img" name="img" placeholder="https://ejemplo.com/imagen.jpg" class="w-full p-2 border border-skin-border rounded-lg bg-skin-base focus:ring-2 focus:ring-skin-accent focus:border-transparent">
                        </div>
                    </div>

                    <hr class="border-skin-border">

                    <!-- Sección 2: Cliente y Vehículo -->
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Datos Cliente -->
                        <div class="space-y-4">
                            <h3 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-skin-accent" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" /></svg>
                                Datos del Cliente
                            </h3>
                            <div class="grid grid-cols-1 gap-3">
                                <input type="text" id="rep-cliente" placeholder="Nombre Completo *" class="w-full p-2 border border-skin-border rounded bg-skin-base" required>
                                <input type="text" id="rep-rut" placeholder="RUT" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="tel" id="rep-telefono" placeholder="Teléfono / Contacto" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="email" id="rep-correo" placeholder="Correo Electrónico" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                            </div>
                        </div>

                        <!-- Datos Vehículo -->
                        <div class="space-y-4">
                            <h3 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-skin-accent" viewBox="0 0 20 20" fill="currentColor"><path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" /><path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05A2.5 2.5 0 0115.95 16H17a1 1 0 001-1v-5a1 1 0 00-.293-.707l-2-2A1 1 0 0015 7h-1z" /></svg>
                                Datos del Vehículo
                            </h3>
                            <div class="grid grid-cols-2 gap-3">
                                <input type="text" id="rep-marca" placeholder="Marca" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="text" id="rep-modelo" placeholder="Modelo" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="text" id="rep-patente" placeholder="Patente" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="number" id="rep-anio" placeholder="Año" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="text" id="rep-color" placeholder="Color" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                                <input type="number" id="rep-km" placeholder="Kilometraje" class="w-full p-2 border border-skin-border rounded bg-skin-base">
                            </div>
                        </div>
                    </div>

                    <hr class="border-skin-border">

                    <!-- Sección 3: Detalles / Items -->
                    <div>
                        <div class="flex justify-between items-center mb-3">
                            <h3 class="text-lg font-semibold text-gray-800">Detalles de Mano de Obra y Repuestos</h3>
                            <button type="button" id="btn-add-item" class="px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm font-medium transition-colors">
                                + Agregar Item
                            </button>
                        </div>
                        
                        <div class="border border-skin-border rounded-lg overflow-hidden">
                            <table class="w-full text-sm">
                                <thead class="bg-skin-base text-gray-500">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Descripción</th>
                                        <th class="px-4 py-2 w-24 text-center">Cant.</th>
                                        <th class="px-4 py-2 w-32 text-right">Precio Unit.</th>
                                        <th class="px-4 py-2 w-32 text-right">Total</th>
                                        <th class="px-4 py-2 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody id="items-container" class="divide-y divide-skin-border bg-skin-card">
                                    <!-- Items dinámicos -->
                                </tbody>
                                <tfoot class="bg-skin-base font-medium">
                                    <tr>
                                        <td colspan="3" class="px-4 py-2 text-right text-gray-600">Total Neto:</td>
                                        <td class="px-4 py-2 text-right" id="total-neto">$0</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="px-4 py-2 text-right text-gray-600">IVA (19%):</td>
                                        <td class="px-4 py-2 text-right" id="total-iva">$0</td>
                                        <td></td>
                                    </tr>
                                    <tr class="text-lg font-bold text-gray-800">
                                        <td colspan="3" class="px-4 py-3 text-right">Total Final:</td>
                                        <td class="px-4 py-3 text-right" id="total-final">$0</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <!-- Sección 4: Observaciones -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Observaciones / Detalles Adicionales</label>
                        <textarea id="rep-detalles" rows="3" class="w-full p-2 border border-skin-border rounded-lg bg-skin-base focus:ring-2 focus:ring-skin-accent focus:border-transparent"></textarea>
                    </div>

                </form>
            </div>

            <!-- Footer Modal -->
            <div class="px-6 py-4 border-t border-skin-border bg-skin-base flex justify-end gap-3">
                <button type="button" id="btn-cancelar" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 font-medium transition-colors">
                    Cancelar
                </button>
                <button type="button" id="btn-guardar" class="px-6 py-2 bg-skin-accent text-white rounded-lg hover:bg-skin-accent-hover font-medium shadow-md transition-transform transform active:scale-95">
                    Guardar Orden
                </button>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('modal-reparacion');
    const form = document.getElementById('form-reparacion');
    const listaReparaciones = document.getElementById('lista-reparaciones');
    const itemsContainer = document.getElementById('items-container');
    
    // --- Funciones de Utilidad ---
    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);
    };

    const showModal = () => {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    };

    const hideModal = () => {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    };

    // --- Gestión de Items ---
    const createItemRow = (data = { desc: '', cant: 1, precio: 0 }) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="px-2 py-2"><input type="text" class="w-full p-1 border rounded item-desc" value="${data.desc}" placeholder="Descripción" required></td>
            <td class="px-2 py-2"><input type="number" class="w-full p-1 border rounded text-center item-cant" value="${data.cant}" min="1"></td>
            <td class="px-2 py-2"><input type="number" class="w-full p-1 border rounded text-right item-precio" value="${data.precio}" min="0"></td>
            <td class="px-4 py-2 text-right font-medium item-total">$0</td>
            <td class="px-2 py-2 text-center"><button type="button" class="text-red-500 hover:text-red-700 btn-del-item">&times;</button></td>
        `;
        
        // Eventos para recálculo
        const inputs = tr.querySelectorAll('input');
        inputs.forEach(input => input.addEventListener('input', () => calculateRowTotal(tr)));
        
        tr.querySelector('.btn-del-item').addEventListener('click', () => {
            tr.remove();
            calculateTotals();
        });

        itemsContainer.appendChild(tr);
        calculateRowTotal(tr);
    };

    const calculateRowTotal = (tr) => {
        const cant = parseFloat(tr.querySelector('.item-cant').value) || 0;
        const precio = parseFloat(tr.querySelector('.item-precio').value) || 0;
        const total = cant * precio;
        tr.querySelector('.item-total').textContent = formatCurrency(total);
        tr.dataset.total = total;
        calculateTotals();
    };

    const calculateTotals = () => {
        let neto = 0;
        document.querySelectorAll('#items-container tr').forEach(tr => {
            neto += parseFloat(tr.dataset.total) || 0;
        });
        
        const iva = neto * 0.19;
        const final = neto + iva;

        document.getElementById('total-neto').textContent = formatCurrency(neto);
        document.getElementById('total-iva').textContent = formatCurrency(iva);
        document.getElementById('total-final').textContent = formatCurrency(final);
    };

    // --- Cargar Datos ---
    const loadReparaciones = async () => {
        try {
            const res = await fetch('save_reparacion.php');
            const data = await res.json();
            
            if (data.success && data.lista) {
                listaReparaciones.innerHTML = '';
                if (data.lista.length === 0) {
                    listaReparaciones.innerHTML = '<tr><td colspan="6" class="px-6 py-8 text-center text-gray-500">No hay reparaciones registradas.</td></tr>';
                    return;
                }

                data.lista.forEach(rep => {
                    // Calcular total desde items si existe
                    let total = 0;
                    if (rep.items && Array.isArray(rep.items)) {
                        const subtotal = rep.items.reduce((acc, item) => acc + (item.cantidad * item.precio), 0);
                        total = subtotal * 1.19; // + IVA
                    }

                    const tr = document.createElement('tr');
                    tr.className = 'hover:bg-skin-base transition-colors';
                    tr.innerHTML = `
                        <td class="px-6 py-4 font-mono text-xs text-gray-500">#${rep.id}</td>
                        <td class="px-6 py-4 font-medium">${rep.cliente || 'Sin nombre'}</td>
                        <td class="px-6 py-4 text-gray-600">${rep.marca || ''} ${rep.modelo || ''} <span class="text-xs bg-gray-100 px-2 py-1 rounded">${rep.patente || ''}</span></td>
                        <td class="px-6 py-4">${rep.fecha || '-'}</td>
                        <td class="px-6 py-4 text-right font-semibold text-gray-800">${formatCurrency(total)}</td>
                        <td class="px-6 py-4 text-center">
                            <div class="flex justify-center gap-2">
                                <button class="p-1 text-blue-600 hover:bg-blue-50 rounded btn-editar" data-id="${rep.id}">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg>
                                </button>
                                <button class="p-1 text-red-600 hover:bg-red-50 rounded btn-eliminar" data-id="${rep.id}">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                                </button>
                            </div>
                        </td>
                    `;
                    listaReparaciones.appendChild(tr);
                });

                // Listeners dinámicos
                document.querySelectorAll('.btn-editar').forEach(btn => {
                    btn.addEventListener('click', () => loadReparacionDetalle(btn.dataset.id));
                });
                document.querySelectorAll('.btn-eliminar').forEach(btn => {
                    btn.addEventListener('click', () => deleteReparacion(btn.dataset.id));
                });
            }
        } catch (e) {
            console.error(e);
            listaReparaciones.innerHTML = '<tr><td colspan="6" class="text-center text-red-500 py-4">Error al cargar datos</td></tr>';
        }
    };

    const loadReparacionDetalle = async (id) => {
        try {
            const res = await fetch(`save_reparacion.php?id=${id}`);
            const data = await res.json();
            
            if (data.success && data.orden) {
                const orden = data.orden;
                
                // Llenar formulario
                document.getElementById('rep-id').value = orden.id;
                document.getElementById('rep-fecha').value = orden.fecha || '';
                document.getElementById('rep-img').value = orden.img || '';
                document.getElementById('rep-cliente').value = orden.cliente || '';
                document.getElementById('rep-rut').value = orden.rut || '';
                document.getElementById('rep-telefono').value = orden.telefono || '';
                document.getElementById('rep-correo').value = orden.correo || '';
                document.getElementById('rep-marca').value = orden.marca || '';
                document.getElementById('rep-modelo').value = orden.modelo || '';
                document.getElementById('rep-patente').value = orden.patente || '';
                document.getElementById('rep-anio').value = orden.anio || '';
                document.getElementById('rep-color').value = orden.color || '';
                document.getElementById('rep-km').value = orden.km || '';
                document.getElementById('rep-detalles').value = orden.detalles_texto || '';

                // Llenar items
                itemsContainer.innerHTML = '';
                if (orden.items && Array.isArray(orden.items)) {
                    orden.items.forEach(item => {
                        createItemRow({
                            desc: item.descripcion,
                            cant: item.cantidad,
                            precio: item.precio
                        });
                    });
                } else {
                    createItemRow(); // Fila vacía por defecto
                }

                document.getElementById('modal-title').textContent = `Editar Orden #${orden.id}`;
                showModal();
            }
        } catch (e) {
            alert('Error al cargar la orden');
        }
    };

    const deleteReparacion = async (id) => {
        if (!confirm('¿Estás seguro de eliminar esta orden?')) return;
        
        try {
            const res = await fetch(`save_reparacion.php?id=${id}`, { method: 'DELETE' });
            const data = await res.json();
            if (data.success) {
                loadReparaciones();
            } else {
                alert('Error al eliminar');
            }
        } catch (e) {
            alert('Error de conexión');
        }
    };

    // --- Guardar ---
    document.getElementById('btn-guardar').addEventListener('click', async () => {
        // Validar campos básicos
        if (!document.getElementById('rep-cliente').value) {
            alert('El nombre del cliente es obligatorio');
            return;
        }

        // Recopilar items
        const items = [];
        document.querySelectorAll('#items-container tr').forEach(tr => {
            const desc = tr.querySelector('.item-desc').value;
            if (desc) {
                items.push({
                    descripcion: desc,
                    cantidad: parseFloat(tr.querySelector('.item-cant').value) || 0,
                    precio: parseFloat(tr.querySelector('.item-precio').value) || 0
                });
            }
        });

        const payload = {
            id: document.getElementById('rep-id').value || 'Nuevo',
            fecha: document.getElementById('rep-fecha').value,
            img: document.getElementById('rep-img').value,
            cliente: document.getElementById('rep-cliente').value,
            rut: document.getElementById('rep-rut').value,
            telefono: document.getElementById('rep-telefono').value,
            correo: document.getElementById('rep-correo').value,
            marca: document.getElementById('rep-marca').value,
            modelo: document.getElementById('rep-modelo').value,
            patente: document.getElementById('rep-patente').value,
            anio: document.getElementById('rep-anio').value,
            color: document.getElementById('rep-color').value,
            km: document.getElementById('rep-km').value,
            detalles_texto: document.getElementById('rep-detalles').value,
            items: items
        };

        try {
            const res = await fetch('save_reparacion.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            
            if (data.success) {
                hideModal();
                loadReparaciones();
                alert('Orden guardada correctamente');
            } else {
                alert('Error al guardar: ' + (data.error || 'Desconocido'));
            }
        } catch (e) {
            alert('Error de conexión al guardar');
        }
    });

    // --- Event Listeners UI ---
    document.getElementById('btn-nueva-reparacion').addEventListener('click', () => {
        form.reset();
        document.getElementById('rep-id').value = '';
        itemsContainer.innerHTML = '';
        createItemRow(); // Fila inicial
        calculateTotals();
        
        // Fecha hoy por defecto
        document.getElementById('rep-fecha').value = new Date().toISOString().split('T')[0];
        document.getElementById('modal-title').textContent = 'Nueva Orden de Trabajo';
        
        showModal();
    });

    document.getElementById('btn-cerrar-modal').addEventListener('click', hideModal);
    document.getElementById('btn-cancelar').addEventListener('click', hideModal);
    document.getElementById('btn-add-item').addEventListener('click', () => createItemRow());

    // --- Importar Cotización ---
    document.getElementById('btn-importar-cotizacion').addEventListener('click', async () => {
        const idCotizacion = document.getElementById('search-cotizacion').value;
        if (!idCotizacion) {
            alert('Por favor ingrese un número de cotización');
            return;
        }

        const btn = document.getElementById('btn-importar-cotizacion');
        const originalText = btn.innerHTML;
        btn.innerHTML = 'Cargando...';
        btn.disabled = true;

        try {
            const res = await fetch(`get_cotizacion_data.php?id=${idCotizacion}`);
            const data = await res.json();

            if (data.success) {
                const d = data.data;
                // Llenar datos de cliente
                if(d.cliente) document.getElementById('rep-cliente').value = d.cliente;
                if(d.rut) document.getElementById('rep-rut').value = d.rut;
                if(d.telefono) document.getElementById('rep-telefono').value = d.telefono;
                if(d.correo) document.getElementById('rep-correo').value = d.correo;
                
                // Llenar datos de vehículo
                if(d.marca) document.getElementById('rep-marca').value = d.marca;
                if(d.modelo) document.getElementById('rep-modelo').value = d.modelo;
                if(d.patente) document.getElementById('rep-patente').value = d.patente;
                if(d.anio) document.getElementById('rep-anio').value = d.anio;
                if(d.color) document.getElementById('rep-color').value = d.color;
                if(d.km) document.getElementById('rep-km').value = d.km;

                alert('Datos cargados correctamente desde la cotización #' + idCotizacion);
            } else {
                alert(data.error || 'No se encontró la cotización');
            }
        } catch (e) {
            console.error(e);
            alert('Error al buscar la cotización');
        } finally {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    });

    // Inicializar
    loadReparaciones();
});
</script>

<?php include 'footer.php'; ?>