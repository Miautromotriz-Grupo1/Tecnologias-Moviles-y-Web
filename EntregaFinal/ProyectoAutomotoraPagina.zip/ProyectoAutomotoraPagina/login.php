<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['rut'])) {
    header("Location: index.php");
    exit(); 
}
include 'header.php'; 
?>
<main class="bg-skin-base flex items-center justify-center min-h-screen -mt-[90px] transition-colors duration-300">

    <div class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl w-full max-w-md p-8 sm:p-10 transition-colors duration-300 relative z-10">
        
        <div class="text-center mx-auto text-skin-muted mb-8">
            <h2 class="text-2xl font-bold text-skin-muted mb-4 tracking-tight">Bienvenido</h2>
            <p class="text-skin-muted text-sm">Ingresa tus datos para continuar</p>
            <?php if(isset($_SESSION['mensaje_exito'])): ?>
                    <span class="absolute left-1/4 right-1/4 inline-block items-center  text-xs text-green-700 ">
                        <?php echo ($_SESSION['mensaje_exito']);?>
                    </span>
                    <?php unset($_SESSION['mensaje_exito']);?>
            <?php endif; ?>
            <?php if(isset($_SESSION['error_registro'])): ?>
                    <span class="absolute left-1/4 right-1/4 inline-block items-center  text-xs text-red-700 ">
                        <?php echo ($_SESSION['error_registro']);?>
                    </span>
                    <?php unset($_SESSION['error_registro']);?>
            <?php endif; ?>
        </div>

        <form action="loginval.php" method="POST" class="space-y-6">
            
            <div class="relative group">
                <label for="rut" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">RUT</label>
                <input 
                    type="text" 
                    id="rut" 
                    name="rut" 
                    placeholder="12345678-9" 
                    pattern="\d{7,8}-[0-9kK]" 
                    title="Debe ser un RUT válido sin puntos y con guion. Ej: 12345678-9" 
                    maxlength="10" 
                    required
                    class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border  placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all"
                >
            </div>

            <div class="relative group">
                <label for="password" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Contraseña</label>
                <div class="relative">
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        placeholder="••••••••" 
                        required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all pr-16"
                    >
                    <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-skin-muted hover:text-skin-accent transition-colors font-semibold focus:outline-none">
                        <span id="toggleText">Mostrar</span>
                    </button>
                </div>
            </div>

            <button type="submit" class="w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200">
                Iniciar Sesión
            </button>

            <div class="text-center text-sm space-y-3 mt-6">
                <p>
                    <a href="#" onclick="redireccionarOlvido(event)" class="text-skin-accent hover:underline hover:text-skin-accent-hover transition-colors">¿Olvidaste tu contraseña?</a>
                </p>
                <p class="text-skin-muted">
                    ¿No tienes cuenta? 
                    <a href="register.php" class="text-skin-accent font-bold hover:underline hover:text-skin-accent-hover transition-colors">Regístrate</a>
                </p>
            </div>
        </form>
    </div>

    <script>
        
    </script>
</main>
<?php include 'footer.php' ?>