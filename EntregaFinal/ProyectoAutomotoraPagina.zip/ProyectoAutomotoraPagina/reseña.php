<?php include 'header.php' ?>
<main class="flex-grow bg-skin-base">
    <div class="max-w-3xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h1 class="text-4xl font-extrabold text-skin-muted tracking-tight sm:text-5xl">Reseñas</h1>
            <p class="mt-4 max-w-2xl mx-auto text-lg text-skin-muted">
                <?php if ($esAdmin || $esEmpleado): ?>
                    Aquí puedes ver los comentarios de nuestros clientes.
                <?php else: ?>
                    Tu opinión es muy importante para nosotros. ¡Déjanos tu reseña!
                <?php endif; ?>
            </p>
        </div>

        <?php if (!$esAdmin && !$esEmpleado): ?>
            <!-- Formulario de reseña para clientes y visitantes -->
            <section class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-8">
                <form id="comentario-form" class="space-y-6">
                    <div>
                        <label for="comentario-nombre" class="block text-sm font-medium text-skin-muted mb-1">Nombre (obligatorio)</label>
                        <input id="comentario-nombre" name="nombre" type="text" placeholder="Tu nombre" required
                               value="<?php echo $isLoggedIn ? htmlspecialchars($nombreUsuario) : ''; ?>"
                               <?php echo $isLoggedIn ? 'readonly' : ''; ?>
                               class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent transition-all <?php echo $isLoggedIn ? 'cursor-not-allowed bg-opacity-50' : ''; ?>">
                    </div>
                    <div>
                        <label for="comentario-text" class="block text-sm font-medium text-skin-muted mb-1">Comentario (obligatorio)</label>
                        <textarea id="comentario-text" name="texto" placeholder="Escribe tu reseña aquí..." rows="6" required
                                  class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border text-skin-muted placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-skin-accent transition-all resize-vertical"></textarea>
                    </div>
                    <div class="text-right">
                        <button type="submit" id="comentario-submit" class="bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all">Enviar reseña</button>
                    </div>
                </form>
            </section>
        <?php else: ?>
            <!-- Lista de reseñas para admin/empleado -->
            <section id="comentarios-list" class="space-y-4"></section>
        <?php endif; ?>
    </div>
</main>

<?php include 'footer.php' ?>