<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificación más segura de sesión y permisos
if (!isset($_SESSION['empleado']) || ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1)) {
    header("Location: index.php");
    exit(); 
}

include 'conexion.php';

// Obtener productos para el modal de selección
$productos_db = [];
if ($conexion) {
    $result = pg_query($conexion, "SELECT id, nombre, precio_v, marca, servicio FROM piezas ORDER BY nombre ASC");
    if ($result) {
        $productos_db = pg_fetch_all($result);
    }
}

include 'header.php';
?>

<main class="min-h-screen bg-skin-base">
    <section class="max-w-6xl mx-auto py-8 px-4">
        <!-- Barra de búsqueda + agregar -->
        <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
            <div class="flex items-center mr-3">
                <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-skin-card border border-skin-border hover:bg-skin-base   rounded-lg shadow-sm transition-colors duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                    </svg>
                    Volver
                </a>
            </div>

            <label for="buscar" class="font-semibold  text-gray-500 mr-2">Buscar:</label>

            <div class="flex items-center gap-2 w-full md:w-auto">
                <input id="buscar" type="text" placeholder="Escribe para filtrar..." 
                       class="w-full md:w-80 p-2 rounded-lg border border-skin-border bg-skin-card   text-gray-500 focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent transition-shadow duration-200" />

                <button id="btn-buscar" class="bg-skin-card border border-skin-border  text-gray-500 p-2 rounded-md hover:shadow-sm hover:bg-skin-base transition-all duration-200" title="Buscar">
                    <img src="media/lupa.webp" alt="Buscar" class="w-5 h-5" />
                </button>
            </div>

            <div class="mt-3 md:mt-0 md:ml-auto">
                <button id="btn-agregar-inv" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow transition-colors duration-200 font-medium">
                    Crear Presupuesto
                </button>
            </div>
        </div>

        <!-- Botones de filtro de vista -->
        <div class="mb-4 flex justify-start gap-2">
            <button data-scope="user" class="btn-scope px-4 py-2 rounded-lg text-sm font-semibold bg-sky-600 text-white transition-colors duration-200">
                Mis Presupuestos
            </button>
            <?php if ($_SESSION['empleado'] == 2): // Solo para admin ?>
            <button data-scope="all" class="btn-scope px-4 py-2 rounded-lg text-sm font-semibold bg-skin-card  text-gray-500 border border-skin-border hover:bg-skin-base transition-colors duration-200">
                Todos los Presupuestos
            </button>
            <?php endif; ?>
        </div>

        <!-- Tabla de presupuestos -->
        <div class="overflow-x-auto bg-skin-card rounded-lg shadow border border-skin-border">
            <table class="w-full table-auto divide-y divide-skin-border" aria-describedby="listado-presupuestos">
                <thead class="bg-skin-base">
                    <tr class="text-left text-sm font-medium  text-gray-500">
                        <th class="px-4 py-3">Cliente</th>
                        <th class="px-4 py-3">RUT</th>
                        <th class="px-4 py-3">Correo</th>
                        <th class="px-4 py-3">Contacto</th>
                        <th class="px-4 py-3">Creado por</th>
                        <th class="px-4 py-3">Fecha</th>
                        <th class="px-4 py-3">Total</th>
                        <th class="px-4 py-3 text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody id="listado-presupuestos" class="bg-skin-card divide-y divide-skin-border text-sm  ">
                    <!-- Los presupuestos se cargan dinámicamente -->
                </tbody>
            </table>
            <div id="loading-message" class="p-4 text-center  text-gray-500 hidden">
                Cargando presupuestos...
            </div>
        </div>

        <!-- Mensaje cuando no hay resultados -->
        <div id="no-results" class="hidden p-4 text-center  text-gray-500">
            No se encontraron presupuestos.
        </div>

        <!-- Paginación -->
        <div id="pagination" class="mt-4 flex justify-between items-center hidden">
            <button id="prev-page" class="px-4 py-2 bg-skin-card border border-skin-border   hover:bg-skin-base rounded-lg disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                Anterior
            </button>
            <span id="page-info" class="text-sm  text-gray-500">Página 1 de 1</span>
            <button id="next-page" class="px-4 py-2 bg-skin-card border border-skin-border   hover:bg-skin-base rounded-lg disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                Siguiente
            </button>
        </div>
    </section>

    <!-- Modal de Presupuesto -->
    <div id="modal-presupuesto" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 p-4">
        <div class="bg-skin-card rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
            <!-- Encabezado del modal -->
            <div class="flex items-center justify-between p-6 border-b border-skin-border bg-skin-card no-print">
                <h2 class="text-2xl font-semibold  " id="modal-title">Nuevo Presupuesto</h2>
                <div class="flex items-center gap-2">
                    <button id="pre-guardar" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded font-medium transition-colors duration-200">
                        Guardar
                    </button>
                    <button type="button" id="pre-limpiar" class="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded font-medium transition-colors duration-200 no-print">
                        Limpiar
                    </button>
                    <button type="button" id="pre-exportar-pdf" class="no-print flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd" /></svg>
                        Exportar a PDF
                    </button>
                    <button id="pre-cancelar" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded font-medium transition-colors duration-200">
                        Cancelar
                    </button>
                </div>
            </div>

            <!-- Contenido del modal -->
            <div class="overflow-y-auto p-6" style="max-height: calc(90vh - 80px)">
                <div id="presupuesto-printable" class="bg-white p-8 rounded-lg">
                    <!-- Encabezado + Logo -->
                    <div class="flex items-start justify-between mb-8 pb-4 border-b border-gray-200">
                        <div class="flex items-center gap-4">
                            <div class="flex-shrink-0 w-52 h-16">
                                <img src="media/logo.png" alt="Logo" class="w-full h-full object-contain" />
                            </div>
                        </div>
                        <div class="text-right">
                            <h2 class="text-2xl font-bold text-gray-800">PRESUPUESTO</h2>
                            <p class="text-sm text-gray-500">N°: <span id="pre-numero" class="font-mono">NUEVO</span></p>
                            <div class="mt-4 text-xs text-gray-600">
                                <p class="font-bold text-gray-700">Miau-tomotriz</p>
                                <p>RUT: 00.000.000-0 | Tel: +56 2 1234 5678</p>
                                <p>Dirección: Calle Principal 123, Santiago</p>
                            </div>
                        </div>
                    </div>

                    <!-- Datos Cliente y Vehículo -->
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-x-8 gap-y-6 mb-6">
                        <!-- Columna Cliente -->
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-skin-border">Datos del Cliente</h3>
                            <div class="space-y-3 mt-3">
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Nombre del cliente *</label>
                                    <input type="text" id="pre-cliente" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Apellido del cliente</label>
                                    <input type="text" id="pre-apellido" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">RUT</label>
                                    <input type="text" id="pre-rut" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Correo</label>
                                    <input type="email" id="pre-correo" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Dirección</label>
                                    <input type="text" id="pre-direccion" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Fecha del Presupuesto *</label>
                                    <input type="date" id="pre-fecha" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Teléfono 1 *</label>
                                    <input type="tel" id="pre-contacto1" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Teléfono 2</label>
                                    <input type="tel" id="pre-contacto2" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div class="pt-2">
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Observaciones</label>
                                    <textarea id="pre-observaciones" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" rows="4"></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Columna Vehículo -->
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3 pb-2 border-b border-skin-border">Información del Vehículo</h3>
                            <div class="space-y-3 mt-3">
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Marca</label>
                                    <input type="text" id="pre-marca" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Modelo</label>
                                    <input type="text" id="pre-modelo" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Año</label>
                                    <input type="number" id="pre-anio" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" min="1900" max="<?php echo date('Y'); ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">VIN</label>
                                    <input type="text" id="pre-vin" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Color</label>
                                    <input type="text" id="pre-color" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Tipo de Vehículo</label>
                                    <input type="text" id="pre-tipo" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Matrícula/Patente</label>
                                    <input type="text" id="pre-matricula" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">Kilometraje</label>
                                    <input type="number" id="pre-kilometraje" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" min="0">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium  text-gray-500 mb-1">N° Chasis</label>
                                    <input type="text" id="pre-chasis" class="w-full p-2 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tabla de items -->
                    <div class="mb-6">
                        <div class="flex justify-between items-center mb-3">
                            <h3 class="text-lg font-semibold text-gray-900 ">Materiales, Repuestos y Trabajos</h3>
                            <button type="button" id="add-item" class="px-3 py-2 bg-sky-100 hover:bg-sky-200 text-sky-700 rounded-md text-sm font-medium transition-colors duration-200 no-print">
                                + Agregar Item
                            </button>
                        </div>
                        
                        <div class="overflow-x-auto border border-skin-border rounded-lg">
                            <table id="tabla-items" class="w-full">
                                <thead class="bg-skin-base">
                                    <tr class="text-left text-sm  text-gray-500">
                                        <th class="px-4 py-3 font-medium text-gray-500">Descripción *</th>
                                        <th class="px-4 py-3 font-medium w-24 text-gray-500 text-center">Cantidad</th>
                                        <th class="px-4 py-3 font-medium w-32 text-gray-500 text-right">Valor Unitario</th>
                                        <th class="px-4 py-3 font-medium w-32 text-right text-gray-500" >Total</th>
                                        <th class="px-4 py-3 font-medium w-20 text-center text-gray-500 no-print">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="items-body" class="divide-y divide-skin-border"></tbody>
                            </table>
                        </div>
                        <p class="text-sm  text-gray-500 mt-2">* Campos obligatorios</p>
                    </div>

                    <div class="totals-and-notes-section">
                        <!-- Totales -->
                        <div class="mt-6 pt-4 border-t border-skin-border">
                            <div class="flex justify-end">
                                <div class="w-64 space-y-2">
                                    <div class="flex justify-between">
                                        <span class=" text-gray-800">Subtotal:</span>
                                        <span class="font-medium  text-gray-800">$<span id="pre-subtotal">0</span></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class=" text-gray-800">IVA (19%):</span>
                                        <span class="font-medium  text-gray-800">$<span id="pre-iva">0</span></span>
                                    </div>
                                    <div class="flex justify-between pt-2 border-t border-skin-border">
                                        <span class="text-lg font-bold  text-gray-800">Total:</span>
                                        <span class="text-lg font-bold  text-gray-800">$<span id="pre-total">0</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <!-- Notas adicionales -->
                        <div class="mt-6 pt-4 border-t border-skin-border">
                            <label class="block text-sm font-medium  text-gray-500 mb-2">Notas Adicionales</label>
                            <textarea id="pre-notas" class="w-full p-3 border border-skin-border bg-skin-base   rounded-md focus:outline-none focus:ring-2 focus:ring-sky-300 focus:border-transparent" rows="3" placeholder="Notas adicionales para el cliente..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Selección de Item -->
    <div id="modal-seleccion-item" class="fixed inset-0 z-[60] hidden items-center justify-center bg-black/50 p-4">
        <div class="bg-skin-card rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
            <div class="p-4 border-b border-skin-border flex justify-between items-center">
                <h3 class="text-xl font-bold  ">Agregar Item</h3>
                <button id="close-select-item" class=" text-2xl">&times;</button>
            </div>
            
            <div class="p-4 border-b border-skin-border">
                <input type="text" id="search-item-input" placeholder="Buscar producto o servicio..." class="w-full p-2 border border-skin-border rounded bg-skin-base   focus:outline-none focus:ring-2 focus:ring-sky-300">
            </div>
            
            <div class="overflow-y-auto p-4 flex-1 space-y-2" id="items-list-container">
                <!-- List of items generated by JS -->
            </div>
            
            <div class="p-4 border-t border-skin-border bg-skin-card">
                <button id="btn-add-external" class="w-full py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-medium transition-colors">
                    Agregar Item Externo / Manual
                </button>
            </div>
        </div>
    </div>
</main>

<!-- Estilos para impresión -->
<style>
    @media print {
        @page {
            size: Letter;
            margin: 1cm;
        }

        body {
            background-color: #fff;
        }

        /* Ocultar todo por defecto excepto el modal del presupuesto */
        body > *:not(#modal-presupuesto) {
            display: none !important;
        }

        /* Configurar el modal para que ocupe toda la página */
        #modal-presupuesto {
            display: block !important;
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: auto !important;
            overflow: visible !important;
            background: white !important;
            z-index: 9999 !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        /* Contenedor interno del modal */
        #modal-presupuesto > div {
            max-height: none !important;
            overflow: visible !important;
            width: 100% !important;
            max-width: 100% !important;
            box-shadow: none !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
        }

        /* Ocultar el header del modal y otros elementos no imprimibles */
        #modal-presupuesto .no-print,
        #modal-presupuesto > div > .flex.items-center.justify-between {
            display: none !important;
        }
        
        #modal-presupuesto > div > .overflow-y-auto {
             overflow: visible !important;
             max-height: none !important;
             padding: 0 !important;
        }

        #presupuesto-printable {
            box-shadow: none !important;
            border: none !important;
            padding: 0 !important;
            margin: 0 !important;
            font-size: 10pt;
            color: #000;
        }
        
        /* Control de saltos de página */
        .flex.items-start.justify-between, .grid.grid-cols-1.lg\:grid-cols-2, .totals-and-notes-section {
            page-break-inside: avoid;
        }

        #tabla-items { page-break-inside: auto; }
        #items-body tr { page-break-inside: avoid; }
    }
</style>

<script>
// Configuración global
const CONFIG = {
    ITEMS_PER_PAGE: 20,
    currentPage: 1,
    totalPages: 1,
    currentScope: 'user'
};
const productosDb = <?php echo json_encode($productos_db ?: []); ?>;

// --- Lógica de Impresión ---
function prepareForPrint() {
    const printableArea = document.getElementById('presupuesto-printable');
    
    // Reemplazar inputs y textareas con spans
    const inputs = printableArea.querySelectorAll('input[type="text"], input[type="number"], input[type="email"], input[type="tel"], input[type="date"], textarea');
    inputs.forEach(input => {
        const span = document.createElement('span');
        span.className = 'print-value';
        
        let value = input.value;
        if (input.type === 'date' && value) {
            try {
                const [year, month, day] = value.split('-');
                value = `${day}/${month}/${year}`;
            } catch (e) { /* Mantener valor original si falla el formato */ }
        }
        
        span.textContent = value || '\u00A0'; // Espacio si está vacío
        input.style.display = 'none';
        input.parentNode.insertBefore(span, input);
    });

    // Reemplazar selects con spans
    const selects = printableArea.querySelectorAll('select');
    selects.forEach(select => {
        const span = document.createElement('span');
        span.className = 'print-value';

        let selectedIndex = select.selectedIndex;
        if (select.disabled && select.dataset.selectedIndexForPrint) {
            selectedIndex = parseInt(select.dataset.selectedIndexForPrint, 10);
        }

        span.textContent = selectedIndex >= 0 ? select.options[selectedIndex].text : '\u00A0';
        select.style.display = 'none';
        select.parentNode.insertBefore(span, select);
    });
}

function cleanupAfterPrint() {
    // Eliminar los spans generados
    document.querySelectorAll('.print-value').forEach(span => span.remove());
    // Volver a mostrar los inputs y selects
    document.querySelectorAll('#presupuesto-printable input, #presupuesto-printable textarea, #presupuesto-printable select').forEach(el => {
        el.style.display = '';
    });
}

// Utilidades
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatCurrency(value) {
    return new Intl.NumberFormat('es-CL', {
        style: 'decimal',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(value);
}

function showLoading(show) {
    const loading = document.getElementById('loading-message');
    const noResults = document.getElementById('no-results');
    
    if (show) {
        loading.classList.remove('hidden');
        noResults.classList.add('hidden');
    } else {
        loading.classList.add('hidden');
    }
}

function showNoResults(show) {
    const noResults = document.getElementById('no-results');
    const tbody = document.getElementById('listado-presupuestos');
    
    if (show) {
        noResults.classList.remove('hidden');
        tbody.innerHTML = '';
    } else {
        noResults.classList.add('hidden');
    }
}

// Sistema de paginación
function updatePagination() {
    const pagination = document.getElementById('pagination');
    const prevBtn = document.getElementById('prev-page');
    const nextBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');
    
    if (CONFIG.totalPages <= 1) {
        pagination.classList.add('hidden');
        return;
    }
    
    pagination.classList.remove('hidden');
    pageInfo.textContent = `Página ${CONFIG.currentPage} de ${CONFIG.totalPages}`;
    
    prevBtn.disabled = CONFIG.currentPage <= 1;
    nextBtn.disabled = CONFIG.currentPage >= CONFIG.totalPages;
}

// Manejo del modal
const modalPresu = document.getElementById('modal-presupuesto');
let isEditing = false;
let currentPresupuestoId = null;

// Abrir modal para nuevo presupuesto
document.getElementById('btn-agregar-inv').addEventListener('click', function() {
    isEditing = false;
    currentPresupuestoId = null;
    document.getElementById('modal-title').textContent = 'Nuevo Presupuesto';
    clearPresupuestoForm();
    
    // Establecer fecha actual
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pre-fecha').value = today;
    
    // Añadir primera fila de items
    const itemsBody = document.getElementById('items-body');
    itemsBody.innerHTML = '';
    addItemRow();
    
    modalPresu.classList.remove('hidden');
    modalPresu.style.display = 'flex';
    document.getElementById('pre-cliente').focus();
});

// Cerrar modal
document.getElementById('pre-cancelar').addEventListener('click', closeModal);
modalPresu.addEventListener('click', function(e) {
    if (e.target === modalPresu) closeModal();
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !modalPresu.classList.contains('hidden')) {
        closeModal();
    }
});

function closeModal() {
    if (isEditing && !confirm('¿Seguro que deseas cancelar? Los cambios no guardados se perderán.')) {
        return;
    }
    modalPresu.classList.add('hidden');
    modalPresu.style.display = 'none';
}

// Manejo de items
function addItemRow(item = {}) {
    const itemsBody = document.getElementById('items-body');
    const rowCount = itemsBody.querySelectorAll('tr').length;
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td class="px-4 py-2">
            <input type="text" class="item-desc w-full p-1 border border-skin-border bg-skin-base   rounded focus:outline-none focus:ring-1 focus:ring-sky-300" 
                   value="${escapeHtml(item.descripcion || '')}" required>
        </td>
        <td class="px-4 py-2">
            <input type="number" class="item-cant w-full p-1 border border-skin-border bg-skin-base   rounded text-center focus:outline-none focus:ring-1 focus:ring-sky-300" 
                   value="${item.cantidad || 1}" min="0" step="0.01">
        </td>
        <td class="px-4 py-2">
            <input type="number" class="item-valor w-full p-1 border border-skin-border bg-skin-base   rounded text-right focus:outline-none focus:ring-1 focus:ring-sky-300" 
                   value="${item.valor || 0}" min="0" step="100">
        </td>
        <td class="px-4 py-2 text-right font-medium item-total  text-gray-800">
            ${formatCurrency((item.cantidad || 1) * (item.valor || 0))}
        </td>
        <td class="px-4 py-2 text-center no-print">
            <button type="button" class="btn-remove-item px-2 py-1 bg-red-100 hover:bg-red-200 text-red-700 rounded text-xs">
                Eliminar
            </button>
        </td>
    `;
    itemsBody.appendChild(tr);
    
    // Configurar eventos para la nueva fila
    const inputs = tr.querySelectorAll('.item-cant, .item-valor');
    inputs.forEach(input => {
        input.addEventListener('input', calcularTotales);
    });
    
    // Botón eliminar
    tr.querySelector('.btn-remove-item').addEventListener('click', function() {
        if (itemsBody.querySelectorAll('tr').length <= 1) {
            alert('Debe haber al menos un item en el presupuesto');
            return;
        }
        tr.remove();
        calcularTotales();
    });
    
    calcularTotales();
    return tr;
}

// Lógica del Modal de Selección de Items
const modalSelect = document.getElementById('modal-seleccion-item');
const searchInput = document.getElementById('search-item-input');
const itemsContainer = document.getElementById('items-list-container');

document.getElementById('add-item').addEventListener('click', function() {
    renderItemsList();
    modalSelect.classList.remove('hidden');
    modalSelect.style.display = 'flex';
    searchInput.value = '';
    setTimeout(() => searchInput.focus(), 100);
});

document.getElementById('close-select-item').addEventListener('click', () => {
    modalSelect.classList.add('hidden');
    modalSelect.style.display = 'none';
});

document.getElementById('btn-add-external').addEventListener('click', () => {
    addItemRow();
    modalSelect.classList.add('hidden');
    modalSelect.style.display = 'none';
});

searchInput.addEventListener('input', (e) => {
    renderItemsList(e.target.value);
});

function renderItemsList(filter = '') {
    itemsContainer.innerHTML = '';
    const term = filter.toLowerCase();
    
    const filtered = productosDb.filter(p => 
        p.nombre.toLowerCase().includes(term) || 
        (p.marca && p.marca.toLowerCase().includes(term))
    );
    
    if (filtered.length === 0) {
        itemsContainer.innerHTML = '<p class="text-center  text-gray-500 py-4">No se encontraron productos</p>';
        return;
    }
    
    filtered.forEach(p => {
        const div = document.createElement('div');
        div.className = 'p-3 border border-skin-border rounded hover:bg-skin-base cursor-pointer flex justify-between items-center transition-colors';
        const isService = p.servicio == 1;
        const typeLabel = isService ? '<span class="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded ml-2">Servicio</span>' : '<span class="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded ml-2">Producto</span>';
        
        div.innerHTML = `
            <div>
                <div class="font-medium  ">${escapeHtml(p.nombre)} ${typeLabel}</div>
                <div class="text-sm  text-gray-500">${escapeHtml(p.marca || '')}</div>
            </div>
            <div class="font-bold  text-gray-500">
                $${formatCurrency(p.precio_v)}
            </div>
        `;
        
        div.addEventListener('click', () => {
            addItemRow({
                descripcion: p.nombre,
                valor: p.precio_v,
                unidad: isService ? 'servicio' : 'unidad'
            });
            modalSelect.classList.add('hidden');
            modalSelect.style.display = 'none';
        });
        
        itemsContainer.appendChild(div);
    });
}

// Calcular totales
function calcularTotales() {
    let subtotal = 0;
    document.querySelectorAll('#items-body tr').forEach(fila => {
        const cant = parseFloat(fila.querySelector('.item-cant').value) || 0;
        const valor = parseFloat(fila.querySelector('.item-valor').value) || 0;
        const total = cant * valor;
        subtotal += total;
        
        // Actualizar total de la fila
        const totalCell = fila.querySelector('.item-total');
        if (totalCell) {
            totalCell.textContent = formatCurrency(total);
        }
    });
    
    const iva = subtotal * 0.19;
    const total = subtotal + iva;
    
    document.getElementById('pre-subtotal').textContent = formatCurrency(subtotal);
    document.getElementById('pre-iva').textContent = formatCurrency(iva);
    document.getElementById('pre-total').textContent = formatCurrency(total);
}

// Validar formulario
function validatePresupuestoForm() {
    const cliente = document.getElementById('pre-cliente').value.trim();
    if (!cliente) {
        alert('Debe ingresar el nombre del cliente');
        document.getElementById('pre-cliente').focus();
        return false;
    }
    
    const contacto1 = document.getElementById('pre-contacto1').value.trim();
    if (!contacto1) {
        alert('Debe ingresar al menos un número de contacto');
        document.getElementById('pre-contacto1').focus();
        return false;
    }
    
    const fecha = document.getElementById('pre-fecha').value;
    if (!fecha) {
        alert('Debe seleccionar una fecha');
        document.getElementById('pre-fecha').focus();
        return false;
    }
    
    const items = document.querySelectorAll('#items-body tr');
    if (items.length === 0) {
        alert('Debe agregar al menos un item al presupuesto');
        return false;
    }
    
    // Validar que cada item tenga descripción
    for (let i = 0; i < items.length; i++) {
        const desc = items[i].querySelector('.item-desc').value.trim();
        if (!desc) {
            alert(`El item ${i + 1} debe tener una descripción`);
            items[i].querySelector('.item-desc').focus();
            return false;
        }
    }
    
    return true;
}

// Guardar presupuesto
async function savePresupuesto() {
    if (!validatePresupuestoForm()) {
        return false;
    }
    
    const items = [];
    document.querySelectorAll('#items-body tr').forEach(fila => {
        items.push({
            descripcion: fila.querySelector('.item-desc').value.trim(),
            cantidad: parseFloat(fila.querySelector('.item-cant').value) || 0,
            valor: parseFloat(fila.querySelector('.item-valor').value) || 0,
            total: (parseFloat(fila.querySelector('.item-cant').value) || 0) * (parseFloat(fila.querySelector('.item-valor').value) || 0)
        });
    });
    
    const nombre = document.getElementById('pre-cliente').value.trim();
    const apellido = document.getElementById('pre-apellido').value.trim();
    
    const payload = {
        cliente: nombre + (apellido ? ' ' + apellido : ''),
        nombre: nombre,
        apellido: apellido,
        rut: document.getElementById('pre-rut').value.trim(),
        correo: document.getElementById('pre-correo').value.trim(),
        direccion: document.getElementById('pre-direccion').value.trim(),
        fecha: document.getElementById('pre-fecha').value,
        contacto1: document.getElementById('pre-contacto1').value.trim(),
        contacto2: document.getElementById('pre-contacto2').value.trim(),
        observaciones: document.getElementById('pre-observaciones').value.trim(),
        marca: document.getElementById('pre-marca').value.trim(),
        modelo: document.getElementById('pre-modelo').value.trim(),
        anio: document.getElementById('pre-anio').value,
        tipo: document.getElementById('pre-tipo').value.trim(),
        matricula: document.getElementById('pre-matricula').value.trim(),
        kilometraje: document.getElementById('pre-kilometraje').value,
        vin: document.getElementById('pre-vin').value.trim(),
        chasis: document.getElementById('pre-chasis').value.trim(),
        color: document.getElementById('pre-color').value.trim(),
        notas: document.getElementById('pre-notas').value.trim(),
        items: items,
        subtotal: parseFloat(document.getElementById('pre-subtotal').textContent.replace(/\./g, '')) || 0,
        iva: parseFloat(document.getElementById('pre-iva').textContent.replace(/\./g, '')) || 0,
        total: parseFloat(document.getElementById('pre-total').textContent.replace(/\./g, '')) || 0
    };
    
    if (currentPresupuestoId) {
        payload.id = currentPresupuestoId;
    }
    
    try {
        const response = await fetch('save_presupuesto.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Presupuesto guardado correctamente');
            closeModal();
            renderPresupuestos(CONFIG.currentScope);
            return true;
        } else {
            alert('Error al guardar: ' + (data.error || 'Error desconocido'));
            return false;
        }
    } catch (error) {
        alert('Error de red: ' + error.message);
        return false;
    }
}

// Cargar presupuesto para editar
async function loadPresupuesto(id) {
    try {
        const response = await fetch(`save_presupuesto.php?id=${id}`);
        const data = await response.json();
        
        if (data.success && data.presupuesto) {
            const p = data.presupuesto;
            isEditing = true;
            currentPresupuestoId = p.id;
            
            document.getElementById('modal-title').textContent = 'Editar Presupuesto';
            document.getElementById('pre-numero').textContent = p.numero || p.id;
            document.getElementById('pre-cliente').value = p.nombre || p.cliente || '';
            document.getElementById('pre-apellido').value = p.apellido || '';
            document.getElementById('pre-rut').value = p.rut || '';
            document.getElementById('pre-correo').value = p.correo || '';
            document.getElementById('pre-direccion').value = p.direccion || '';
            document.getElementById('pre-fecha').value = p.fecha || '';
            document.getElementById('pre-contacto1').value = p.contacto1 || '';
            document.getElementById('pre-contacto2').value = p.contacto2 || '';
            document.getElementById('pre-observaciones').value = p.observaciones || '';
            document.getElementById('pre-marca').value = p.marca || '';
            document.getElementById('pre-modelo').value = p.modelo || '';
            document.getElementById('pre-anio').value = p.anio || '';
            document.getElementById('pre-tipo').value = p.tipo || '';
            document.getElementById('pre-matricula').value = p.matricula || '';
            document.getElementById('pre-kilometraje').value = p.kilometraje || '';
            document.getElementById('pre-vin').value = p.vin || '';
            document.getElementById('pre-chasis').value = p.chasis || '';
            document.getElementById('pre-color').value = p.color || '';
            document.getElementById('pre-notas').value = p.notas || '';

            // Asegurarse de que los botones de acción y campos estén editables
            document.getElementById('add-item').style.display = 'block';
            document.getElementById('pre-guardar').style.display = 'block';
            document.querySelectorAll('#presupuesto-printable input, #presupuesto-printable textarea, #presupuesto-printable select').forEach(input => {
                input.readOnly = false;
                if (input.tagName === 'SELECT') input.disabled = false;
            });
            
            // Cargar items
            const itemsBody = document.getElementById('items-body');
            itemsBody.innerHTML = '';
            (p.items || []).forEach(item => {
                addItemRow(item);
            });
            
            if ((p.items || []).length === 0) {
                addItemRow();
            }
            
            document.querySelectorAll('.btn-remove-item').forEach(btn => btn.style.display = '');
            modalPresu.classList.remove('hidden');
            modalPresu.style.display = 'flex';
            document.getElementById('pre-cliente').focus();
        } else {
            alert('Error al cargar el presupuesto');
        }
    } catch (error) {
        alert('Error de red al cargar el presupuesto');
    }
}

// Eliminar presupuesto
async function deletePresupuesto(id) {
    if (!confirm('¿Está seguro de eliminar este presupuesto? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch(`save_presupuesto.php?id=${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Presupuesto eliminado correctamente');
            renderPresupuestos(CONFIG.currentScope);
        } else {
            alert('Error al eliminar: ' + (data.error || 'Error desconocido'));
        }
    } catch (error) {
        alert('Error de red al eliminar');
    }
}

// Renderizar lista de presupuestos
async function renderPresupuestos(scope = CONFIG.currentScope, page = 1, search = '') {
    CONFIG.currentScope = scope;
    CONFIG.currentPage = page;
    
    const tbody = document.getElementById('listado-presupuestos');
    showLoading(true);
    showNoResults(false);
    
    try {
        const url = `save_presupuesto.php?scope=${scope}&page=${page}&limit=${CONFIG.ITEMS_PER_PAGE}&search=${encodeURIComponent(search)}`;
        const response = await fetch(url);
        const data = await response.json();
        
        showLoading(false);
        
        if (data.success && data.presupuestos && data.presupuestos.length > 0) {
            tbody.innerHTML = '';
            
            data.presupuestos.forEach(p => {
                const tr = document.createElement('tr');
                tr.className = 'hover:bg-skin-base transition-colors duration-150';
                tr.innerHTML = `
                    <td class="px-4 py-3">${escapeHtml(p.cliente)}</td>
                    <td class="px-4 py-3 font-mono text-sm">${escapeHtml(p.rut || 'N/A')}</td>
                    <td class="px-4 py-3">
                        <div class="max-w-xs truncate" title="${escapeHtml(p.correo || '')}">
                            ${escapeHtml(p.correo || 'N/A')}
                        </div>
                    </td>
                    <td class="px-4 py-3">${escapeHtml(p.contacto1 || 'N/A')}</td>
                    <td class="px-4 py-3">${escapeHtml(p.creado_por_nombre || p.creado_por_rut || 'N/A')}</td>
                    <td class="px-4 py-3">${escapeHtml(p.fecha || '')}</td>
                    <td class="px-4 py-3 font-semibold">$${formatCurrency(p.total || 0)}</td>
                    <td class="px-4 py-3">
                        <div class="flex items-center justify-center gap-2">
                            <button class="btn-view px-3 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded text-sm font-medium transition-colors duration-200" 
                                    data-id="${p.id}" title="Ver">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                            <button class="btn-edit px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-700 rounded text-sm font-medium transition-colors duration-200" 
                                    data-id="${p.id}" title="Editar">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                            </button>
                            <button class="btn-delete px-3 py-1 bg-red-100 hover:bg-red-200 text-red-700 rounded text-sm font-medium transition-colors duration-200" 
                                    data-id="${p.id}" title="Eliminar">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            CONFIG.totalPages = data.totalPages || 1;
            updatePagination();
        } else {
            showNoResults(true);
            CONFIG.totalPages = 1;
            updatePagination();
        }
    } catch (error) {
        showLoading(false);
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="px-4 py-8 text-center text-red-600">
                    Error al cargar los presupuestos. Por favor, intenta nuevamente.
                </td>
            </tr>
        `;
        console.error('Error loading presupuestos:', error);
    }
}

// Botones de scope
document.querySelectorAll('.btn-scope').forEach(button => {
    button.addEventListener('click', () => {
        const scope = button.dataset.scope;
        
        // Actualizar estilos
        document.querySelectorAll('.btn-scope').forEach(btn => {
            btn.classList.remove('bg-sky-600', 'text-white');
            btn.classList.add('bg-skin-card', 'text-gray-500', 'border', 'border-skin-border', 'hover:bg-skin-base');
        });
        
        button.classList.add('bg-sky-600', 'text-white');
        button.classList.remove('bg-skin-card', 'text-gray-500', 'border', 'border-skin-border', 'hover:bg-skin-base');
        
        // Cargar presupuestos
        const query = document.getElementById('buscar').value.trim();
        renderPresupuestos(scope, 1, query);
    });
});

// Búsqueda
let searchTimeout;
document.getElementById('buscar').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        const query = this.value.trim();
        renderPresupuestos(CONFIG.currentScope, 1, query);
    }, 300);
});

document.getElementById('btn-buscar').addEventListener('click', function() {
    const query = document.getElementById('buscar').value.trim();
    renderPresupuestos(CONFIG.currentScope, 1, query);
});

// Delegación de eventos para los botones de acción
document.addEventListener('click', function(e) {
    // Editar
    if (e.target.classList.contains('btn-edit') || e.target.closest('.btn-edit')) {
        const id = e.target.dataset?.id || e.target.closest('.btn-edit')?.dataset?.id;
        if (id) loadPresupuesto(id);
    }
    
    // Eliminar
    if (e.target.classList.contains('btn-delete') || e.target.closest('.btn-delete')) {
        const id = e.target.dataset?.id || e.target.closest('.btn-delete')?.dataset?.id;
        if (id) deletePresupuesto(id);
    }
    
    // Ver (solo vista)
    if (e.target.classList.contains('btn-view') || e.target.closest('.btn-view')) {
        const id = e.target.dataset?.id || e.target.closest('.btn-view')?.dataset?.id;
        if (id) viewPresupuesto(id);
    }
});

document.getElementById('pre-guardar').addEventListener('click', async () => {
    await savePresupuesto();
});

function prepareForPrint() {
    const container = document.getElementById('presupuesto-printable');
    if (!container) return;

    // Reemplazar inputs, textareas y selects con texto simple para una impresión limpia
    container.querySelectorAll('input, textarea, select').forEach(input => {
        if (input.closest('.no-print') || input.type === 'hidden') return;

        const span = document.createElement('span');
        span.className = 'print-text-replacement'; // Clase para una fácil limpieza
        
        let value;
        if (input.tagName.toLowerCase() === 'select') {
            // Handle disabled selects from view mode
            let selectedIndex = input.selectedIndex;
            if (input.disabled && input.dataset.selectedIndexForPrint) {
                selectedIndex = parseInt(input.dataset.selectedIndexForPrint, 10);
            }
            value = input.options[selectedIndex]?.text || '---';
        } else if (input.type === 'date' && input.value) {
            try {
                const [year, month, day] = input.value.split('-');
                value = `${day}/${month}/${year}`;
            } catch (e) { value = input.value; }
        } else {
            value = input.value.trim();
        }
        
        span.textContent = value === '' ? '---' : value;
        
        // Ocultar el input original y marcarlo
        input.style.display = 'none';
        input.setAttribute('data-print-hidden', 'true');
        
        // Insertar el span antes del input
        input.parentNode.insertBefore(span, input);
    });
}

function cleanupAfterPrint() {
    // Eliminar los spans temporales
    document.querySelectorAll('.print-text-replacement').forEach(span => span.remove());
    // Restaurar los inputs originales
    document.querySelectorAll('[data-print-hidden]').forEach(el => {
        el.style.display = '';
        el.removeAttribute('data-print-hidden');
    });
}

// --- Lógica de Exportación a PDF ---
document.getElementById('pre-exportar-pdf').addEventListener('click', async function() {
    const isViewMode = document.getElementById('pre-guardar').style.display === 'none';

    const executeExport = () => {
        exportToPDF();
    };

    if (isViewMode) {
        executeExport();
    } else {
        // Guardar antes de exportar si se está en modo edición
        const saved = await savePresupuesto();
        if (saved) {
            executeExport();
        }
    }
});

function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: 'letter' });

    // --- 1. Obtener Datos del Formulario ---
    const numero = document.getElementById('pre-numero').textContent || 'NUEVO';
    const fecha = document.getElementById('pre-fecha').value;
    const cliente = document.getElementById('pre-cliente').value + ' ' + document.getElementById('pre-apellido').value;
    const rut = document.getElementById('pre-rut').value;
    const correo = document.getElementById('pre-correo').value;
    const direccion = document.getElementById('pre-direccion').value;
    const contacto1 = document.getElementById('pre-contacto1').value;
    
    const marca = document.getElementById('pre-marca').value;
    const modelo = document.getElementById('pre-modelo').value;
    const anio = document.getElementById('pre-anio').value;
    const matricula = document.getElementById('pre-matricula').value;
    const kilometraje = document.getElementById('pre-kilometraje').value;
    const vin = document.getElementById('pre-vin').value;

    const observaciones = document.getElementById('pre-observaciones').value;
    const notas = document.getElementById('pre-notas').value;

    const subtotal = document.getElementById('pre-subtotal').textContent;
    const iva = document.getElementById('pre-iva').textContent;
    const total = document.getElementById('pre-total').textContent;

    // --- 2. Configuración y Encabezado del PDF ---
    let y = 15;
    const logoImg = new Image();
    logoImg.src = 'media/logo.png';
    doc.addImage(logoImg, 'PNG', 15, y - 5, 40, 20);

    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('PRESUPUESTO', 195, y, { align: 'right' });
    y += 7;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`N°: ${numero}`, 195, y, { align: 'right' });
    y += 5;
    doc.text(`Fecha: ${new Date(fecha).toLocaleDateString('es-CL')}`, 195, y, { align: 'right' });
    y += 15;

    // --- 3. Datos del Cliente y Vehículo ---
    doc.setLineWidth(0.2);
    doc.line(15, y, 195, y);
    y += 8;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Datos del Cliente', 15, y);
    doc.text('Datos del Vehículo', 110, y);
    y += 6;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Nombre: ${cliente}`, 15, y);
    doc.text(`Marca/Modelo: ${marca || ''} ${modelo || ''}`, 110, y);
    y += 5;
    doc.text(`RUT: ${rut || 'N/A'}`, 15, y);
    doc.text(`Año: ${anio || 'N/A'}`, 110, y);
    y += 5;
    doc.text(`Correo: ${correo || 'N/A'}`, 15, y);
    doc.text(`Patente: ${matricula || 'N/A'}`, 110, y);
    y += 5;
    doc.text(`Dirección: ${direccion || 'N/A'}`, 15, y);
    doc.text(`Kilometraje: ${kilometraje ? formatCurrency(kilometraje) + ' km' : 'N/A'}`, 110, y);
    y += 5;
    doc.text(`Teléfono: ${contacto1 || 'N/A'}`, 15, y);
    doc.text(`VIN: ${vin || 'N/A'}`, 110, y);
    y += 10;

    // --- 4. Tabla de Items ---
    const head = [['Descripción', 'Cantidad', 'Valor Unitario', 'Total']];
    const body = [];
    document.querySelectorAll('#items-body tr').forEach(tr => {
        const desc = tr.querySelector('.item-desc').value;
        const cant = tr.querySelector('.item-cant').value;
        const valor = tr.querySelector('.item-valor').value;
        const totalFila = (parseFloat(cant) || 0) * (parseFloat(valor) || 0);
        body.push([
            desc,
            cant,
            `$${formatCurrency(valor)}`,
            `$${formatCurrency(totalFila)}`
        ]);
    });

    doc.autoTable({
        startY: y,
        head: head,
        body: body,
        theme: 'grid',
        headStyles: { fillColor: [30, 64, 175], textColor: 255 },
        styles: { fontSize: 8, cellPadding: 2 },
        columnStyles: {
            0: { cellWidth: 95 },
            1: { halign: 'center' },
            2: { halign: 'right' },
            3: { halign: 'right' }
        },
    });
    
    y = doc.autoTable.previous.finalY + 10;

    // --- 5. Totales ---
    doc.setFontSize(10);
    doc.text('Subtotal:', 140, y);
    doc.text(`$${subtotal}`, 195, y, { align: 'right' });
    y += 7;
    doc.text('IVA (19%):', 140, y);
    doc.text(`$${iva}`, 195, y, { align: 'right' });
    y += 7;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('TOTAL:', 140, y);
    doc.text(`$${total}`, 195, y, { align: 'right' });
    y += 15;

    // --- 6. Observaciones y Notas ---
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    if (observaciones.trim()) {
        doc.setFont('helvetica', 'bold');
        doc.text('Observaciones:', 15, y);
        y += 5;
        doc.setFont('helvetica', 'normal');
        const obsLines = doc.splitTextToSize(observaciones, 180);
        doc.text(obsLines, 15, y);
        y += obsLines.length * 4 + 5;
    }

    if (notas.trim()) {
        doc.setFont('helvetica', 'bold');
        doc.text('Notas Adicionales:', 15, y);
        y += 5;
        doc.setFont('helvetica', 'normal');
        const notasLines = doc.splitTextToSize(notas, 180);
        doc.text(notasLines, 15, y);
    }

    // --- 7. Guardar el PDF ---
    doc.save(`Presupuesto_${numero}_${cliente.replace(/\s/g, '_')}.pdf`);
}

// Función para ver presupuesto (solo lectura)
async function viewPresupuesto(id) {
    try {
        const response = await fetch(`save_presupuesto.php?id=${id}`);
        const data = await response.json();
        
        if (data.success && data.presupuesto) {
            const p = data.presupuesto;
            isEditing = false;
            
            document.getElementById('modal-title').textContent = 'Ver Presupuesto';
            document.getElementById('pre-numero').textContent = p.numero || p.id;
            document.getElementById('pre-cliente').value = p.nombre || p.cliente || '';
            document.getElementById('pre-apellido').value = p.apellido || '';
            document.getElementById('pre-rut').value = p.rut || '';
            document.getElementById('pre-correo').value = p.correo || '';
            document.getElementById('pre-direccion').value = p.direccion || '';
            document.getElementById('pre-fecha').value = p.fecha || '';
            document.getElementById('pre-contacto1').value = p.contacto1 || '';
            document.getElementById('pre-contacto2').value = p.contacto2 || '';
            document.getElementById('pre-observaciones').value = p.observaciones || '';
            document.getElementById('pre-marca').value = p.marca || '';
            document.getElementById('pre-modelo').value = p.modelo || '';
            document.getElementById('pre-anio').value = p.anio || '';
            document.getElementById('pre-tipo').value = p.tipo || '';
            document.getElementById('pre-matricula').value = p.matricula || '';
            document.getElementById('pre-kilometraje').value = p.kilometraje || '';
            document.getElementById('pre-vin').value = p.vin || '';
            document.getElementById('pre-chasis').value = p.chasis || '';
            document.getElementById('pre-color').value = p.color || '';
            document.getElementById('pre-notas').value = p.notas || '';

            // Ocultar botones de acción
            document.getElementById('add-item').style.display = 'none';
            document.getElementById('pre-guardar').style.display = 'none';
            
            // Cargar items
            const itemsBody = document.getElementById('items-body');
            itemsBody.innerHTML = '';
            (p.items || []).forEach(item => addItemRow(item));
            if ((p.items || []).length === 0) {
                addItemRow();
            }

            // Hacer campos de solo lectura y ocultar botones de eliminar item
            const inputs = document.querySelectorAll('#presupuesto-printable input, #presupuesto-printable textarea, #presupuesto-printable select');
            inputs.forEach(input => {
                // FIX: Para los selects, guardamos el índice seleccionado antes de deshabilitarlo.
                // Esto permite que la función de impresión pueda leer el valor correcto.
                if (input.tagName === 'SELECT') {
                    input.dataset.selectedIndexForPrint = input.selectedIndex;
                    input.disabled = true;
                } else {
                    input.readOnly = true;
                }
            });
            document.querySelectorAll('.btn-remove-item').forEach(btn => btn.style.display = 'none');
            
            // Mostrar totales
            document.getElementById('pre-subtotal').textContent = formatCurrency(p.subtotal || 0);
            document.getElementById('pre-iva').textContent = formatCurrency(p.iva || 0);
            document.getElementById('pre-total').textContent = formatCurrency(p.total || 0);
            
            modalPresu.classList.remove('hidden');
            modalPresu.style.display = 'flex';
        }
    } catch (error) {
        alert('Error al cargar el presupuesto para visualizar');
    }
}

// Limpiar formulario
function clearPresupuestoForm() {
    const fields = [
        'pre-cliente', 'pre-apellido', 'pre-rut', 'pre-correo', 'pre-direccion', 'pre-fecha',
        'pre-contacto1', 'pre-contacto2', 'pre-observaciones', 'pre-marca',
        'pre-modelo', 'pre-anio', 'pre-tipo', 'pre-matricula', 'pre-kilometraje', 'pre-vin', 'pre-chasis', 'pre-color',
        'pre-notas'
    ];
    
    fields.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });
    
    // Mostrar botones de acción
    document.getElementById('add-item').style.display = 'block';
    document.getElementById('pre-guardar').style.display = 'block';
    
    // Habilitar campos
    const inputs = document.querySelectorAll('#presupuesto-printable input, #presupuesto-printable textarea, #presupuesto-printable select');
    inputs.forEach(input => input.readOnly = false);
}

// Paginación
document.getElementById('prev-page').addEventListener('click', () => {
    if (CONFIG.currentPage > 1) {
        const query = document.getElementById('buscar').value.trim();
        renderPresupuestos(CONFIG.currentScope, CONFIG.currentPage - 1, query);
    }
});

document.getElementById('next-page').addEventListener('click', () => {
    if (CONFIG.currentPage < CONFIG.totalPages) {
        const query = document.getElementById('buscar').value.trim();
        renderPresupuestos(CONFIG.currentScope, CONFIG.currentPage + 1, query);
    }
});

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    // Establecer fecha actual por defecto
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pre-fecha').value = today;
    
    // Cargar presupuestos iniciales
    renderPresupuestos('user', 1, '');
    
    // Añadir primera fila de items por defecto
    const itemsBody = document.getElementById('items-body');
    if (itemsBody.querySelectorAll('tr').length === 0) {
        addItemRow();
    }

    // Limpieza del formulario con botón
    document.getElementById('pre-limpiar').addEventListener('click', function() {
        if (confirm('¿Desea limpiar todos los campos del formulario?')) {
            clearPresupuestoForm();
            const itemsBody = document.getElementById('items-body');
            itemsBody.innerHTML = '';
            addItemRow();
            calcularTotales();
        }
    });

    // --- AUTOCOMPLETAR CLIENTE POR RUT ---
    const rutInput = document.getElementById('pre-rut');
    rutInput.addEventListener('blur', async function() {
        const rut = this.value.trim();
        if (rut.length < 8) return; // No buscar si el RUT es muy corto

        // No autocompletar si ya se está editando y el nombre ya existe, para no sobreescribir.
        const nombreInput = document.getElementById('pre-cliente');
        if (isEditing && nombreInput.value.trim() !== '') {
            return;
        }

        try {
            const response = await fetch(`save_presupuesto.php?action=search_client&rut=${encodeURIComponent(rut)}`);
            const data = await response.json();

            if (data.success && data.cliente) {
                const c = data.cliente;
                // Preguntar antes de autocompletar para no sobreescribir datos accidentalmente
                if (confirm(`Cliente encontrado: ${c.nombre || ''} ${c.apellido || ''}.\n¿Desea autocompletar los datos?`)) {
                    document.getElementById('pre-cliente').value = c.nombre || '';
                    document.getElementById('pre-apellido').value = c.apellido || '';
                    document.getElementById('pre-correo').value = c.correo || '';
                    document.getElementById('pre-direccion').value = c.direccion || '';
                    document.getElementById('pre-contacto1').value = c.contacto1 || '';
                    document.getElementById('pre-contacto2').value = c.contacto2 || '';
                }
            }
        } catch (error) {
            console.error('Error al buscar cliente por RUT:', error);
            // No se muestra alerta al usuario, simplemente no se autocompleta.
        }
    });
});
</script>

<?php include 'footer.php'; ?>