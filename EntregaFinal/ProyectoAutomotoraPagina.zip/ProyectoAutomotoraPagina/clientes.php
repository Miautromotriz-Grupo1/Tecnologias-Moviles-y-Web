<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

// Manejo de búsqueda
$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$clientes = [];
$total_clientes = 0;
$estadisticas = [
    'bueno' => 0,
    'malo' => 0,
    'revisar' => 0
];

if (isset($conexion) && $conexion) {
    $base_sql = "
        SELECT
            data->'cliente'->>'rut' AS rut,
            MAX(data->'cliente'->>'nombre') AS nombre,
            STRING_AGG(DISTINCT data->'cliente'->>'fono', ' - ') AS telefonos,
            STRING_AGG(DISTINCT data->'cliente'->>'matricula', ' - ') AS patentes,
            COUNT(*) AS numero_facturas,
            CASE
                WHEN COUNT(DISTINCT data->'cliente'->>'nombre') > 1 THEN 'Malo'
                WHEN bool_or(
                    data->'cliente'->>'matricula' IS NOT NULL AND
                    data->'cliente'->>'matricula' != '' AND
                    UPPER(regexp_replace(data->'cliente'->>'matricula', '[^a-zA-Z0-9]', '', 'g')) !~ '^[A-Z]{2}[0-9]{4}$' AND
                    UPPER(regexp_replace(data->'cliente'->>'matricula', '[^a-zA-Z0-9]', '', 'g')) !~ '^[A-Z]{4}[0-9]{2}$'
                ) THEN 'Revisar Patente'
                ELSE 'Bueno'
            END AS consistencia_datos
        FROM factura
        WHERE data->'cliente'->>'rut' IS NOT NULL AND data->'cliente'->>'rut' != ''
    ";

    $group_by_sql = " GROUP BY data->'cliente'->>'rut' ORDER BY nombre ASC";

    if ($q !== '') {
        $pattern = '%' . $q . '%';
        $sql = $base_sql . " AND (data->'cliente'->>'nombre' ILIKE $1 OR data->'cliente'->>'rut' ILIKE $1 OR data->'cliente'->>'matricula' ILIKE $1)" . $group_by_sql;
        $res = @pg_query_params($conexion, $sql, array($pattern));
    } else {
        $sql = $base_sql . $group_by_sql;
        $res = @pg_query($conexion, $sql);
    }

    if ($res) {
        while ($r = pg_fetch_assoc($res)) {
            $clientes[] = $r;
            // Contar estadísticas
            if ($r['consistencia_datos'] == 'Bueno') {
                $estadisticas['bueno']++;
            } elseif ($r['consistencia_datos'] == 'Malo') {
                $estadisticas['malo']++;
            } else {
                $estadisticas['revisar']++;
            }
        }
        $total_clientes = count($clientes);
    }
}

include 'header.php';
?>

<main class="min-h-screen bg-skin-base">
    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Encabezado con título y estadísticas -->
        <div class="px-4 py-6 sm:px-0">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
                <div>
                    <h1 class="text-3xl font-bold  ">Clientes Registrados</h1>
                    <p class="mt-2 text-skin-muted">Gestión y visualización de todos los clientes del sistema</p>
                </div>
                <div class="mt-4 md:mt-0">
                    <a href="funciones.php" class="inline-flex items-center px-4 py-2.5 bg-skin-card border border-skin-border rounded-lg shadow-sm text-sm font-medium   hover:bg-skin-base hover:shadow-md transition duration-200">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                        Volver al Menú
                    </a>
                </div>
            </div>

            <!-- Tarjetas de estadísticas -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-skin-card rounded-xl shadow-md p-5 border-l-4 border-blue-500">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="p-3 bg-blue-100 rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                            </div>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-skin-muted">Total Clientes</p>
                            <p class="text-2xl font-bold  "><?php echo $total_clientes; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-skin-card rounded-xl shadow-md p-5 border-l-4 border-green-500">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="p-3 bg-green-100 rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-skin-muted">Datos Correctos</p>
                            <p class="text-2xl font-bold  "><?php echo $estadisticas['bueno']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-skin-card rounded-xl shadow-md p-5 border-l-4 border-yellow-500">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="p-3 bg-yellow-100 rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.998-.833-2.732 0L4.342 16.5c-.77.833.192 2.5 1.732 2.5z" />
                                </svg>
                            </div>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-skin-muted">Por Revisar</p>
                            <p class="text-2xl font-bold  "><?php echo $estadisticas['revisar']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-skin-card rounded-xl shadow-md p-5 border-l-4 border-red-500">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="p-3 bg-red-100 rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-skin-muted">Datos Incorrectos</p>
                            <p class="text-2xl font-bold "><?php echo $estadisticas['malo']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Barra de búsqueda mejorada -->
            <div class="mb-8">
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">Buscar Clientes</h2>
                    <form method="get" class="space-y-4">
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </div>
                            <input 
                                id="buscar" 
                                name="q" 
                                type="text" 
                                value="<?php echo htmlspecialchars($q, ENT_QUOTES); ?>"
                                class="block w-full pl-10 pr-12 py-3.5 border border-gray-300 rounded-xl text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base shadow-sm"
                                placeholder="Buscar por nombre, RUT o patente del cliente..."
                            />
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                                <?php if ($q): ?>
                                <a href="?" class="text-gray-400 hover:text-gray-600 p-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                    </svg>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <div class="text-sm text-gray-500">
                                <?php if ($q): ?>
                                    Mostrando <span class="font-semibold"><?php echo $total_clientes; ?></span> resultado(s) para "<span class="font-semibold"><?php echo htmlspecialchars($q); ?></span>"
                                <?php else: ?>
                                    Total de <span class="font-semibold"><?php echo $total_clientes; ?></span> clientes registrados
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl shadow-md hover:shadow-lg transition duration-200 flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                </svg>
                                Buscar
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabla de clientes mejorada -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden">
                <?php if ($total_clientes === 0): ?>
                    <div class="text-center py-16 px-4">
                        <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-gray-100 mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                            </svg>
                        </div>
                        <h3 class="text-lg font-medium text-gray-900 mb-2">No se encontraron clientes</h3>
                        <p class="text-gray-500 max-w-md mx-auto">
                            <?php echo $q ? 'No hay resultados para tu búsqueda.' : 'Aún no hay clientes registrados en el sistema.'; ?>
                        </p>
                        <?php if ($q): ?>
                            <a href="?" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200">
                                Ver todos los clientes
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                                        <div class="flex items-center gap-2">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            Cliente
                                        </div>
                                    </th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">RUT</th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Contacto</th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                                        <div class="flex items-center gap-2">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                            </svg>
                                            Patente(s)
                                        </div>
                                    </th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                                        <div class="flex items-center gap-2">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                            </svg>
                                            Facturas
                                        </div>
                                    </th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Consistencia</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-100">
                                <?php foreach ($clientes as $cliente): 
                                    $esc = function($v){ return htmlspecialchars((string)$v, ENT_QUOTES); };
                                    
                                    // Determinar clases para el estado
                                    if ($cliente['consistencia_datos'] == 'Bueno') {
                                        $estado_clase = 'bg-green-100 text-green-800';
                                        $estado_icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>';
                                    } elseif ($cliente['consistencia_datos'] == 'Malo') {
                                        $estado_clase = 'bg-red-100 text-red-800';
                                        $estado_icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>';
                                    } else {
                                        $estado_clase = 'bg-yellow-100 text-yellow-800';
                                        $estado_icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.998-.833-2.732 0L4.342 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>';
                                    }
                                ?>
                                <tr class="hover:bg-gray-50 transition-colors duration-150">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 h-10 w-10">
                                                <div class="h-10 w-10 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                                                    <span class="text-blue-600 font-semibold">
                                                        <?php echo strtoupper(substr($esc($cliente['nombre'] ?? 'N/A'), 0, 1)); ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900"><?php echo $esc($cliente['nombre'] ?? 'N/A'); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900 font-mono bg-gray-50 px-3 py-1.5 rounded-lg">
                                            <?php echo $esc($cliente['rut'] ?? 'N/A'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php 
                                            $telefonos = $esc($cliente['telefonos'] ?? 'N/A');
                                            if ($telefonos !== 'N/A') {
                                                $telefonos_array = explode(' - ', $telefonos);
                                                foreach ($telefonos_array as $tel) {
                                                    echo '<div class="flex items-center gap-2 mb-1 last:mb-0">';
                                                    echo '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>';
                                                    echo '<span>' . $tel . '</span>';
                                                    echo '</div>';
                                                }
                                            } else {
                                                echo '<span class="text-gray-400">-</span>';
                                            }
                                            ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php 
                                            $patentes = $esc($cliente['patentes'] ?? 'N/A');
                                            if ($patentes !== 'N/A') {
                                                $patentes_array = explode(' - ', $patentes);
                                                foreach ($patentes_array as $patente) {
                                                    echo '<span class="inline-block bg-gray-100 text-gray-800 px-2.5 py-1 rounded-md text-xs font-medium mr-1 mb-1">' . $patente . '</span>';
                                                }
                                            } else {
                                                echo '<span class="text-gray-400">-</span>';
                                            }
                                            ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                </svg>
                                                <?php echo $esc($cliente['numero_facturas']); ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <span class="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold <?php echo $estado_clase; ?>">
                                                <?php echo $estado_icon; ?>
                                                <?php echo $esc($cliente['consistencia_datos']); ?>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pie de página de la tabla -->
                    <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                            <div class="text-sm text-gray-500 mb-2 sm:mb-0">
                                Mostrando <span class="font-medium"><?php echo $total_clientes; ?></span> cliente(s)
                            </div>
                            <?php if ($q): ?>
                            <div class="text-sm">
                                <a href="?" class="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                    </svg>
                                    Limpiar búsqueda
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Estado del Cliente -->
            <?php if ($total_clientes > 0): ?>
            <div class="mt-8 bg-white rounded-xl shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Estado del Cliente</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="flex items-center">
                        <span class="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-green-100 text-green-800 mr-3">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Bueno
                        </span>
                        <span class="text-sm text-gray-600">Datos consistentes y correctos</span>
                    </div>
                    <div class="flex items-center">
                        <span class="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800 mr-3">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.998-.833-2.732 0L4.342 16.5c-.77.833.192 2.5 1.732 2.5z" />
                            </svg>
                            Revisar Patente
                        </span>
                        <span class="text-sm text-gray-600">Patente con formato incorrecto</span>
                    </div>
                    <div class="flex items-center">
                        <span class="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-red-100 text-red-800 mr-3">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Malo
                        </span>
                        <span class="text-sm text-gray-600">Datos inconsistentes entre facturas</span>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-focus en el campo de búsqueda
    const buscarInput = document.getElementById('buscar');
    if (buscarInput) {
        buscarInput.focus();
        // Seleccionar texto si ya hay una búsqueda
        if (buscarInput.value) {
            buscarInput.select();
        }
    }
    
    // Agregar efecto hover a las filas de la tabla
    const tableRows = document.querySelectorAll('tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.transition = 'transform 0.2s ease, box-shadow 0.2s ease';
            this.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
});
</script>

<?php include 'footer.php' ?>