<?php
include 'conexion.php';
session_start();

header('Content-Type: application/json');

// Verificar permisos de administrador
if (!isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
    exit;
}

try {
    // Obtener datos del producto
    $query = "
        SELECT id, nombre, precio_v, precio_c, marca, anio, img, categoria, n_bodega, cantidad, servicio
        FROM piezas
        WHERE id = $1 AND (servicio = 0 OR servicio IS NULL)
    ";
    
    $res = pg_query_params($conexion, $query, [$id]);
    
    if (!$res) {
        throw new Exception("Error en la consulta: " . pg_last_error($conexion));
    }
    
    $product = pg_fetch_assoc($res);
    
    if (!$product) {
        throw new Exception("Producto no encontrado");
    }

    // Formatear la fecha a YYYY-MM-DD si existe
    if (!empty($product['anio'])) {
        $product['anio'] = date('Y-m-d', strtotime($product['anio']));
    }
    
    echo json_encode([
        'success' => true,
        'product' => $product
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>