<?php
include 'conexion.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['empleado'])) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'error' => 'ID no válido']);
    exit;
}

try {
    // Consultar la tabla presupuesto
    // NOTA: Si tu tabla de cotizaciones tiene otro nombre (ej: cotizaciones), cámbialo aquí.
    $query = "SELECT * FROM presupuesto WHERE id = $1";
    $res = @pg_query_params($conexion, $query, [$id]);

    if (!$res) {
        throw new Exception("Error al consultar cotización (Verifica que la tabla 'presupuesto' exista)");
    }

    $row = pg_fetch_assoc($res);

    if ($row) {
        // Intentar obtener datos desde columna JSON 'detalles' o 'contenido' si existen
        $detalles = [];
        if (isset($row['detalles'])) {
            $detalles = json_decode($row['detalles'], true);
        } elseif (isset($row['contenido'])) {
            $detalles = json_decode($row['contenido'], true);
        }

        // Mapear datos: Prioridad JSON > Columnas directas
        // Ajusta las claves del array derecho ($row['...']) según los nombres reales de tus columnas
        $data = [
            'cliente' => $detalles['cliente'] ?? $row['cliente'] ?? $row['nombre_cliente'] ?? '',
            'rut' => $detalles['rut'] ?? $row['rut'] ?? $row['rut_cliente'] ?? '',
            'telefono' => $detalles['telefono'] ?? $row['telefono'] ?? '',
            'correo' => $detalles['correo'] ?? $row['correo'] ?? '',
            
            'marca' => $detalles['marca'] ?? $row['marca'] ?? $row['vehiculo_marca'] ?? '',
            'modelo' => $detalles['modelo'] ?? $row['modelo'] ?? $row['vehiculo_modelo'] ?? '',
            'patente' => $detalles['patente'] ?? $row['patente'] ?? $row['vehiculo_patente'] ?? '',
            'anio' => $detalles['anio'] ?? $row['anio'] ?? $row['vehiculo_anio'] ?? '',
            'color' => $detalles['color'] ?? $row['color'] ?? $row['vehiculo_color'] ?? '',
            'km' => $detalles['km'] ?? $row['km'] ?? $row['vehiculo_km'] ?? ''
        ];

        echo json_encode(['success' => true, 'data' => $data]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Cotización no encontrada']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>