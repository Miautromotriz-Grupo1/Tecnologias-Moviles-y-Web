<?php
include 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

try {
    pg_query($conexion, "BEGIN"); // Iniciar transacción

    // Verificar que tenemos los datos necesarios
    if (!isset($data['nombre']) || !isset($data['precio_mdo'])) {
        throw new Exception('Faltan datos requeridos');
    }
    
    // Preparar datos
    $id = isset($data['id']) && !empty($data['id']) ? (int)$data['id'] : null;
    $nombre_servicio = $data['nombre'] . ' (Servicio)';
    $precio_mdo = isset($data['precio_mdo']) ? (int)$data['precio_mdo'] : 0;
    $precio_total = isset($data['precio_total']) ? (int)$data['precio_total'] : 0;
    $img = $data['img'] ?? null;
    $mecanico = $data['mecanico'] ?? null;
    $new_id = null;
    
    if ($id) {
        // --- ACTUALIZAR SERVICIO EXISTENTE ---
        $query_piezas = "UPDATE piezas SET nombre = $1, precio_v = $2, marca = $3, img = $4, servicio = 1 WHERE id = $5";
        $res_piezas = pg_query_params($conexion, $query_piezas, [$nombre_servicio, $precio_total, 'Miautomotriz', $img, $id]);
        if (!$res_piezas) throw new Exception("Error al actualizar la tabla de piezas: " . pg_last_error($conexion));
        $new_id = $id;
    } else {
        // --- INSERTAR NUEVO SERVICIO ---
        $query_piezas = "INSERT INTO piezas (nombre, precio_v, marca, img, creado, categoria, servicio) VALUES ($1, $2, $3, $4, NOW(), 'Servicio', 1) RETURNING id";
        $result_piezas = pg_query_params($conexion, $query_piezas, [$nombre_servicio, $precio_total, 'Miautomotriz', $img]);
        if (!$result_piezas) throw new Exception("Error al insertar en piezas: " . pg_last_error($conexion));
        $row = pg_fetch_assoc($result_piezas);
        $new_id = $row['id'];
    }

    if (!$new_id) {
        throw new Exception("No se pudo obtener el ID del servicio.");
    }

    // --- UPSERT (UPDATE/INSERT) PARA MANODEOBRA ---
    // Esto maneja tanto la creación como la actualización de los detalles de mano de obra.
    $query_mdo_upsert = "
        INSERT INTO manodeobra (id, nombre_mdo, precio_mdo, img_mdo, mecanico) 
        VALUES ($1, $2, $3, $4, $5)
        ON CONFLICT (id) DO UPDATE SET
            nombre_mdo = EXCLUDED.nombre_mdo,
            precio_mdo = EXCLUDED.precio_mdo,
            img_mdo = EXCLUDED.img_mdo,
            mecanico = EXCLUDED.mecanico;
    ";
    $res_mdo = pg_query_params($conexion, $query_mdo_upsert, [$new_id, $data['nombre'], $precio_mdo, $img, $mecanico]);
    if (!$res_mdo) {
        // Si falla, podría ser porque la tabla no existe. Intentamos crearla.
        $create_mdo_table = "
            CREATE TABLE IF NOT EXISTS manodeobra (
                id INTEGER PRIMARY KEY REFERENCES piezas(id) ON DELETE CASCADE,
                nombre_mdo TEXT,
                precio_mdo INTEGER,
                img_mdo TEXT,
                mecanico TEXT
            );
        ";
        if (pg_query($conexion, $create_mdo_table)) {
            // Reintentar el UPSERT
            $res_mdo = pg_query_params($conexion, $query_mdo_upsert, [$new_id, $data['nombre'], $precio_mdo, $img, $mecanico]);
        }
        if (!$res_mdo) {
            throw new Exception("Error al guardar en mano de obra: " . pg_last_error($conexion));
        }
    }

    // --- ACTUALIZAR PIEZAS ASOCIADAS ---
    pg_query($conexion, "CREATE TABLE IF NOT EXISTS servicio_piezas (id SERIAL PRIMARY KEY, servicio_id INTEGER REFERENCES piezas(id) ON DELETE CASCADE, pieza_id INTEGER REFERENCES piezas(id), cantidad INTEGER DEFAULT 1, creado TIMESTAMP DEFAULT NOW())");
    $res_del = pg_query_params($conexion, "DELETE FROM servicio_piezas WHERE servicio_id = $1", [$new_id]);
    if (!$res_del) throw new Exception("Error al limpiar piezas asociadas: " . pg_last_error($conexion));

    if (isset($data['piezas']) && is_array($data['piezas'])) {
        foreach ($data['piezas'] as $pieza) {
            $cantidad = isset($pieza['cantidad']) && (int)$pieza['cantidad'] > 0 ? (int)$pieza['cantidad'] : 1;
            $res_pieza_link = pg_query_params($conexion, "INSERT INTO servicio_piezas (servicio_id, pieza_id, cantidad) VALUES ($1, $2, $3)", [$new_id, $pieza['id'], $cantidad]);
            if (!$res_pieza_link) throw new Exception("Error al asociar nueva pieza (ID: {$pieza['id']}): " . pg_last_error($conexion));
        }
    }

    pg_query($conexion, "COMMIT");
    echo json_encode(['success' => true, 'id' => $new_id]);

} catch (Exception $e) {
    pg_query($conexion, "ROLLBACK");
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>