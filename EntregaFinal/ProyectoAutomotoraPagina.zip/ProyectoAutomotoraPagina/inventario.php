<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['empleado']) || ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1)) {
    header("Location: index.php");
    exit(); 
}
@include 'conexion.php';

// Obtener todos los productos de la tabla piezas
$productos = [];
$db_error = null;

if (isset($conexion) && $conexion) {
    $query = "SELECT id, nombre, precio_c, precio_v, marca, EXTRACT(YEAR FROM anio) AS anio, 
              categoria, n_bodega, cantidad, img, creado 
              FROM piezas 
              WHERE (marca NOT ILIKE '%Servicio - Miautomotriz%' OR marca IS NULL) AND (categoria IS NULL OR categoria != 'Servicio')
              ORDER BY id ASC";
    
    $res = pg_query($conexion, $query);
    
    if ($res) {
        while ($row = pg_fetch_assoc($res)) {
            $productos[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio_c' => $row['precio_c'] ?? 0,
                'precio_v' => $row['precio_v'] ?? 0,
                'marca' => $row['marca'] ?? '',
                'anio' => $row['anio'] ?? '',
                'categoria' => $row['categoria'] ?? '',
                'n_bodega' => $row['n_bodega'] ?? 0,
                'cantidad' => $row['cantidad'] ?? 0,
                'img' => $row['img'] ?? '',
                'creado' => $row['creado'] ?? ''
            ];
        }
    } else {
        $db_error = "Error al consultar la base de datos: " . pg_last_error($conexion);
    }
    
    // Obtener el próximo ID disponible
    $query_last_id = "SELECT COALESCE(MAX(id), 0) + 1 as next_id FROM piezas";
    $res_last = pg_query($conexion, $query_last_id);
    if ($res_last) {
        $row_last = pg_fetch_assoc($res_last);
        $proximo_id_producto = $row_last['next_id'];
    } else {
        $proximo_id_producto = 1;
    }
}

include 'header.php';
?>

<main class="min-h-screen bg-skin-base">
    <section class="max-w-7xl mx-auto my-8 px-4">
        <!-- Título -->
        <div class="mb-6">
            <h1 class="text-3xl font-bold  ">Inventario de Productos</h1>
            <p class="text-skin-muted mt-2">Gestión completa de productos y piezas en stock</p>
        </div>

        <!-- Barra de búsqueda + agregar -->
        <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-6 p-4 bg-skin-card rounded-lg shadow border border-skin-border">
            <div class="flex items-center mr-3">
                <a href="funciones.php" id="back-to-menu" class="inline-flex items-center px-3 py-2 bg-skin-base hover:bg-skin-card border border-skin-border   rounded-lg shadow-sm transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                    </svg>
                    Volver
                </a>
            </div>

            <div class="flex-1">
                <label for="buscar" class="block text-sm font-medium text-skin-muted mb-1">Buscar Producto:</label>
                <div class="flex items-center gap-2">
                    <input id="buscar" type="text" placeholder="Nombre, marca o categoría..." 
                           class="w-full p-2.5 rounded-lg border border-skin-border bg-skin-base   focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                    
                    <button id="btn-buscar" class="bg-blue-500 hover:bg-blue-600 text-white p-2.5 rounded-md transition duration-200" title="Buscar">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                        </svg>
                    </button>
                </div>
            </div>

            <div class="mt-4 md:mt-0 md:ml-auto">
                <button id="btn-agregar-inv" class="px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-lg shadow-md transition duration-200 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 3a1 1 0 00-1 1v5H4a1 1 0 100 2h5v5a1 1 0 102 0v-5h5a1 1 0 100-2h-5V4a1 1 0 00-1-1z" clip-rule="evenodd" />
                    </svg>
                    Agregar Producto
                </button>
            </div>
        </div>

        <!-- Mensaje de error si hay -->
        <?php if ($db_error): ?>
        <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Error:</strong>
            <span class="block sm:inline"><?php echo htmlspecialchars($db_error); ?></span>
        </div>
        <?php endif; ?>

        <!-- Estadísticas -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-skin-card p-4 rounded-lg shadow border border-skin-border">
                <div class="text-sm text-skin-muted">Total Productos</div>
                <div class="text-2xl font-bold  "><?php echo count($productos); ?></div>
            </div>
            <div class="bg-skin-card p-4 rounded-lg shadow border border-skin-border">
                <div class="text-sm text-skin-muted">Valor Total Inventario</div>
                <div class="text-2xl font-bold text-blue-600">
                    <?php 
                    $total_inventario = 0;
                    foreach ($productos as $p) {
                        $total_inventario += ($p['precio_c'] ?? 0) * ($p['n_bodega'] ?? 0);
                    }
                    echo '$' . number_format($total_inventario, 0, ',', '.');
                    ?>
                </div>
            </div>
            <div class="bg-skin-card p-4 rounded-lg shadow border border-skin-border">
                <div class="text-sm text-skin-muted">Productos en Bodega</div>
                <div class="text-2xl font-bold text-green-600">
                    <?php 
                    $total_bodega = 0;
                    foreach ($productos as $p) {
                        $total_bodega += $p['cantidad'] ?? 0;
                    }
                    echo number_format($total_bodega, 0, ',', '.');
                    ?>
                </div>
            </div>
            <div class="bg-skin-card p-4 rounded-lg shadow border border-skin-border">
                <div class="text-sm text-skin-muted">Valor Venta Total</div>
                <div class="text-2xl font-bold text-purple-600">
                    <?php 
                    $total_venta = 0;
                    foreach ($productos as $p) {
                        $total_venta += ($p['precio_v'] ?? 0) * ($p['cantidad'] ?? 0);
                    }
                    echo '$' . number_format($total_venta, 0, ',', '.');
                    ?>
                </div>
            </div>
        </div>

        <!-- Tabla de inventario -->
        <div class="bg-skin-card rounded-lg shadow overflow-hidden border border-skin-border">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-skin-border">
                    <thead class="bg-skin-base">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Producto</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Marca</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Categoría</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Cantidad</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Precio Compra</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Precio Venta</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Año</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">N° Bodega</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Creado</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-skin-muted uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>

                    <tbody id="listado-inventario" class="bg-skin-card divide-y divide-skin-border">
                        <?php if (empty($productos)): ?>
                        <tr>
                            <td colspan="11" class="px-6 py-8 text-center text-skin-muted">
                                No hay productos en el inventario.
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($productos as $producto): ?>
                            <tr class="hover:bg-skin-base transition-colors" data-id="<?php echo $producto['id']; ?>">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium  ">
                                    <?php echo str_pad($producto['id'], 4, '0', STR_PAD_LEFT); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <?php if ($producto['img']): ?>
                                        <div class="flex-shrink-0 h-10 w-10">
                                            <img class="h-10 w-10 rounded-full object-cover" src="<?php echo htmlspecialchars($producto['img']); ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium  "><?php echo htmlspecialchars($producto['nombre']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    <?php echo htmlspecialchars($producto['marca']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    <?php echo htmlspecialchars($producto['categoria']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php echo ($producto['cantidad'] > 10) ? 'bg-green-100 text-green-800' : 
                                                 (($producto['cantidad'] > 0) ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo $producto['cantidad']; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    $<?php echo number_format($producto['precio_c'], 0, ',', '.'); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                                    $<?php echo number_format($producto['precio_v'], 0, ',', '.'); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    <?php echo $producto['anio']; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    <?php echo $producto['n_bodega']; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-skin-muted">
                                    <?php echo date('d/m/Y', strtotime($producto['creado'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button class="editar-inv-btn px-3 py-1 bg-blue-500 text-white rounded-md hover:bg-blue-600 mr-2"
                                            data-id="<?php echo $producto['id']; ?>"
                                            data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                            data-marca="<?php echo htmlspecialchars($producto['marca']); ?>"
                                            data-categoria="<?php echo htmlspecialchars($producto['categoria']); ?>"
                                            data-n_bodega="<?php echo $producto['n_bodega']; ?>"
                                            data-cantidad="<?php echo $producto['cantidad']; ?>"
                                            data-precio_c="<?php echo $producto['precio_c']; ?>"
                                            data-precio_v="<?php echo $producto['precio_v']; ?>"
                                            data-anio="<?php echo $producto['anio']; ?>"
                                            data-img="<?php echo htmlspecialchars($producto['img']); ?>">
                                        Editar
                                    </button>
                                    <button class="eliminar-inv-btn px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                                            data-id="<?php echo $producto['id']; ?>">
                                        Eliminar
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</main>

<!-- Modal para Agregar/Editar Producto (Mismo que en productos.php) -->
<div id="modal-producto-inv" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 p-4">
    <div class="bg-skin-card p-6 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-skin-border">
        <div class="flex justify-between items-center mb-4">
            <h3 id="modal-title-inv" class="text-2xl font-bold  ">Producto</h3>
            <p class="text-skin-muted">N°: <span id="producto-numero-inv"><?php echo str_pad($proximo_id_producto, 4, '0', STR_PAD_LEFT); ?></span></p>
        </div>
        
        <form id="form-producto-inv" class="space-y-4">
            <input type="hidden" id="prod-id-inv" name="id">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Nombre *</label>
                    <input type="text" id="prod-nombre-inv" name="nombre" class="w-full p-2 border border-skin-border rounded bg-skin-base  " required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de venta *</label>
                    <input type="number" id="prod-precio_v-inv" name="precio_v" class="w-full p-2 border border-skin-border rounded bg-skin-base  " required>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de compra</label>
                    <input type="number" id="prod-precio_c-inv" name="precio_c" class="w-full p-2 border border-skin-border rounded bg-skin-base  ">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Marca</label>
                    <input type="text" id="prod-marca-inv" name="marca" class="w-full p-2 border border-skin-border rounded bg-skin-base  ">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Año</label>
                    <input type="number" id="prod-anio-inv" name="anio" min="1995" max="<?php echo date('Y'); ?>" class="w-full p-2 border border-skin-border rounded bg-skin-base  ">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Categoría</label>
                    <input type="text" id="prod-categoria-inv" name="categoria" class="w-full p-2 border border-skin-border rounded bg-skin-base  ">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Cantidad</label>
                    <input type="number" id="prod-cantidad-inv" name="cantidad" class="w-full p-2 border border-skin-border rounded bg-skin-base" min="0">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">N° Bodega (Stock)</label>
                    <input type="number" id="prod-n_bodega-inv" name="n_bodega" class="w-full p-2 border border-skin-border rounded bg-skin-base  " min="0">
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-skin-muted mb-1">Imagen / URL</label>
                <input type="text" id="prod-img-inv" name="img" class="w-full p-2 border border-skin-border rounded bg-skin-base  " placeholder="URL de la imagen">
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded p-3">
                <p class="text-sm text-blue-800">
                    <strong>Nota:</strong> El IVA (19%) se calculará automáticamente al mostrar el producto a los clientes.
                </p>
            </div>
            
            <div class="flex justify-between gap-2 pt-4 border-t border-skin-border">
                <button type="button" id="limpia-producto-inv" class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">
                    Limpiar
                </button>
                <div class="flex gap-2">
                    <button type="button" id="cancel-producto-inv" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">
                        Cerrar
                    </button>
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        Guardar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modalProductoInv = document.getElementById('modal-producto-inv');
    const formProductoInv = document.getElementById('form-producto-inv');
    const btnAgregarInv = document.getElementById('btn-agregar-inv');
    const buscarInput = document.getElementById('buscar');
    const btnBuscar = document.getElementById('btn-buscar');
    const listadoInventario = document.getElementById('listado-inventario');
    
    // Variables para próximos IDs
    const proximoIdProducto = <?php echo $proximo_id_producto; ?>;
    
    // Función para filtrar la tabla
    function filtrarTabla() {
        const texto = buscarInput.value.toLowerCase();
        const filas = listadoInventario.querySelectorAll('tr[data-id]');
        
        filas.forEach(fila => {
            const textoFila = fila.textContent.toLowerCase();
            fila.style.display = textoFila.includes(texto) ? '' : 'none';
        });
    }
    
    // Evento para buscar
    buscarInput.addEventListener('input', filtrarTabla);
    btnBuscar.addEventListener('click', filtrarTabla);
    
    // Abrir modal para agregar producto
    btnAgregarInv.addEventListener('click', () => {
        // Resetear formulario para nuevo producto
        formProductoInv.reset();
        document.getElementById('prod-id-inv').value = '';
        document.getElementById('modal-title-inv').textContent = 'Agregar Producto';
        document.getElementById('producto-numero-inv').textContent = 
            proximoIdProducto.toString().padStart(4, '0');
        modalProductoInv.classList.remove('hidden');
    });
    
    // Botones para cerrar modal
    document.getElementById('cancel-producto-inv').addEventListener('click', () => {
        modalProductoInv.classList.add('hidden');
    });
    
    // Botón para limpiar formulario
    document.getElementById('limpia-producto-inv').addEventListener('click', function() {
        formProductoInv.reset();
    });
    
    // Editar productos existentes
    document.querySelectorAll('.editar-inv-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const data = {
                id: this.dataset.id,
                nombre: this.dataset.nombre,
                marca: this.dataset.marca,
                categoria: this.dataset.categoria,
                n_bodega: this.dataset.n_bodega,
                cantidad: this.dataset.cantidad,
                precio_c: this.dataset.precio_c,
                precio_v: this.dataset.precio_v,
                anio: this.dataset.anio,
                img: this.dataset.img
            };
            
            // Llenar formulario con datos del producto
            document.getElementById('modal-title-inv').textContent = 'Editar Producto';
            document.getElementById('producto-numero-inv').textContent = 
                data.id.toString().padStart(4, '0');
            document.getElementById('prod-id-inv').value = data.id;
            document.getElementById('prod-nombre-inv').value = data.nombre;
            document.getElementById('prod-marca-inv').value = data.marca;
            document.getElementById('prod-categoria-inv').value = data.categoria;
            document.getElementById('prod-n_bodega-inv').value = data.n_bodega;
            document.getElementById('prod-cantidad-inv').value = data.cantidad;
            document.getElementById('prod-precio_c-inv').value = data.precio_c;
            document.getElementById('prod-precio_v-inv').value = data.precio_v;
            document.getElementById('prod-anio-inv').value = data.anio;
            document.getElementById('prod-img-inv').value = data.img;
            
            modalProductoInv.classList.remove('hidden');
        });
    });
    
    // Guardar Producto (Inventario)
    formProductoInv.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(formProductoInv);
        const data = Object.fromEntries(formData.entries());
        
        // Formatear año para la base de datos
        if (data.anio) {
            data.anio = data.anio + '-01-01';
        }
        
        fetch('save_producto.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        })
        .then(r => r.json())
        .then(res => {
            if(res.success) {
                alert(`Producto ${data.id ? 'actualizado' : 'guardado'} exitosamente con ID: ${res.id}`);
                location.reload();
            } else {
                alert('Error al guardar: ' + (res.error || 'Desconocido'));
            }
        })
        .catch(err => {
            console.error('Error:', err);
            alert('Error de conexión al servidor');
        });
    });
    
    // Eliminar producto del inventario
    document.querySelectorAll('.eliminar-inv-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const nombre = this.closest('tr').querySelector('. ').textContent;
            
            if(confirm(`¿Está seguro de eliminar el producto "${nombre}"?`)) {
                fetch('eliminar_producto.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({id: id})
                })
                .then(r => r.json())
                .then(res => {
                    if(res.success) {
                        location.reload();
                    } else {
                        alert('Error al eliminar: ' + (res.error || 'Desconocido'));
                    }
                })
                .catch(err => alert('Error de conexión'));
            }
        });
    });
    
    // Prevenir envío del formulario con Enter en el campo de búsqueda
    buscarInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            filtrarTabla();
        }
    });
    
    // Inicializar tooltips para las cantidades
    const cantidadSpans = document.querySelectorAll('.bg-green-100, .bg-yellow-100, .bg-red-100');
    cantidadSpans.forEach(span => {
        const cantidad = parseInt(span.textContent);
        if (cantidad === 0) {
            span.title = 'Sin stock - Reabastecer';
        } else if (cantidad <= 10) {
            span.title = 'Stock bajo - Revisar pronto';
        } else {
            span.title = 'Stock suficiente';
        }
    });
});
</script>

<?php include 'footer.php' ?>