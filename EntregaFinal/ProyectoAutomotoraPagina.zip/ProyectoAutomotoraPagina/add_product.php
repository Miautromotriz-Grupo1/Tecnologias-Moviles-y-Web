<?php
header('Content-Type: application/json');

@include 'conexion.php'; // Incluir la conexión a la base de datos

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar si la conexión a la base de datos está establecida
    if (!isset($conexion) || !$conexion) {
        $response['message'] = 'Error de conexión a la base de datos.';
        echo json_encode($response);
        exit;
    }

    // Obtener los datos POST en formato JSON
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    // Verificar si hubo un error al decodificar el JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        $response['message'] = 'Error en el formato JSON de la solicitud.';
        echo json_encode($response);
        exit;
    }

    // Validar y sanitizar los datos de entrada
    $nombre = filter_var($data['nombre'] ?? '', FILTER_SANITIZE_STRING);
    $precio = filter_var($data['precio'] ?? 0, FILTER_VALIDATE_INT);
    $img = filter_var($data['img'] ?? '', FILTER_SANITIZE_URL);
    $marca = filter_var($data['marca'] ?? '', FILTER_SANITIZE_STRING);
    $anio_input = filter_var($data['anio'] ?? null, FILTER_VALIDATE_INT);
    $anio = ($anio_input && $anio_input > 0) ? $anio_input . '-01-01' : null;

    // Validaciones básicas
    if (empty($nombre) || $precio === false || $precio < 0) {
        $response['message'] = 'El nombre y el precio son campos obligatorios y deben ser válidos.';
        echo json_encode($response);
        exit;
    }

    // Preparar la consulta SQL para insertar el nuevo producto
    // Se utiliza pg_query_params para prevenir inyecciones SQL
    // Se inserta el precio en precio_v y precio_c
    $query = "INSERT INTO piezas (nombre, precio_v, precio_c, img, marca, anio) VALUES ($1, $2, $2, $3, $4, $5) RETURNING id";
    $params = [$nombre, $precio, $img, $marca, $anio];

    $result = pg_query_params($conexion, $query, $params);

    if ($result) {
        $row = pg_fetch_assoc($result);
        $response['success'] = true;
        $response['message'] = 'Producto agregado exitosamente.';
        $response['id'] = $row['id']; // Opcional: devolver el ID del nuevo producto
    } else {
        $response['message'] = 'Error al insertar el producto: ' . pg_last_error($conexion);
    }

    pg_close($conexion); // Cerrar la conexión a la base de datos

} else {
    $response['message'] = 'Método de solicitud no permitido.';
}

echo json_encode($response);
?>