<!-- Vincular scripts externos: primero script.js (globals y UI general), luego producto.js (render productos) -->

<!-- Contenedor del Carrito (disponible en todas las páginas) -->
<div class="fixed bottom-6 right-6 z-50">
    <button id="floating-cart" type="button" class="relative w-16 h-16 rounded-full bg-skin-header text-skin-text flex items-center justify-center text-3xl shadow-2xl hover:scale-110 transition-transform border-2 border-skin-accent" title="Abrir carrito">
        🛒
        <span id="cart-counter" class="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center hidden">0</span>
    </button>   
</div>

<div id="carrito-sidebar" class="fixed inset-y-0 right-0 w-80 bg-skin-header shadow-2xl z-[60] transform translate-x-full transition-transform duration-300 p-6 flex flex-col hidden border-l border-skin-border">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-bold text-skin-text">Tu Carrito</h2>
        <button id="cerrar-carrito" class="rounded-md border border-white/20 p-2 text-skin-text hover:bg-red-500/20 hover:text-red-400 hover:border-red-400 transition-colors">
                ✕
        </button>
    </div>
    
    <div id="carrito-lista" class="flex-grow overflow-y-auto space-y-4 text-skin-muted pr-2">
        <!-- Los items del carrito se renderizan aquí -->
    </div>
    
    <div id="carrito-total" class="mt-4 pt-4 border-t border-skin-border font-bold text-xl text-skin-text text-right">
        Total: $0
    </div>
    <button class="w-full mt-4 bg-skin-accent hover:bg-skin-accent-hover text-white py-3 rounded-lg font-bold shadow-lg transition">
        Ir a Pagar
    </button>
</div>

<!-- Quitamos 'defer' de script.js para asegurar que se cargue antes que los scripts que dependen de él -->
<script src="js/cart.js?v=<?php echo filemtime('js/cart.js'); ?>"></script>
<script src="js/script.js?v=<?php echo filemtime('js/script.js'); ?>"></script>
<script src="js/producto.js?v=<?php echo filemtime('js/producto.js'); ?>"></script>

<!-- Centralizamos todas las llamadas de inicialización aquí -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof window.renderProductos === 'function') {
            window.renderProductos();
        }
        if (typeof window.renderComentarios === 'function') {
            window.renderComentarios();
        }
    });
</script>
        
    
</body>
<footer class="flex justify-center">
        &copy; 2025 MIAUtomotriz
    </footer>
</html>