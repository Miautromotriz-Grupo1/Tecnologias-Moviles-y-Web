<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificación de sesión (igual que en usuarios.php)
if (($_SESSION['empleado'] != 2 )) {
    header("Location: index.php");
    exit(); 
}

@include 'conexion.php';
include 'header.php';

// Obtener el RUT de la URL y limpiarlo
$rut = isset($_GET['rut']) ? trim($_GET['rut']) : '';
$usuario = null;
$error = false;

if ($rut && $conexion) {
    // Consulta segura usando parámetros (evita inyección SQL)
    $query = "SELECT * FROM persona WHERE rut = $1";
    $result = pg_query_params($conexion, $query, array($rut));
    
    if ($result && pg_num_rows($result) > 0) {
        $usuario = pg_fetch_assoc($result);
    } else {
        $error = true;
    }
} else {
    $error = true;
}

// Función auxiliar para limpiar HTML
$esc = function($v) { return htmlspecialchars((string)$v, ENT_QUOTES); };
?>

<main class="bg-skin-main transition-colors duration-300">
    <section class="max-w-3xl mx-auto my-10 px-4">
        
        <div class="mb-6">
            <a href="usuarios.php" class="inline-flex items-center text-skin-muted hover:text-skin-main transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                </svg>
                Volver al listado
            </a>
        </div>

        <?php if ($usuario): ?>
            <div class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl overflow-hidden">
                
                <div class="bg-skin-card2 px-6 py-4 border-b border-skin-border flex items-center justify-between">
                    <h1 class="text-xl font-bold text-skin-main flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-skin-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        Datos del Usuario
                    </h1>
                    <span class="px-3 py-1 text-xs font-semibold rounded-full 
                        <?php echo ($usuario['empleado'] == 1 || $usuario['empleado'] == 2) ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>">
                        <?php echo ($usuario['empleado'] == 0) ? 'Cliente' : ''; ?>
                        <?php echo ($usuario['empleado'] == 1) ? 'Empleado' : ''; ?>
                        <?php echo ($usuario['empleado'] == 2) ? 'Admin' : ''; ?>
                    </span>
                </div>

                <div class="p-6">
                    <form id="form-usuario" action="actualizar_usuario.php" method="POST">
                        
                        <input type="hidden" name="rut_original" value="<?php echo $esc($usuario['rut']); ?>">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">RUT</label>
                                <input type="text" name="rut" id="input-rut" 
                                    class="w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors cursor-not-allowed"
                                    value="<?php echo $esc($usuario['rut']); ?>" 
                                    readonly required>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Nombre</label>
                                <input type="text" name="nombre" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['nombre']); ?>" 
                                    readonly required>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Apellido</label>
                                <input type="text" name="apellido" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['apellido']); ?>" 
                                    readonly required>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Correo Electrónico</label>
                                <input type="email" name="correo" 
                                    class="w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['correo']); ?>" 
                                    readonly required>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Teléfono</label>
                                <input type="text" name="telefono" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['telefono']); ?>" 
                                    readonly>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Dirección (ID)</label>
                                <input type="text" name="direccionid" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['direccionid']); ?>" 
                                    readonly>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Fecha nacimiento</label>
                                <input type="date" name="fechanacimiento" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['fechanacimiento']); ?>" 
                                    readonly>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Giro</label>
                                <input type="text" name="giro" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['giro']); ?>" 
                                    readonly>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Rol</label>
                                <input type="text" name="rol" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['rol']); ?>" 
                                    readonly>
                            </div>

                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Previsión</label>
                                <input type="text" name="prevision" 
                                    class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                    value="<?php echo $esc($usuario['prevision']); ?>" 
                                    readonly>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="space-y-1 ">
                                    <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Nivel Acceso</label>
                                    <select name="empleado" 
                                            class="input-editable w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                                            disabled>
                                            
                                        <option value="0" <?php echo ($usuario['empleado'] == 0) ? 'selected' : ''; ?>>
                                            Cliente (0)
                                        </option>
                                        <option value="1" <?php echo ($usuario['empleado'] == 1) ? 'selected' : ''; ?>>
                                            Empleado (1)
                                        </option>
                                        <option value="2" <?php echo ($usuario['empleado'] == 2) ? 'selected' : ''; ?>>
                                            Admin (2)
                                        </option>
                                    </select>
                                </div>

                                <div class="space-y-1 ">
                                    <label class="text-xs font-semibold text-skin-muted uppercase tracking-wider">Verificado</label>
                                    <input type="text" name="personaveri" 
                                        class="w-full text-lg font-medium text-skin-main border-b border-skin-border pb-1 bg-transparent focus:outline-none focus:border-blue-500 transition-colors"
                                        value="<?php echo $esc($usuario['personaveri']); ?>" 
                                        readonly>
                                </div>
                            </div>
                        </div>

                        <div class="mt-8 bg-skin-card2 px-6 py-4 border-t border-skin-border -mx-6 -mb-6 flex justify-end gap-3 rounded-b-2xl">
                            
                            <div id="grupo-visualizacion" class="flex gap-3">
                                <button type="button" onclick="confirmarEliminar('<?php echo $rut;?>')" class="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors font-medium text-sm">
                                    Eliminar Usuario
                                </button>
                                <button type="button" onclick="activarEdicion()" class="px-4 py-2 bg-skin-card border border-skin-border text-skin-main rounded-lg hover:shadow-md transition-shadow font-medium text-sm">
                                    Editar Información
                                </button>
                            </div>

                            <div id="grupo-edicion" class="hidden flex gap-3">
                                <button type="button" onclick="location.reload()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium text-sm">
                                    Cancelar
                                </button>
                                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium text-sm">
                                    Guardar Cambios
                                </button>
                            </div>
                        </div>

                    </form>
                </div>

            </div>

        <?php else: ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded-md shadow-md">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-700">
                            No se encontró el usuario solicitado o el enlace es incorrecto.
                        </p>
                        <p class="mt-2">
                            <a href="usuarios.php" class="text-sm font-medium text-red-700 hover:text-red-600 underline">
                                Volver a intentar
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </section>
</main>
<div id="modal-eliminar" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        <div class="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity" aria-hidden="true" onclick="cerrarModal()"></div>

        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div class="inline-block align-bottom bg-skin-card rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-skin-border">
            <div class="bg-skin-card px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                        <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-skin-main" id="modal-title">Eliminar Usuario</h3>
                        <div class="mt-2">
                            <p class="text-sm text-skin-muted">
                                ¿Estás seguro de que deseas eliminar este usuario? Esta acción no se puede deshacer.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-skin-card2 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <a id="btn-confirmar-eliminar" href="#" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm">
                    Eliminar
                </a>
                <button type="button" onclick="cerrarModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-skin-border shadow-sm px-4 py-2 bg-skin-card text-base font-medium text-skin-main hover:text-skin-muted focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>