/**
 * Módulo para gestionar el carrito de compras.
 * Utiliza localStorage para persistencia y se inicializa automáticamente.
 */

/**
 * Muestra una notificación toast no bloqueante.
 * @param {string} message - El mensaje a mostrar.
 * @param {string} type - 'success' (verde), 'error' (rojo), o 'warning' (amarillo).
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `toast-notification toast-${type}`;
    notification.innerHTML = `<span>${message}</span>`;
    document.body.appendChild(notification);

    // Hacerla visible
    setTimeout(() => notification.classList.add('show'), 100);

    // Ocultarla y eliminarla después de 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        notification.addEventListener('transitionend', () => notification.remove());
    }, 3000);
}

const MiauCart = {
    carrito: [],
    elements: {
        sidebar: null,
        lista: null,
        total: null,
        floatingBtn: null,
        closeBtn: null,
        counter: null,
    },

    /**
     * Inicializa el módulo del carrito.
     * Carga elementos del DOM, el carrito desde localStorage y asigna eventos.
     */
    init: function() {
        // 1. Cargar elementos del DOM
        this.elements.sidebar = document.getElementById('carrito-sidebar');
        this.elements.lista = document.getElementById('carrito-lista');
        this.elements.total = document.getElementById('carrito-total');
        this.elements.floatingBtn = document.getElementById('floating-cart');
        this.elements.closeBtn = document.getElementById('cerrar-carrito');
        this.elements.counter = document.getElementById('cart-counter');

        // Salir si no se encuentran los elementos esenciales del carrito en la página actual.
        if (!this.elements.sidebar || !this.elements.lista || !this.elements.total) {
            // console.warn("Elementos del carrito no encontrados en esta página. El módulo del carrito no se iniciará completamente.");
            return;
        }

        // 2. Cargar carrito desde localStorage
        this.carrito = JSON.parse(localStorage.getItem('carritoMiautomotriz')) || [];

        // 3. Asignar eventos
        this.assignEvents();

        // 4. Renderizar estado inicial
        this.render();
    },

    /**
     * Asigna los listeners de eventos a los botones del carrito.
     */
    assignEvents: function() {
        if (this.elements.floatingBtn) {
            this.elements.floatingBtn.addEventListener('click', () => this.open());
        }
        if (this.elements.closeBtn) {
            this.elements.closeBtn.addEventListener('click', () => this.close());
        }

        this.elements.lista.addEventListener('click', (e) => {
            const cambiarBtn = e.target.closest('.cambiar-cantidad');
            const quitarBtn = e.target.closest('.quitar-item');
            const vaciarBtn = e.target.closest('#btn-vaciar-carrito');

            if (cambiarBtn) {
                const index = parseInt(cambiarBtn.dataset.index, 10);
                const cambio = parseInt(cambiarBtn.dataset.change, 10);
                this.changeQuantity(index, cambio);
            } else if (quitarBtn) {
                const index = parseInt(quitarBtn.dataset.index, 10);
                this.removeItem(index);
            } else if (vaciarBtn) {
                if (confirm('¿Estás seguro de que deseas vaciar todo el carrito?')) {
                    this.clearCart();
                }
            }
        });
    },

    /**
     * Guarda el estado actual del carrito en localStorage.
     */
    save: function() {
        localStorage.setItem('carritoMiautomotriz', JSON.stringify(this.carrito));
    },

    /**
     * Renderiza el contenido del carrito en el DOM.
     */
    render: function() {
        if (!this.elements.lista) return;

        this.elements.lista.innerHTML = '';
        if (this.carrito.length === 0) {
            this.elements.lista.innerHTML = '<p class="text-center text-skin-muted">Tu carrito está vacío.</p>';
        } else {
            this.carrito.forEach((item, index) => {
                const itemEl = document.createElement('div');
                itemEl.className = 'flex items-center gap-4 p-2 bg-skin-base rounded-lg';
                itemEl.innerHTML = `
                    <div class="w-16 h-16 rounded-md bg-gray-200 flex-shrink-0 flex items-center justify-center overflow-hidden">
                        <img src="${item.img}" alt="${item.nombre}" class="w-full h-full object-cover" onerror="this.style.display='none'; this.parentElement.querySelector('svg').style.display='block';">
                        <svg style="display:none;" class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l-1-1m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <div class="flex-grow">
                        <p class="font-semibold text-sm text-skin-main">${item.nombre}</p>
                        <p class="text-xs text-skin-muted">$${item.precio.toLocaleString('es-CL')}</p>
                        <div class="flex items-center gap-2 mt-1">
                            <button class="cambiar-cantidad bg-skin-card border border-skin-border rounded px-2 text-lg" data-index="${index}" data-change="-1">-</button>
                            <span class="font-bold text-skin-main">${item.cantidad}</span>
                            <button class="cambiar-cantidad bg-skin-card border border-skin-border rounded px-2 text-lg" data-index="${index}" data-change="1">+</button>
                        </div>
                    </div>
                    <button class="quitar-item text-red-500 hover:text-red-700 text-xl" data-index="${index}">&times;</button>
                `;
                this.elements.lista.appendChild(itemEl);
            });

            const clearBtnContainer = document.createElement('div');
            clearBtnContainer.className = 'mt-4 text-center border-t border-skin-border pt-4';
            clearBtnContainer.innerHTML = `
                <button id="btn-vaciar-carrito" class="text-red-500 hover:text-red-700 text-sm font-semibold hover:underline transition-colors">
                    Vaciar Carrito
                </button>
            `;
            this.elements.lista.appendChild(clearBtnContainer);
        }
        this.updateTotal();
        this.updateCounter();
        this.save();
    },

    /**
     * Actualiza el cálculo del precio total en el DOM.
     */
    updateTotal: function() {
        if (!this.elements.total) return;
        const total = this.carrito.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
        this.elements.total.textContent = `Total: $${total.toLocaleString('es-CL')}`;
    },

    /**
     * Actualiza el contador del ícono flotante del carrito.
     */
    updateCounter: function() {
        if (!this.elements.counter) return;

        const totalItems = this.carrito.reduce((sum, item) => sum + item.cantidad, 0);

        if (totalItems > 0) {
            this.elements.counter.textContent = totalItems;
            this.elements.counter.classList.remove('hidden');

            // Aplicar animación de rebote
            this.elements.counter.classList.remove('bump-anim');
            void this.elements.counter.offsetWidth; // Forzar reflow para reiniciar la animación
            this.elements.counter.classList.add('bump-anim');
        } else {
            this.elements.counter.classList.add('hidden');
        }
    },

    /**
     * Agrega un producto al carrito.
     * @param {object} producto - El objeto del producto a agregar.
     */
    addItem: function(producto) {
        const itemExistente = this.carrito.find(item => item.id === producto.id);
        if (itemExistente) {
            itemExistente.cantidad++;
        } else {
            this.carrito.push({ ...producto, cantidad: 1 });
        }
        this.render();
        this.open();
        showNotification(`'${producto.nombre}' se agregó al carrito.`, 'success');
    },

    /**
     * Cambia la cantidad de un item en el carrito.
     * @param {number} index - El índice del item en el array del carrito.
     * @param {number} change - El cambio a aplicar a la cantidad (+1 o -1).
     */
    changeQuantity: function(index, change) {
        const item = this.carrito[index];
        if (item) {
            item.cantidad += change;
            if (item.cantidad <= 0) {
                this.carrito.splice(index, 1);
            }
            this.render();
        }
    },

    /**
     * Remueve un item del carrito.
     * @param {number} index - El índice del item a remover.
     */
    removeItem: function(index) {
        this.carrito.splice(index, 1);
        this.render();
    },

    /**
     * Vacía todo el contenido del carrito.
     */
    clearCart: function() {
        this.carrito = [];
        this.render();
        showNotification('El carrito ha sido vaciado.', 'warning');
    },

    /**
     * Abre el panel lateral del carrito.
     */
    open: function() {
        if (!this.elements.sidebar) return;
        this.elements.sidebar.classList.remove('hidden');
        setTimeout(() => this.elements.sidebar.classList.remove('translate-x-full'), 10);
    },

    /**
     * Cierra el panel lateral del carrito.
     */
    close: function() {
        if (!this.elements.sidebar) return;
        this.elements.sidebar.classList.add('translate-x-full');
        this.elements.sidebar.addEventListener('transitionend', () => {
            if (this.elements.sidebar.classList.contains('translate-x-full')) {
                this.elements.sidebar.classList.add('hidden');
            }
        }, { once: true });
    }
};

/**
 * Función global para agregar productos al carrito desde cualquier parte de la aplicación.
 * @param {object} producto - El objeto del producto a agregar.
 */
function agregarAlCarrito(producto) {
    MiauCart.addItem(producto);
}

// Inicializar el carrito cuando el DOM esté completamente cargado.
document.addEventListener('DOMContentLoaded', () => {
    MiauCart.init();
});