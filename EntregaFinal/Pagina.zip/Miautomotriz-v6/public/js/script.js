
tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        skin: {
                            base: 'var(--bg-main)',
                            header: 'var(--header-bg)',
                            nav: 'var(--nav-bg)',
                            accent: 'var(--accent)',
                            'accent-hover': 'var(--accent-hover)',
                            accent2: 'var(--accent2)',
                            'accent2-hover': 'var(--accent2-hover)',
                            text: 'var(--header-text)'
                        }
                    }
                }
            }
        }

// Variables globales inyectadas desde PHP (header.php)
//  var isLoggedIn, isAdmin, isEmpleado, currentUser;
/* ----------------- Funciones auxiliares para localStorage (excepto sesión) ----------------- */
function getUsuarios() { return JSON.parse(localStorage.getItem('usuarios') || '[]'); }
function saveUsuarios(u){ localStorage.setItem('usuarios', JSON.stringify(u)); }
function findUsuario(usuario, password) {
    const usuarios = getUsuarios();
    return usuarios.find(u => u.usuario === usuario && u.password === password);
}
function usuarioExiste(usuario) {
    return getUsuarios().some(u => u.usuario === usuario);
}

function getComentarios() { return JSON.parse(localStorage.getItem('comentarios') || '[]'); }
function saveComentarios(comentarios) { localStorage.setItem('comentarios', JSON.stringify(comentarios)); }

/* ----------------- Persistencia del tema ----------------- */
// modo: 'light' o 'dark'
function saveThemeMode(mode) { localStorage.setItem('miau_theme_mode', mode); }
function loadThemeMode() {
    const m = localStorage.getItem('miau_theme_mode') || 'light';
    return (m === 'dark') ? 'dark' : 'light';
}

// pag login
function togglePassword() {
            const passwordInput = document.getElementById("password");
            const toggleText = document.getElementById("toggleText");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleText.textContent = "Ocultar";
            } else {
                passwordInput.type = "password";
                toggleText.textContent = "Mostrar";
            }
        }
function togglePassword_repeat() {
            const passwordInput = document.getElementById("password-repeat");
            const toggleText = document.getElementById("toggleText_repeat");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleText.textContent = "Ocultar";
            } else {
                passwordInput.type = "password";
                toggleText.textContent = "Mostrar";
            }
        }
function redireccionarOlvido(event) {
                event.preventDefault(); // Evita que el enlace recargue la página
                const regexRUT = /\d{7,8}-[0-9kK]/;
                // 1. Obtener el valor del RUT
                const rutValue = document.getElementById("rut").value;
                if (!regexRUT.test(rutValue)) {
                    rut.reportValidity(); 
                
                rut.focus(); // Pone el cursor en el campo RUT para que el usuario escriba
                return; // Detiene la función aquí, NO redirige
            }

                // 2. Redirigir enviando el rut en la URL (GET)
                // encodeURIComponent asegura que caracteres especiales no rompan la URL
                window.location.href = 'olvidocontra.php?rut=' + encodeURIComponent(rutValue);
            }
            function confirmarEliminar(rut) {
                    // Obtenemos el modal y el botón de confirmación
                    const modal = document.getElementById('modal-eliminar');
                    const btnConfirmar = document.getElementById('btn-confirmar-eliminar');
                    
                    // Configuramos el enlace para que vaya al archivo PHP de eliminación
                    // Asegúrate de crear eliminar_usuario.php después
                    btnConfirmar.href = "eliminar_usuario.php?rut=" + rut;
                    
                    // Mostramos el modal quitando la clase 'hidden'
                    modal.classList.remove('hidden');
                }

                // Función para cerrar el modal
                function cerrarModal() {
                    const modal = document.getElementById('modal-eliminar');
                    modal.classList.add('hidden');
                }
function activarEdicion() {
    const inputs = document.querySelectorAll('.input-editable');
    
    inputs.forEach(input => {
        // Para inputs normales
        input.removeAttribute('readonly');
        // Para el select (nivel de acceso)
        input.removeAttribute('disabled');
        
        // Estilos visuales
        input.classList.remove('bg-transparent', 'border-skin-border');
        input.classList.add('bg-skin-card', 'border-blue-500', 'shadow-sm', 'px-2', 'rounded');
    });

    // ... resto de tu lógica para mostrar botones ...
    document.getElementById('grupo-visualizacion').classList.add('hidden');
    document.getElementById('grupo-edicion').classList.remove('hidden');
}

    // Funciones del Modal Eliminar (Ya las tenías)
    function confirmarEliminar(rut) {
        const modal = document.getElementById('modal-eliminar');
        const btnConfirmar = document.getElementById('btn-confirmar-eliminar');
        btnConfirmar.href = "eliminar_usuario.php?rut=" + rut;
        modal.classList.remove('hidden');
    }

document.addEventListener('DOMContentLoaded', () => {
            const btn = document.getElementById('toggle-theme');
            const menuBtn = document.getElementById('mobile-menu-btn');
            const closeBtn = document.getElementById('close-menu-btn');
            const drawer = document.getElementById('mobile-drawer');
            const overlay = document.getElementById('mobile-overlay');
            const body = document.body;


            var themeMode = loadThemeMode(); // 'light' o 'dark'

            const loginBtn = document.getElementById('login-btn');
            const registerBtn = document.getElementById('register-btn'); 
            const LOGIN_PAGE_URL = 'login.php'; 
            const REGISTER_PAGE_URL = 'register.php'; 
            // Redirecciones de login y registro
            if (loginBtn) {
                loginBtn.addEventListener('click', () => {
                    window.location.href = LOGIN_PAGE_URL;
                });
            }

            if (registerBtn) {
                registerBtn.addEventListener('click', () => {
                    window.location.href = REGISTER_PAGE_URL;
                });
            }

            function openMenu() {
                drawer.classList.remove('-translate-x-full');
                overlay.classList.remove('hidden');
                // Pequeño delay para la opacidad del overlay
                setTimeout(() => overlay.classList.remove('opacity-0'), 10);
                body.style.overflow = 'hidden'; // Evitar scroll de fondo
            }

            function closeMenu() {
                drawer.classList.add('-translate-x-full');
                overlay.classList.add('opacity-0');
                setTimeout(() => overlay.classList.add('hidden'), 300);
                body.style.overflow = '';
            }

            if (menuBtn) menuBtn.addEventListener('click', openMenu);
            if (closeBtn) closeBtn.addEventListener('click', closeMenu);
            if (overlay) overlay.addEventListener('click', closeMenu);

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMenu(); // Cierra el menú de navegación
                    // Cierra también el carrito si el módulo MiauCart está disponible y el carrito está visible
                    if (typeof MiauCart !== 'undefined' && MiauCart.elements.sidebar && !MiauCart.elements.sidebar.classList.contains('translate-x-full')) {
                        MiauCart.close();
                    }
                }
            });
            
            const loginMob = document.getElementById('login-btn-mobile');
            const regMob = document.getElementById('register-btn-mobile');
            if(loginMob) loginMob.addEventListener('click', () => window.location.href = 'login.php');
            if(regMob) regMob.addEventListener('click', () => window.location.href = 'register.php');

            // Sincronizar tema móvil con la lógica principal
            const themeMob = document.getElementById('toggle-theme-mobile');
            const themeDesk = document.getElementById('toggle-theme');
            if(themeMob && themeDesk) {
                themeMob.addEventListener('click', () => {
                    themeDesk.click(); // Dispara el evento del botón principal que ya tiene la lógica en script.js
                });
            }

            function applyThemeAndAdmin() {
            // Limpiamos todas las clases
            document.body.classList.remove('dark','green-mode','dark-green','blue-mode','dark-blue'); 

            if (isAdmin) {
                if (themeMode === 'dark') {
                    document.body.classList.add('dark-blue'); 
                    if (btn) btn.textContent = 'Modo Bosque';
                } else {
                    document.body.classList.add('blue-mode'); 
                    if (btn) btn.textContent = 'Modo Menta';
                }
            } if (isEmpleado) {
                if (themeMode === 'dark') {
                    document.body.classList.add('dark-green'); 
                    if (btn) btn.textContent = 'Modo Bosque';
                } else {
                    document.body.classList.add('green-mode'); 
                    if (btn) btn.textContent = 'Modo Menta';
                }
            } else {
                if (themeMode === 'dark') {
                    document.body.classList.add('dark'); // CAMBIO: 'dark' en vez de 'dark-mode'
                    if (btn) btn.textContent = 'Modo Claro';
                } else {
                    // Modo light por defecto (sin clase)
                    if (btn) btn.textContent = 'Modo Oscuro';
                }
            }
            }
            function reflectSessionUI() {
            // El login/logout ahora se renderiza desde PHP.
            // Solo necesitamos actualizar la UI que depende de JS
            if (typeof updateAdminUI === 'function') updateAdminUI();
            if (typeof renderProductos === 'function') renderProductos();
            if (typeof renderComentarios === 'function') renderComentarios();
            applyThemeAndAdmin();

            const navFunciones = document.getElementById('nav-funciones');
            if (navFunciones) {
                navFunciones.style.display = (isLoggedIn && (isAdmin || isEmpleado)) ? '' : 'none';
            }
            }
            if (btn) {
                btn.addEventListener('click', function() {
                    themeMode = (themeMode === 'dark') ? 'light' : 'dark';
                    saveThemeMode(themeMode);
                    applyThemeAndAdmin();
                });
            }
            

    // --- Lógica de Reseñas / Comentarios ---

    // Utilidad para escapar HTML y prevenir XSS
    window.escapeHtml = function(str) {
        if (!str) return '';
        return str.replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[m]);
    };

    // Función para renderizar los comentarios
    window.renderComentarios = function() {
        const list = document.getElementById('comentarios-list');
        if (!list) return; // Solo se ejecuta en la página de reseñas

        const comentarios = getComentarios();
        list.innerHTML = ''; // Limpiar lista

        if (comentarios.length === 0) {
            list.innerHTML = `
                <div class="text-center py-12 px-6 bg-skin-card border border-skin-border rounded-2xl shadow-xl">
                    <p class="text-lg font-medium text-skin-muted">No existen reseñas actualmente.</p>
                </div>`;
            return;
        }

        comentarios.forEach((com, index) => {
            const d = document.createElement('div');
            // Si la reseña está leída, se aplica una opacidad reducida
            const readClass = com.leido ? 'opacity-60' : '';
            d.className = `bg-skin-card border border-skin-border rounded-2xl shadow-lg p-6 transition-opacity ${readClass}`;
            
            d.innerHTML = `
                <div class="flex items-center justify-between mb-3">
                    <strong class="text-skin-main text-lg">${escapeHtml(com.nombre)}</strong>
                    <small class="text-skin-muted text-xs">${escapeHtml(com.fecha)} - ${escapeHtml(com.hora)}</small>
                </div>
                <p class="text-skin-muted">${escapeHtml(com.texto)}</p>
                <div class="flex items-center justify-end gap-3 mt-4 border-t border-skin-border pt-4">
                    <button data-index="${index}" class="mark-read-btn text-sm font-medium text-green-500 hover:text-green-400 transition-colors flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" /></svg>
                        Marcar como leída
                    </button>
                    <button data-index="${index}" class="delete-btn text-sm font-medium text-red-500 hover:text-red-400 transition-colors flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                        Eliminar
                    </button>
                </div>
            `;
            list.appendChild(d);
        });

        // Añadir listeners a los nuevos botones
        list.querySelectorAll('.mark-read-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const index = btn.dataset.index;
                const comentarios = getComentarios();
                comentarios[index].leido = !comentarios[index].leido; // Alterna el estado
                saveComentarios(comentarios);
                renderComentarios(); // Re-renderizar para reflejar el cambio
            });
        });

        list.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (confirm('¿Estás seguro de que quieres eliminar esta reseña?')) {
                    const index = btn.dataset.index;
                    const comentarios = getComentarios();
                    comentarios.splice(index, 1); // Eliminar del array
                    saveComentarios(comentarios);
                    renderComentarios(); // Re-renderizar
                }
            });
        });
    };

    // Manejador para el formulario de envío
    const comentarioForm = document.getElementById('comentario-form');
    if (comentarioForm) {
        comentarioForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const nombreInput = document.getElementById('comentario-nombre');
            const textoInput = document.getElementById('comentario-text');
            
            const comentario = {
                nombre: nombreInput.value.trim(),
                texto: textoInput.value.trim(),
                fecha: new Date().toLocaleDateString(),
                hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };

            const comentarios = getComentarios();
            comentarios.unshift(comentario); // Añadir al principio
            saveComentarios(comentarios);

            // Limpiar solo si el usuario no está logueado
            if (!nombreInput.hasAttribute('readonly')) {
                nombreInput.value = '';
            }
            textoInput.value = '';

            alert('¡Gracias por tu reseña!');
        });
    }


            reflectSessionUI();
        });
/* ----------------- Lógica para productos.php ----------------- */

// Función para manejar el modal de productos
function initProductosModals() {
    const modalTipo = document.getElementById('modal-tipo');
    const modalProducto = document.getElementById('modal-producto');
    const modalServicio = document.getElementById('modal-servicio');
    const formProducto = document.getElementById('form-producto');
    const formServicio = document.getElementById('form-servicio');
    const addMenuBtn = document.getElementById('add-menu-btn');
    const btnProducto = document.getElementById('btn-producto');
    const btnServicio = document.getElementById('btn-servicio');
    
    if (!addMenuBtn || !modalTipo) return; // Solo ejecutar si estamos en productos.php
    
    // Obtener próximos IDs desde elementos de datos si están disponibles
    const productoNumeroElem = document.getElementById('producto-numero');
    const servicioNumeroElem = document.getElementById('servicio-numero');
    const tipoNumeroElem = document.getElementById('tipo-numero');
    
    // Función para cerrar todos los modales
    function cerrarTodosModales() {
        modalTipo.classList.add('hidden');
        modalProducto.classList.add('hidden');
        modalServicio.classList.add('hidden');
    }
    
    // Abrir modal de selección de tipo
    addMenuBtn.addEventListener('click', (e) => {
        e.preventDefault(); // Prevenir envío del formulario
        cerrarTodosModales();
        modalTipo.classList.remove('hidden');
    });
    
    // ... resto del código similar al del archivo productos.php ...
}

// Inicializar cuando se cargue la página
document.addEventListener('DOMContentLoaded', function() {
    // ... código existente ...
    
    // Inicializar modales de productos si estamos en esa página
    initProductosModals();
    
    // ... resto del código existente ...
});