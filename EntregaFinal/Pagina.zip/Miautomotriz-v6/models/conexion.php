<?php
$host = "localhost";
$port = "5432"; // Puerto por defecto de Postgres
$usuario = "postgres";
$clave = "Ulagos2025$";
$bd = "miaucar";

// Cadena de conexión específica para Postgres
$str_conexion = "host=$host port=$port dbname=$bd user=$usuario password=$clave";

$conexion = pg_connect($str_conexion);

if (!$conexion) {
    die("Error de conexión: " . pg_last_error());
} else {
    // echo "Conectado a Postgres correctamente"; // Descomenta para probar
}
?>