<?php
require '/models/conexion.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function regresarConError($mensaje) {
    $_SESSION['error_registro'] = $mensaje; 
    header("Location: login.php");       
    exit();                                 
}
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $token_hash = hash("sha256", $token);

    $query = "SELECT * FROM persona WHERE token_hash = $1";
    $result = pg_query_params($conexion, $query, array($token_hash));

    if (pg_num_rows($result) > 0) {
        $user = pg_fetch_assoc($result);

        $token_expires_at = strtotime($user['token_expires_at']);
        
        if ($token_expires_at > time()) {

        } else {    
            regresarConError("El token ha expirado.");
        }
    } else {
        regresarConError("Token inválido.");
    }
} else {
    regresarConError("No se ha proporcionado un token.");
}
include 'header.php'; 
?>
<main class="bg-skin-base flex items-center justify-center min-h-screen -mt-[90px] transition-colors duration-300">
    <div class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl w-full max-w-md p-8 sm:p-10 transition-colors duration-300 relative z-10">
        
        <div class="text-center mx-auto text-skin-muted mb-8">
            <h2 class="text-2xl font-bold text-skin-muted mb-4 tracking-tight">Recuperar Contraseña</h2>
            <p class="text-skin-muted text-sm">Ingrese su nueva contraseña.</p>
            <?php if(isset($_SESSION['error_registro'])): ?>
                    <span class="absolute left-1/4 right-1/4 inline-block items-center  text-xs rounded  text-red-700 border border-red-700">
                        <?php echo ($_SESSION['error_registro']);?>
                    </span>
                    <?php unset($_SESSION['error_registro']);?>
            <?php endif; ?>
        </div>

        <form action="recuperacuentaval.php?token=<?php echo $token;?>" method="POST" class="space-y-6">
            <div class="relative group">
                <label for="password" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Contraseña</label>
                <div class="relative">
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        placeholder="••••••••" 
                        required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all pr-16"
                    >
                    <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-skin-muted hover:text-skin-accent transition-colors font-semibold focus:outline-none">
                        <span id="toggleText">Mostrar</span>
                    </button>
                </div>
            </div>
            <div class="relative group">
                <label for="password-repeat" class="block text-sm font-medium text-skin-muted mb-1 transition-colors group-focus-within:text-skin-accent">Repetir Contraseña</label>
                <div class="relative">
                    <input 
                        type="password" 
                        id="password-repeat" 
                        name="password-repeat" 
                        placeholder="••••••••" 
                        required
                        class="w-full px-4 py-3 rounded-lg bg-skin-base border border-skin-border placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-skin-accent focus:border-transparent transition-all pr-16"
                    >
                    <button type="button" onclick="togglePassword_repeat()" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-skin-muted hover:text-skin-accent transition-colors font-semibold focus:outline-none">
                        <span id="toggleText_repeat">Mostrar</span>
                    </button>
                </div>
            </div>

            <button type="submit" class="w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200">
                Cambiar Contraseña
            </button>

            <div class="text-center text-sm mt-6">
                <a href="login.php" class="text-skin-muted hover:text-skin-accent transition-colors">Volver al Login</a>
            </div>
        </form>
    </div>
</main>

<?php include 'partials/footer.php'; ?>