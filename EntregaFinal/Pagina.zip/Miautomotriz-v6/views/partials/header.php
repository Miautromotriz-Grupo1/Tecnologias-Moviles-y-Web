<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

$isLoggedIn = isset($_SESSION['rut']);
$nombreUsuario = $isLoggedIn ? $_SESSION['nombre'] : '';
$esEmpleado = $isLoggedIn && isset($_SESSION['empleado']) && $_SESSION['empleado'] == 1;
$esAdmin = $isLoggedIn && isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIAUtomotriz</title>
    <link rel="icon" type="image/svg+xml" href="../public/media/icon.ico">
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Librerías para PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>

    <link rel="stylesheet" href="../public/css/style.css?v=<?php echo @filemtime('../public/css/style.css'); ?>">
    <script>
        const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;
        const isEmpleado = <?php echo json_encode($esEmpleado); ?>;
        const isAdmin = <?php echo json_encode($esAdmin); ?>;
    </script>
    <style>
        /* --- Estilos para Notificaciones Toast --- */
        .toast-notification {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translate(-50%, 150%); /* Empieza fuera de la pantalla */
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 1000;
            transition: transform 0.4s ease-in-out, opacity 0.4s ease-in-out;
            opacity: 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .toast-notification.show {
            transform: translate(-50%, 0); /* Se desliza hacia arriba */
            opacity: 1;
        }

        .toast-notification.toast-success {
            background-color: #28a745; /* Verde éxito */
        }

        .toast-notification.toast-error {
            background-color: #dc3545; /* Rojo error */
        }

        .toast-notification.toast-warning {
            background-color: #ffc107; /* Amarillo advertencia */
            color: #212529; /* Texto oscuro para mejor contraste */
        }

        .toast-icon { font-size: 18px; line-height: 1; }

        /* Animación para el contador del carrito */
        @keyframes bump {
            0% { transform: scale(1); }
            50% { transform: scale(1.5); }
            100% { transform: scale(1); }
        }
        .bump-anim {
            animation: bump 0.3s ease-out;
        }
    </style>
</head>
<body class="antialiased font-sans flex flex-col">

    <nav class="bg-skin-header text-skin-text shadow-lg transition-colors duration-300 sticky top-0 z-40 ">
        <div class="max-w-7xl mx-auto px-4 px-8">
            <div class="flex  justify-between h-16 grid md:grid-cols-2 lg:grid-cols-3 items-center">
                
                <div class="flex items-center self-center">
                    
                    <button id="mobile-menu-btn" type="button" class="lg:hidden inline-flex items-center justify-center p-2 rounded-md hover:bg-white/10 focus:outline-none mr-2">
                        ☰
                    </button>
                            <a href="index.php" class="flex items-center gap-3 flex-shrink-0">
                                <img class="h-10 w-auto" src="../public/media/icon.ico" alt="Logo">
                                <span class="font-bold text-xl tracking-wider">MIAUtomotriz</span>
                            </a>
                    <?php if ($isLoggedIn): ?>
                <div class="flex flex-col items-center px-4">
                    <?php if ($_SESSION['empleado']==1):?>
                    <p class="text-lg items-center font-bold text-skin-text mb-1"><?php echo htmlspecialchars($nombreUsuario); ?></p>

                        <span class="inline-block items-center px-2 py-0.5 text-xs rounded bg-white/10 border border-skin-accent/30 text-sky-300">
                            Empleado
                        </span>
                    <?php elseif ($_SESSION['empleado']==2):?>
                    <p class="text-lg items-center font-bold text-skin-text mb-1"><?php echo htmlspecialchars($nombreUsuario); ?></p>

                        <span class="inline-block items-center px-2 py-0.5 text-xs rounded bg-white/10 border border-skin-accent/30 text-lime-300" >
                            Administrador
                        </span>
                    <?php else: ?>

                    <?php endif; ?>
                        
                </div>
            <?php else: ?>
                
            <?php endif; ?>
            
                </div>
                <div class="max-md:hidden flex md:justify-end lg:justify-center">
                                <a href="index.php" class="hover:bg-white/10 px-3 py-2 rounded-md text-sm font-medium transition">Inicio</a>
                                <a href="productos.php" class="hover:bg-white/10 px-3 py-2 rounded-md text-sm font-medium transition">Productos</a>
                                <?php if ($esEmpleado || $esAdmin): ?>
                                    <a href="funciones.php" class="hover:bg-white/10 px-3 py-2 rounded-md text-sm font-medium transition">Funciones</a>
                                <?php endif; ?>
                                <a href="reseña.php" class="hover:bg-white/10 px-3 py-2 rounded-md text-sm font-medium transition">Reseña</a>
                                <a href="contacto.php" class="hover:bg-white/10 px-3 py-2 rounded-md text-sm font-medium transition">Contacto</a>
                </div>
                <div class="max-lg:hidden flex justify-end ">
                    <button id="toggle-theme" class="bg-gray-700/50 hover:bg-gray-600 px-3 py-1 text-xs rounded transition border border-white/20">
                        Modo Oscuro
                    </button>

                    <?php if ($isLoggedIn): ?>
                        <a href="../controllers/logout.php" class="bg-red-600 hover:bg-red-700 px-3 py-2 rounded text-sm transition">Salir</a>
                    <?php else: ?>
                        <button id="login-btn" class="text-gray-300 hover:text-white px-3 py-2 text-sm w-100 font-medium transition">Login</button>
                        <button id="register-btn" class="bg-skin-accent hover:bg-skin-accent-hover text-white px-4 py-2 rounded-md text-sm font-medium transition shadow-md">
                            Registrarse
                        </button>
                    <?php endif; ?>
                </div>
                
            </div>
                
        <aside id="mobile-drawer" class="fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] -translate-x-full bg-skin-header border-r border-white/10 shadow-2xl transition-transform duration-300 ease-in-out flex flex-col">
        
        <div class="flex h-16 items-center justify-between border-b border-white/10 px-4 bg-skin-header">
            <span class="text-lg font-bold text-skin-text tracking-wider">MENÚ</span>
            <button id="close-menu-btn" class="rounded-md border border-white/20 p-2 text-skin-text hover:bg-red-500/20 hover:text-red-400 hover:border-red-400 transition-colors">
                ✕
            </button>
        </div>

        <nav class=" flex-1 overflow-y-auto p-4 space-y-2">
            <a href="index.php" class="md:hidden block rounded-lg px-4 py-3 text-skin-text hover:bg-white/10 hover:text-skin-accent transition-colors font-medium">Inicio</a>
            <a href="productos.php" class="md:hidden block rounded-lg px-4 py-3 text-skin-text hover:bg-white/10 hover:text-skin-accent transition-colors font-medium">Productos</a>
            <?php if ($esEmpleado || $esAdmin): ?>
                <a href="funciones.php" class="md:hidden block rounded-lg px-4 py-3 text-skin-text hover:bg-white/10 hover:text-skin-accent transition-colors font-medium">Funciones</a>
            <?php endif; ?>
            <a href="reseña.php" class="md:hidden block rounded-lg px-4 py-3 text-skin-text hover:bg-white/10 hover:text-skin-accent transition-colors font-medium">Reseña</a>
            <a href="contacto.php" class="md:hidden block rounded-lg px-4 py-3 text-skin-text hover:bg-white/10 hover:text-skin-accent transition-colors font-medium">Contacto</a>

            <div class="my-4 border-t border-white/10"></div>

            <?php if ($isLoggedIn): ?>
                <a href="../controllers/logout.php" class="block text-center w-full rounded-lg border border-red-500/50 text-red-400 py-2.5 hover:bg-red-500 hover:text-white transition-colors font-bold">
                    Cerrar Sesión
                </a>
            <?php else: ?>
                <button id="login-btn-mobile" class="mt-2 block w-full text-center rounded-lg bg-skin-accent px-4 py-3 text-skin-text hover:bg-white/10 transition-colors">
                    Iniciar Sesión
                </button>
                <button id="register-btn-mobile" class="mt-2 block w-full text-center rounded-lg bg-skin-accent2 text-white py-3 font-bold hover:brightness-110 shadow-lg shadow-skin-accent/20 transition-all">
                    Registrarse
                </button>
            <?php endif; ?>
            
            <div class="mt-6">
                <button id="toggle-theme-mobile" class="flex w-full items-center justify-between rounded-lg border border-white/10 px-4 py-3 text-skin-text hover:bg-white/5 transition-colors">
                    <span>Cambiar Tema</span>
                    <span class="text-xl">◑</span>
                </button>
            </div>
        </nav>
        
        <div class="p-4 border-t border-white/10 text-center">
             <p class="text-xs text-skin-text/40">© 2025 MIAUtomotriz</p>
        </div>
    </aside>
        </div>
            
    </nav>