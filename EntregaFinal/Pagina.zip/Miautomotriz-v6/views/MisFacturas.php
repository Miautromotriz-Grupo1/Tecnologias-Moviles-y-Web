<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
include dirname(__DIR__) . '../models/conexion.php';
include 'partials/header.php';
?>
    <main>
        <style>
        @media print {
            .no-print {
            display: none !important;
            }
        }
        </style>
        <section class="max-w-4xl mx-auto my-8 px-4">

            <!-- Barra de busqueda -->

            <div class="flex flex-col md:flex-row md:items-center md:gap-4 mb-4">
                <div class="flex items-center mr-3">
                    <a href="funciones.php" id="back-to-menu" class="bg-skin-card inline-flex items-center border border-skin-border rounded-2xl shadow-2xl px-3 py-2  rounded-lg shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 svg-text-main" viewBox="0 0 20 20" aria-hidden="true">
                          <path fill-rule="evenodd" d="M7.707 14.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L4.414 9H18a1 1 0 110 2H4.414l3.293 3.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>

                <form method="get" class="flex items-center gap-2 w-full md:w-auto">
                    <label for="buscar" class="font-semibold text-skin-muted mr-2">Buscar:</label>
                    <input id="buscar" class="w-full md:w-80 text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border rounded-2xl shadow-2xl focus:outline-none focus:ring-2 focus:ring-sky-300" name="q"  type="text" placeholder="Escribe para filtrar por N° factura o nombre" value="<?php echo isset($_GET['q'])?htmlspecialchars($_GET['q'],ENT_QUOTES):''; ?>"  />

                    <button type="submit" id="btn-buscar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md " title="Buscar">
                        <span alt="Buscar" class="svg-text-main block w-5 h-5">
                            <?php include 'media/lupa.svg'; ?>
                        </span>
                    </button>
                        <a href="MisFacturas.php" id="btn-cancelar" class="bg-skin-card border border-skin-border rounded-2xl shadow-2xl p-2 rounded-md hover:shadow-sm inline-flex items-center" title="Limpiar búsqueda">
                            <span class="svg-text-main block w-5 h-5">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                            </span>
                        </a>
                </form>

                <div class="mt-3 md:mt-0 md:ml-auto">
                    <button id="btn-crear-fac" class="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow no-print">Crear Factura</button>
                </div>
            </div>

            <!-- Tabla de facturas -->
            <div class="overflow-x-auto bg-white rounded-md shadow">
                <table class="min-w-full divide-y divide-gray-200" aria-describedby="listado-facturas">
                    <thead class="bg-gray-50">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-3">N° Factura</th>
                            <th class="px-4 py-3">Cliente</th>
                            <th class="px-4 py-3">Fecha Emisión</th>
                            <th class="px-4 py-3">Total</th>
                            <th class="px-4 py-3 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="listado-facturas" class="bg-white divide-y divide-gray-100 text-sm text-gray-700">
                        <!-- Facturas cargadas dinámicamente -->
                    </tbody>
                </table>
            </div>

        </section>
    </main>

    <!-- Modal / Plantilla de factura (mejorado) -->
    <style>
        /* Estilos generales para la factura */
        .invoice-container {
            background: linear-gradient(to bottom, #ffffff, #f9fafb);
            border: 1px solid #e5e7eb;
        }
        
        .invoice-header {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: white;
        }
        
        .invoice-section-title {
            border-left: 4px solid #3b82f6;
            padding-left: 12px;
            font-weight: 600;
            color: #1f2937;
        }
        
        .invoice-table-header {
            background: linear-gradient(to right, #f8fafc, #f1f5f9);
            font-weight: 600;
            color: #374151;
        }
        
        .signature-box {
            border: 2px dashed #d1d5db;
            border-radius: 4px;
            background: #f9fafb;
            min-height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
            transition: all 0.3s ease;
        }
        
        .signature-box:hover {
            border-color: #3b82f6;
            background: #f0f9ff;
        }
        
        .signature-container {
            background: white;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 12px;
            transition: all 0.2s ease;
            height: 100%;
        }
        
        .signature-container:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .total-section {
            background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
            color: white;
            border-radius: 8px;
        }
        
        /* Estilos para mejorar la visualización en pantalla */
        #factura-printable {
            max-width: 100%;
            overflow-x: hidden;
        }

        #fac-items tr {
            transition: all 0.2s ease;
        }

        /* Clase para visualizar cómo se verá al imprimir */
        #print-preview {
            width: 21cm;
            min-height: 29.7cm;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        /* Estilos específicos para cuando se está imprimiendo */
        #factura-printable .printing {
            transform: none !important;
            animation: none !important;
            transition: none !important;
        }

        /* Mejorar la legibilidad de los inputs en modo impresión */
        @media screen {
            #factura-printable input,
            #factura-printable textarea,
            #factura-printable select {
                border: 1px solid #d1d5db;
                background: white;
            }
        }

        /* Asegurar que las imágenes de firma no se distorsionen */
        .signature-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        /* Print: show only the printable invoice block */
        @media print {
            /* Configuración de página optimizada para tamaño CARTA */
            @page {
                margin: 0.5cm !important;
                size: Letter !important;
            }
            
            /* Reset y ocultar todo excepto el modal */
            body {
                overflow: visible !important;
                height: auto !important;
            }
            
            body > *:not(#modal-factura) {
                display: none !important;
            }
            
            /* Configurar el modal para que se comporte como el documento principal */
            #modal-factura {
                display: block !important;
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                width: 100% !important;
                height: auto !important;
                overflow: visible !important;
                background: white !important;
                z-index: 9999 !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            
            /* Resetear el contenedor interno del modal */
            #modal-factura > div {
                max-height: none !important;
                overflow: visible !important;
                width: 100% !important;
                max-width: 100% !important;
                box-shadow: none !important;
                margin: 0 !important;
                padding: 0 !important;
            }
            
            /* Ocultar elementos no imprimibles dentro del modal (botones, títulos, etc) */
            #modal-factura > div > *:not(#factura-printable) {
                display: none !important;
            }
            
            /* Mostrar solo la factura */
            #factura-printable, #factura-printable * {
                visibility: visible !important;
                box-sizing: border-box !important;
                font-family: 'Arial', 'Helvetica', sans-serif !important;
                max-width: 100% !important;
                overflow: visible !important;
            }
            
            #factura-printable { 
                position: static !important;
                width: 100% !important;
                height: auto !important;
                font-size: 11px !important;
                line-height: 1.2 !important;
                background: white !important;
                border: none !important;
                padding: 0 !important;
                margin: 0 !important;
                display: block !important;
            }
            
            /* CONTROL DE SALTOS DE PÁGINA MEJORADO */
            .page-break {
                page-break-before: always !important;
                break-before: page !important;
            }
            
            /* Mantener secciones importantes juntas */
            .keep-together {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            /* Forzar que no se dividan entre páginas */
            .no-break {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            /* Sección que SIEMPRE debe estar en nueva página si no cabe */
            .page-break-if-needed {
                page-break-before: auto !important;
                break-before: auto !important;
            }
            
            /* Asegurar que las secciones críticas no se dividan */
            .signatures-section,
            .totals-container {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            /* SI la sección de firmas está a punto de cortarse, forzar nueva página */
            .signatures-section {
                page-break-before: avoid !important;
                break-before: avoid !important;
                margin-top: 0 !important;
            }
            
            /* Si no hay  Espacio para firmas en la página actual, mover a nueva */
            .force-new-page-for-signatures {
                page-break-before: always !important;
                break-before: page !important;
            }
            
            /* Permitir que las tablas largas se dividan */
            #fac-items {
                page-break-inside: auto !important;
            }
            
            /* Pero mantener juntas las filas individuales */
            #fac-items tr {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            
            /* Si una tabla es muy larga, permitir que se divida después de X filas */
            #fac-items tr.split-point {
                page-break-after: always !important;
                break-after: page !important;
            }
            
            /* Encabezado principal */
            #factura-printable .flex.justify-between {
                display: flex !important;
                justify-content: space-between !important;
                align-items: flex-start !important;
                margin-bottom: 0.5cm !important;
                padding: 0 !important;
                border-bottom: 2px solid #1e40af !important;
                padding-bottom: 0.2cm !important;
            }
            
            /* Logo */
            #factura-printable .logo-container {
                width: 120px !important;
                height: 60px !important;
                margin: 0 !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
            }
            
            #factura-printable .logo-container img {
                max-width: 100% !important;
                max-height: 100% !important;
                object-fit: contain !important;
            }
            
            /* Título FACTURA */
            #factura-printable .invoice-header {
                background: #1e40af !important;
                color: white !important;
                padding: 0.15cm 0.3cm !important;
                margin: 0 auto 0.2cm !important;
                border-radius: 3px !important;
                text-align: center !important;
                display: block !important;
                font-size: 14px !important;
                font-weight: bold !important;
                width: auto !important;
            }
            
            #factura-printable .invoice-header h1 {
                font-size: 16px !important;
                font-weight: 900 !important;
                margin: 0 !important;
                letter-spacing: 1px !important;
            }
            
            #factura-printable .invoice-header .text-sm {
                font-size: 9px !important;
                opacity: 0.9 !important;
            }
            
            /* Datos de la empresa */
            #factura-printable .text-right {
                text-align: right !important;
                font-size: 9px !important;
                line-height: 1.2 !important;
                flex: 1 !important;
            }
            
            #factura-printable .text-right .font-bold {
                font-size: 10px !important;
                font-weight: 700 !important;
                margin-bottom: 0.05cm !important;
            }
            
            #factura-printable .text-right div {
                margin: 0.05cm 0 !important;
            }
            
            /* Información de Factura */
            #factura-printable .invoice-info-box {
                margin-bottom: 0.3cm !important;
            }
            
            /* Contenedor vehículo y cliente lado a lado */
            #factura-printable .vehicle-client-grid {
                display: grid !important;
                grid-template-columns: 1fr 1fr !important;
                gap: 0.3cm !important;
                margin-bottom: 0.3cm !important;
            }
            
            /* Caja de información de factura */
            #factura-printable .invoice-info-box {
                padding: 0.15cm !important;
                border: 1px solid #d1d5db !important;
                background: #f9fafb !important;
                border-radius: 3px !important;
                font-size: 9px !important;
                width: 100% !important;
            }
            
            /* Título de sección */
            #factura-printable .section-title {
                font-size: 11px !important;
                font-weight: 700 !important;
                color: #1e40af !important;
                margin-bottom: 0.15cm !important;
                padding-left: 0.1cm !important;
                border-left: 2px solid #1e40af !important;
            }
            
            #factura-printable .invoice-info-box .text-lg {
                font-size: 12px !important;
                font-weight: 700 !important;
                color: #1e40af !important;
                margin: 0.1cm 0 !important;
            }
            
            /* Grid para fechas */
            #factura-printable .grid.grid-cols-2.gap-3 {
                grid-template-columns: 1fr 1fr !important;
                gap: 0.1cm !important;
                margin-top: 0.1cm !important;
            }
            
            /* Datos del vehículo */
            #factura-printable .border.border-gray-200.p-4.rounded-lg.bg-white.shadow-sm {
                height: 100% !important;
                display: flex !important;
                flex-direction: column !important;
                padding: 0.15cm !important;
            }
            
            /* Grid de datos */
            #factura-printable .grid.grid-cols-1.md\:grid-cols-2.gap-3 {
                display: grid !important;
                grid-template-columns: 1fr 1fr !important;
                gap: 0.1cm !important;
                flex-grow: 1 !important;
            }
            
            /* Grid de datos del cliente */
            #factura-printable .grid.grid-cols-1.md\:grid-cols-2.gap-4 {
                display: grid !important;
                grid-template-columns: 1fr 1fr !important;
                gap: 0.1cm !important;
                flex-grow: 1 !important;
            }
            
            /* Para el md:col-span-2 */
            #factura-printable .md\:col-span-2 {
                grid-column: span 2 !important;
            }
            
            /* Labels más pequeños */
            #factura-printable .block.text-xs {
                font-size: 8px !important;
                margin-bottom: 0.03cm !important;
                font-weight: 600 !important;
            }
            
            /* Inputs como texto plano */
            #factura-printable input,
            #factura-printable textarea,
            #factura-printable select {
                border: none !important;
                background: transparent !important;
                box-shadow: none !important;
                padding: 0.03cm !important;
                margin: 0 !important;
                width: 100% !important;
                appearance: none !important;
                font-size: 9px !important;
                font-family: inherit !important;
                color: #111827 !important;
                outline: none !important;
                min-height: unset !important;
                height: auto !important;
                display: block !important;
                flex-shrink: 0 !important;
            }
            
            /* Área de texto */
            #factura-printable textarea {
                min-height: 0.8cm !important;
                resize: none !important;
                overflow: hidden !important;
                border: 1px solid #d1d5db !important;
                background: white !important;
            }
            
            #factura-printable input::placeholder,
            #factura-printable textarea::placeholder {
                color: transparent !important;
            }
            
            /* Select como texto */
            #factura-printable select {
                -webkit-appearance: none !important;
                -moz-appearance: none !important;
                appearance: none !important;
                background: none !important;
                padding-right: 0 !important;
            }
            
            /* Tabla de items compacta */
            #factura-printable .table-auto {
                width: 100% !important;
                border-collapse: collapse !important;
                font-size: 8px !important;
                border: 1px solid #d1d5db !important;
                margin: 0.2cm 0 !important;
            }
            
            #factura-printable thead {
                background: #1e40af !important;
                color: white !important;
            }
            
            #factura-printable thead th {
                padding: 0.08cm 0.1cm !important;
                border-bottom: 1px solid #1e3a8a !important;
                font-weight: 600 !important;
                font-size: 8px !important;
                text-align: left !important;
            }
            
            #factura-printable tbody td {
                padding: 0.06cm 0.1cm !important;
                border-bottom: 1px solid #e5e7eb !important;
                font-size: 8px !important;
                vertical-align: top !important;
            }
            
            #factura-printable tbody tr:nth-child(even) {
                background-color: #f9fafb !important;
            }
            
            /* Totales */
            #factura-printable .totals-container {
                background: #f8fafc !important;
                color: #111827 !important;
                padding: 0.15cm 0.2cm !important;
                border-radius: 3px !important;
                margin: 0.2cm 0 !important;
                border: 1px solid #d1d5db !important;
            }
            
            #factura-printable .totals-container .max-w-xs {
                max-width: 200px !important;
                margin-left: auto !important;
            }
            
            #factura-printable .totals-container .text-sm {
                font-size: 9px !important;
            }
            
            #factura-printable .totals-container .text-lg {
                font-size: 10px !important;
            }
            
            #factura-printable .totals-container .text-xl {
                font-size: 12px !important;
                font-weight: 700 !important;
            }
            
            /* Sección de firmas - CRÍTICO: SIEMPRE mantener junta */
            #factura-printable .signatures-section {
                margin-top: 0.3cm !important;
                padding-top: 0.2cm !important;
                border-top: 2px solid #1e40af !important;
            }
            
            #factura-printable .grid.grid-cols-1.md\:grid-cols-3 {
                display: grid !important;
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 0.2cm !important;
                align-items: stretch !important;
            }
            
            #factura-printable .signature-container {
                border: 1px solid #d1d5db !important;
                border-radius: 3px !important;
                padding: 0.1cm !important;
                background: #f9fafb !important;
                height: 100% !important;
                text-align: center !important;
            }
            
            #factura-printable .signature-box {
                height: 1.2cm !important;
                min-height: 1.2cm !important;
                border: 1px solid #9ca3af !important;
                margin-bottom: 0.1cm !important;
                background: white !important;
                border-style: dashed !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
            }
            
            #factura-printable .signature-container .text-sm {
                font-size: 9px !important;
                margin-bottom: 0.1cm !important;
                font-weight: 600 !important;
            }
            
            #factura-printable .signature-container input {
                font-size: 9px !important;
                text-align: center !important;
                padding: 0.05cm !important;
                font-weight: 500 !important;
            }
            
            /* Notas y condiciones */
            #factura-printable .mt-6.pt-4.border-t {
                margin-top: 0.2cm !important;
                padding-top: 0.15cm !important;
                border-top: 1px solid #d1d5db !important;
                font-size: 7px !important;
                line-height: 1.2 !important;
            }
            
            /* Tabla de servicios */
            #factura-printable .mt-6.bg-white.border.border-gray-200.rounded-lg.shadow-sm.overflow-hidden {
                margin-top: 0.2cm !important;
            }
            
            /* Ocultar elementos no necesarios */
            #fac-add-item, 
            #btn-imprimir-fac, 
            #btn-cerrar-fac,
            #btn-guardar-fac,
            .no-print,
            #firma-input,
            #gerente-firma-input,
            #cliente-firma-input,
            .signature-upload,
            button,
            .flex.justify-between button,
            #modal-factura > div > div.flex.items-center.justify-between.mb-4,
            .section-title.px-4.pt-4,
            .p-4.border-t.border-gray-200,
            .fa-plus,
            i {
                display: none !important;
            }
            
            /* Mostrar títulos de sección */
            #factura-printable .section-title.mb-3,
            #factura-printable .section-title.mb-4,
            #factura-printable .section-title.px-4.pt-4 {
                display: block !important;
                font-size: 11px !important;
                font-weight: 700 !important;
                color: #1e40af !important;
                margin-bottom: 0.15cm !important;
                padding-left: 0 !important;
                border-left: none !important;
                border-bottom: 1px solid #d1d5db !important;
                padding-bottom: 0.05cm !important;
            }
            
            /* Eliminar padding extra */
            #factura-printable .invoice-container.p-6 {
                padding: 0 !important;
                border: none !important;
                background: white !important;
                display: flex !important;
                flex-direction: column !important;
            }
            
            /* Anchos de columna */
            #factura-printable th.w-8\/12 {
                width: 55% !important;
            }
            
            #factura-printable th.w-1\/12 {
                width: 10% !important;
            }
            
            #factura-printable th.w-2\/12 {
                width: 17.5% !important;
            }
            
            /* Eliminar efectos visuales */
            #factura-printable * {
                box-shadow: none !important;
                text-shadow: none !important;
                border-radius: 0 !important;
            }
            
            /* Mantener bordes básicos */
            #factura-printable .border,
            #factura-printable .border-gray-200 {
                border: 1px solid #d1d5db !important;
            }
            
            /* Número de factura destacado */
            #fac-num {
                font-size: 12px !important;
                font-weight: 700 !important;
                color: #1e40af !important;
            }
            
            /* Asegurar que no haya desbordamiento */
            #factura-printable {
                overflow: visible !important;
                width: 100% !important;
                max-width: 100% !important;
            }
            
            /* Placeholder de firmas */
            #firma-placeholder,
            #gerente-firma-placeholder,
            #cliente-firma-placeholder {
                font-size: 8px !important;
                color: #6b7280 !important;
            }
            
            /* Previews de firmas */
            #firma-preview:not(.hidden),
            #gerente-firma-preview:not(.hidden),
            #cliente-firma-preview:not(.hidden) {
                max-height: 1cm !important;
                max-width: 90% !important;
                border: none !important;
                padding: 0 !important;
                background: transparent !important;
            }
            
            /* Ajuste para select de cuotas */
            #fac-cuotas {
                padding: 0.03cm !important;
                font-size: 9px !important;
                border: 1px solid #d1d5db !important;
                background: white !important;
            }
            
            /* Ajuste para comentarios */
            #veh-comentario {
                min-height: 0.8cm !important;
                overflow: hidden !important;
            }
            
            /* Nueva regla: Si hay más de X líneas en la tabla, forzar salto antes de firmas */
            .many-items ~ .signatures-section {
                page-break-before: always !important;
                break-before: page !important;
            }
            
            /* Espaciador para asegurar que no se corte */
            .spacer-for-signatures {
                height: 3cm !important;
                visibility: hidden !important;
            }
        }
    </style>

    <div id="modal-factura" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 p-6 overflow-auto">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-6xl p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-semibold text-slate-800">Factura</h2>
                <div class="flex items-center gap-2">
                    <button id="btn-guardar-fac" class="px-3 py-2 bg-sky-600 text-white rounded-md shadow-sm hover:bg-sky-700">Guardar</button>
                    <button id="btn-imprimir-fac" class="px-3 py-2 bg-emerald-600 text-white rounded-md shadow-sm hover:bg-emerald-700">Imprimir</button>
                    <button id="btn-cerrar-fac" class="px-3 py-2 bg-gray-100 text-slate-700 rounded-md hover:bg-gray-200">Cerrar</button>
                </div>
            </div>

            <div id="factura-printable" class="space-y-6 text-slate-800 invoice-container p-6">
                <!-- Logo y encabezado profesional -->
                <div class="flex justify-between items-start mb-6 keep-together">
                    <div class="logo-container w-49 h-24 flex items-center justify-center">
                        <img src="/pagina/v6/public/media/logo.png" alt="LOGO" class="max-w-full max-h-full object-contain">
                    </div>
                    <div class="text-right">
                        <div class="invoice-header px-4 py-3 rounded-lg mb-2">
                            <h1 class="text-2xl font-bold">FACTURA</h1>
                            <div class="text-sm opacity-90">Servicios Automotrices Profesionales</div>
                        </div>
                        <div class="text-xxs text-gray-700">
                            <div class="font-bold">Miau-tomotriz</div>
                            <div>correo: contacto@miautomotriz.cl</div>
                            <div>RUT: 00.000.000-0</div>
                            <div>Dirección: Calle Principal 123, Santiago</div>
                            <div>Teléfono: +56 2 1234 5678</div>
                        </div>
                    </div>
                </div>

                <!-- Sección 1: Información de Factura -->
                <div class="invoice-info-box keep-together">
                    <div class="section-title mb-3">Información de Factura</div>
                    <div class="space-y-3">
                        <div>
                            <div class="text-xs text-gray-600 font-semibold">Número de Factura</div>
                            <div class="text-lg font-bold text-blue-700 mt-1" id="fac-num">N° ( ID_factura )</div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <div class="text-xs text-gray-600">Fecha Emisión</div>
                                <div class="font-mono font-semibold mt-1" id="fac-fecha">00/00/0000</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-600">Fecha Vencimiento</div>
                                <div class="font-mono font-semibold mt-1" id="fac-venc">00/00/0000</div>
                            </div>
                        </div>
                        
                        <div>
                            <div class="text-xs text-gray-600 mb-1">Cuotas de Pago</div>
                            <select id="fac-cuotas" class="w-full p-2 border border-gray-300 rounded-md text-sm bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200">
                                <option value="1">1 cuota (Pago inmediato)</option>
                                <option value="2">2 cuotas</option>
                                <option value="3">3 cuotas</option>
                                <option value="4">4 cuotas</option>
                                <option value="5">5 cuotas</option>
                                <option value="6">6 cuotas</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Sección 2: Datos del vehículo y Datos del Cliente lado a lado -->
                <div class="vehicle-client-grid grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 keep-together">
                    <!-- Datos del vehículo -->
                    <div class="border border-gray-200 p-4 rounded-lg bg-white shadow-sm">
                        <div class="section-title mb-3">Datos del Vehículo</div>
                        <div class="space-y-3">
                            <div>
                                <label for="veh-estado-select" class="block text-xs font-semibold text-slate-700 mb-1">Estado del Servicio:</label>
                                <select id="veh-estado-select" class="w-full p-2 border border-gray-300 rounded-md text-sm bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200">
                                    <option value="">Seleccione estado...</option>
                                    <option value="revision">En revisión</option>
                                    <option value="listo">Listo para entrega</option>
                                    <option value="pendiente">Pendiente de repuestos</option>
                                    <option value="solo_repuestos">Solo repuestos</option>
                                    <option value="finalizado">Servicio finalizado</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-700 mb-1">Mecánico Encargado:</label>
                                <input id="veh-mecanico" class="w-full p-2 border border-gray-300 rounded-md text-sm bg-gray-50 font-semibold" readonly value="<?php echo (isset($_SESSION['nombre']) ? htmlspecialchars($_SESSION['nombre']) : '') . (isset($_SESSION['rut']) ? ' - ' . htmlspecialchars($_SESSION['rut']) : ''); ?>">
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div>
                                    <label for="para-matricula" class="block text-xs font-semibold text-slate-700 mb-1">Matrícula/Patente:</label>
                                    <input id="para-matricula" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Patente del vehículo (AB-CD-12)">
                                </div>
                                <div>
                                    <label for="para-chasis" class="block text-xs font-semibold text-slate-700 mb-1">Chasis:</label>
                                    <input id="para-chasis" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Número de chasis">
                                </div>
                                <div>
                                    <label for="para-motor" class="block text-xs font-semibold text-slate-700 mb-1">N° Motor:</label>
                                    <input id="para-motor" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Número de motor">
                                </div>
                                <div>
                                    <label for="para-vin" class="block text-xs font-semibold text-slate-700 mb-1">VIN:</label>
                                    <input id="para-vin" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Número de identificación vehicular">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Datos del Cliente -->
                    <div class="border border-gray-200 p-4 rounded-lg bg-white shadow-sm">
                        <div class="section-title mb-3">Datos del Cliente</div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label for="para-nombre" class="block text-xs font-semibold text-slate-700 mb-1">Nombre:</label>
                                        <input id="para-nombre" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Nombre del cliente">
                                    </div>
                                    <div>
                                        <label for="para-apellido" class="block text-xs font-semibold text-slate-700 mb-1">Apellido:</label>
                                        <input id="para-apellido" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="Apellido del cliente">
                                    </div>
                                    <div>
                                        <label for="para-rut" class="block text-xs font-semibold text-slate-700 mb-1">RUT:</label>
                                        <input id="para-rut" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="00.000.000-0">
                                    </div>
                                    <div>
                                        <label for="para-fono" class="block text-xs font-semibold text-slate-700 mb-1">Teléfono:</label>
                                        <input id="para-fono" class="w-full p-2 border border-gray-300 rounded-md text-sm" placeholder="+56 9 1234 5678">
                                    </div>
                            </div>
                            <div class="p-4">
                                <label for="veh-comentario" class="block text-xs font-semibold text-slate-700 mb-1">Comentarios del Servicio:</label>
                                <textarea id="veh-comentario" class="w-full p-2 border border-gray-300 rounded-md text-sm" rows="2" placeholder="Detalles adicionales del servicio..."></textarea>
                            </div>
                    </div>
                </div>

                <!-- Tabla de items profesional -->
                <div class="mt-6 bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden" id="table-items-container">
                    <div class="section-title px-4 pt-4">Detalle de Servicios y Repuestos</div>
                    <table class="table-auto w-full text-sm">
                        <thead class="invoice-table-header">
                            <tr class="text-left text-gray-700">
                                <th class="px-4 py-3 w-8/12">Descripción del Servicio/Repuesto</th>
                                <th class="px-4 py-3 w-1/12 text-center">Cant.</th>
                                <th class="px-4 py-3 w-2/12 text-right">Precio Unitario</th>
                                <th class="px-4 py-3 w-2/12 text-right">Importe</th>
                                <th class="px-4 py-3 w-10 text-center no-print"></th>
                            </tr>
                        </thead>
                        <tbody id="fac-items" class="bg-white divide-y divide-gray-100">
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3"><input class="w-full p-2 border border-gray-300 rounded-md desc focus:border-blue-500 focus:ring-2 focus:ring-blue-200" placeholder="Descripción del servicio o repuesto" value=""></td>
                                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md cant text-center focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="1"></td>
                                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md precio text-right focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="0"></td>
                                <td class="px-4 py-3 text-right font-semibold importe"><span class="importe-val">$ 0</span></td>
                                <td class="px-4 py-3 text-center no-print">
                                    <button type="button" class="text-red-500 hover:text-red-700 btn-remove-item p-1" title="Eliminar">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="p-4 border-t border-gray-200">
                        <button id="fac-add-item" class="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-md font-semibold transition-colors">
                            <i class="fas fa-plus mr-2"></i>Añadir Línea de Servicio/Repuesto
                        </button>
                    </div>
                </div>

                <!-- Sección de totales profesional -->
                <div class="mt-6 totals-container p-6 keep-together">
                    <div class="flex justify-end">
                        <div class="w-full max-w-xs space-y-2">
                            <div class="flex justify-between text-sm">
                                <span class="font-semibold">Subtotal</span>
                                <span id="fac-sub" class="font-mono font-bold">$ 0</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="font-semibold">IVA (19.00%)</span>
                                <span id="fac-iva" class="font-mono font-bold">$ 0</span>
                            </div>
                            <div class="flex justify-between text-lg font-bold border-t border-white/30 pt-2">
                                <span>TOTAL A PAGAR</span>
                                <span id="fac-total" class="font-mono text-xl">$ 0</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DIV ESPACIADOR PARA CONTROLAR MEJOR LOS SALTOS -->
                <div class="spacer-for-signatures print-only"></div>

                <!-- Sección de firmas profesionales (3 firmas en línea) -->
                <div class="mt-8 signatures-section keep-together">
                    <div class="section-title mb-4">Autorizaciones y Firmas</div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <!-- Firma del Mecánico -->
                        <div class="signature-container">
                            <div class="text-sm font-semibold text-gray-700 mb-2">Mecánico Encargado</div>
                            <div class="signature-upload no-print mb-2">
                                <input id="firma-input" type="file" accept="image/*" class="border p-2 text-sm w-full rounded-md" />
                            </div>
                            <div class="signature-preview signature-box flex items-center justify-center overflow-hidden">
                                <img id="firma-preview" class="max-h-full max-w-full hidden" alt="Firma Mecánico" />
                                <span id="firma-placeholder" class="text-gray-400 text-xs text-center"> </span>
                            </div>
                            <div class="mt-2 text-xs text-gray-600 text-center border-t pt-1">
                                <input type="text" class="w-full text-center bg-transparent border-none focus:outline-none text-sm" placeholder="Nombre del mecánico" value="<?php echo isset($_SESSION['nombre']) ? htmlspecialchars($_SESSION['nombre']) : 'Mecánico'; ?>" id="mecanico-firma-nombre" />
                            </div>
                        </div>

                        <!-- Firma del Gerente -->
                        <div class="signature-container">
                            <div class="text-sm font-semibold text-gray-700 mb-2">Gerente/Supervisor</div>
                            <div class="signature-upload no-print mb-2">
                                <input id="gerente-firma-input" type="file" accept="image/*" class="border p-2 text-sm w-full rounded-md" />
                            </div>
                            <div class="signature-preview signature-box flex items-center justify-center overflow-hidden">
                                <img id="gerente-firma-preview" class="max-h-full max-w-full hidden" alt="Firma Gerente" />
                                <span id="gerente-firma-placeholder" class="text-gray-400 text-xs text-center"> </span>
                            </div>
                            <div class="mt-2 text-xs text-gray-600 text-center border-t pt-1">
                                <input type="text" class="w-full text-center bg-transparent border-none focus:outline-none text-sm" placeholder="Nombre del gerente" value="Gerente / Supervisor" id="gerente-firma-nombre" />
                            </div>
                        </div>

                        <!-- Firma del Cliente -->
                        <div class="signature-container">
                            <div class="text-sm font-semibold text-gray-700 mb-2">Cliente/Representante</div>
                            <div class="signature-upload no-print mb-2">
                                <input id="cliente-firma-input" type="file" accept="image/*" class="border p-2 text-sm w-full rounded-md" />
                            </div>
                            <div class="signature-preview signature-box flex items-center justify-center overflow-hidden">
                                <img id="cliente-firma-preview" class="max-h-full max-w-full hidden" alt="Firma Cliente" />
                                <span id="cliente-firma-placeholder" class="text-gray-400 text-xs text-center"> </span>
                            </div>
                            <div class="mt-2 text-xs text-gray-600 text-center border-t pt-1">
                                <input type="text" class="w-full text-center bg-transparent border-none focus:outline-none text-sm" placeholder="Nombre del cliente" value="" id="cliente-firma-nombre" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Notas y condiciones -->
                <div class="mt-6 pt-4 border-t border-gray-200 keep-together">
                    <div class="text-xs text-gray-600">
                        <p class="font-semibold mb-1">Notas y Condiciones:</p>
                        <p>1. Los precios incluyen IVA (19%).</p>
                        <p>2. Factura válida como documento tributario.</p>
                        <p>3. Garantía de 6 meses en repuestos y servicios.</p>
                        <p>4. El cliente acepta los términos al firmar este documento.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Configuración para las 3 firmas
    const firmasConfig = [
        {
            inputId: "firma-input",
            previewId: "firma-preview",
            placeholderId: "firma-placeholder"
        },
        {
            inputId: "gerente-firma-input",
            previewId: "gerente-firma-preview",
            placeholderId: "gerente-firma-placeholder"
        },
        {
            inputId: "cliente-firma-input",
            previewId: "cliente-firma-preview",
            placeholderId: "cliente-firma-placeholder"
        }
    ];

    // Inicializar todas las firmas
    firmasConfig.forEach(config => {
        const input = document.getElementById(config.inputId);
        const preview = document.getElementById(config.previewId);
        const placeholder = document.getElementById(config.placeholderId);

        if (input && preview && placeholder) {
            input.addEventListener("change", () => {
                const file = input.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = e => {
                        preview.src = e.target.result;
                        preview.classList.remove("hidden");
                        placeholder.classList.add("hidden");
                    };
                    reader.readAsDataURL(file);
                } else {
                    preview.src = "";
                    preview.classList.add("hidden");
                    placeholder.classList.remove("hidden");
                }
            });
        }
    });
    </script>

    <script>
        const esAdmin = <?php echo ($_SESSION['empleado'] ?? 0) == 2 ? 'true' : 'false'; ?>;

        const fmt = (n) => {
            try { return n.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); } catch(e) { return Number(n).toFixed(0); }
        };

        // Variables globales para control de impresión
        let printData = null;
        const MAX_ROWS_PER_PAGE = 15; // Máximo de filas por página
        const MIN_SPACE_FOR_SIGNATURES = 8; // cm mínimo requerido para firmas

        // Función para preparar la impresión - SOLUCIÓN DEFINITIVA
        function prepareForPrint() {
            const printable = document.getElementById('factura-printable');
            const signaturesSection = document.querySelector('.signatures-section');
            
            // Sincronizar nombres de firmas antes de imprimir
            const clienteNombre = document.getElementById('para-nombre').value;
            const clienteApellido = document.getElementById('para-apellido').value;
            if (clienteNombre || clienteApellido) {
                document.getElementById('cliente-firma-nombre').value = 
                    (clienteNombre || '') + (clienteApellido ? ' ' + clienteApellido : '');
            }
            
            // Calcular número de filas
            const itemsTbody = document.getElementById('fac-items');
            const itemRows = itemsTbody.querySelectorAll('tr');
            const itemCount = itemRows.length;
            
            console.log(`Items en la factura: ${itemCount}`);
            
            // Guardar contenido original
            const originalContent = printable.innerHTML;
            
            // Si hay muchas filas (> 10), agregar clase para forzar nueva página antes de firmas
            if (itemCount > 10) {
                // Agregar clase que forzará nueva página antes de firmas en CSS
                signaturesSection.classList.add('force-new-page-for-signatures');
                console.log('Muchos items detectados, forzando nueva página para firmas');
            }
            
            // Si hay MUCHAS filas (> 20), dividir la tabla en páginas
            if (itemCount > 20) {
                console.log('Factura muy larga, dividiendo tabla...');
                divideLongTable(itemRows, itemCount);
            } else {
                // Para tablas más cortas, solo marcar para impresión
                printable.classList.add('printing');
            }
            
            // Guardar datos para restaurar después
            printData = {
                originalContent: originalContent,
                itemCount: itemCount
            };
        }

        // Función para dividir tablas muy largas
        function divideLongTable(itemRows, itemCount) {
            const totalPages = Math.ceil(itemCount / MAX_ROWS_PER_PAGE);
            const printable = document.getElementById('factura-printable');
            
            // Obtener todas las secciones de la factura
            const sections = Array.from(printable.children);
            
            // Encontrar índice de la tabla
            let tableSectionIndex = -1;
            for (let i = 0; i < sections.length; i++) {
                if (sections[i].id === 'table-items-container' || 
                    sections[i].querySelector('#fac-items')) {
                    tableSectionIndex = i;
                    break;
                }
            }
            
            if (tableSectionIndex === -1) return;
            
            // Crear nuevo contenido con páginas
            let newContent = [];
            
            // Agregar secciones antes de la tabla
            for (let i = 0; i < tableSectionIndex; i++) {
                newContent.push(sections[i].outerHTML);
            }
            
            // Crear páginas para la tabla
            for (let page = 0; page < totalPages; page++) {
                const startRow = page * MAX_ROWS_PER_PAGE;
                const endRow = Math.min(startRow + MAX_ROWS_PER_PAGE, itemCount);
                
                // Clonar la sección de tabla
                const tableSection = sections[tableSectionIndex].cloneNode(true);
                const tbody = tableSection.querySelector('#fac-items');
                
                // Limpiar tbody
                tbody.innerHTML = '';
                
                // Agregar solo las filas de esta página
                for (let i = startRow; i < endRow; i++) {
                    const row = itemRows[i];
                    const desc = row.querySelector('.desc').value;
                    const cant = row.querySelector('.cant').value;
                    const precio = row.querySelector('.precio').value;
                    const importeVal = row.querySelector('.importe-val').textContent;
                    
                    const newRow = document.createElement('tr');
                    newRow.className = 'hover:bg-gray-50';
                    newRow.innerHTML = `
                        <td class="px-4 py-3">${desc || ''}</td>
                        <td class="px-4 py-3 text-center">${cant || '1'}</td>
                        <td class="px-4 py-3 text-right">${precio || '0'}</td>
                        <td class="px-4 py-3 text-right font-semibold">${importeVal || '$ 0'}</td>
                    `;
                    tbody.appendChild(newRow);
                }
                
                // Si no es la primera página, cambiar título
                if (page > 0) {
                    const title = tableSection.querySelector('.section-title');
                    if (title) {
                        title.textContent = `Detalle de Servicios y Repuestos (Continuación - Página ${page + 1})`;
                    }
                }
                
                newContent.push(tableSection.outerHTML);
                
                // Agregar salto de página si no es la última página
                if (page < totalPages - 1) {
                    newContent.push('<div class="page-break"></div>');
                }
            }
            
            // Agregar secciones después de la tabla (totales, firmas, notas)
            for (let i = tableSectionIndex + 1; i < sections.length; i++) {
                newContent.push(sections[i].outerHTML);
            }
            
            // Reemplazar contenido
            printable.innerHTML = newContent.join('');
            printable.classList.add('printing');
        }

        // Limpiar estilos después de imprimir
        function cleanupPrintStyles() {
            const printable = document.getElementById('factura-printable');
            const signaturesSection = document.querySelector('.signatures-section');
            
            printable.classList.remove('printing');
            if (signaturesSection) {
                signaturesSection.classList.remove('force-new-page-for-signatures');
            }
            
            // Restaurar contenido original si fue modificado
            if (printData && printData.originalContent) {
                printable.innerHTML = printData.originalContent;
                printData = null;
                
                // Re-attachar listeners
                document.querySelectorAll('#fac-items tr').forEach(r => attachFacListeners(r));
                updateFacTotals();
            }
        }

        // Abrir modal factura
        document.getElementById('btn-crear-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            if (!modal) return;
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            // inicializar fecha
            clearFacForm(); // Limpiar formulario antes de usar
            const hoy = new Date();
            document.getElementById('modal-factura').dataset.fechaEmision = hoy.toISOString();
            document.getElementById('fac-fecha').textContent = hoy.toLocaleDateString();
            document.getElementById('fac-num').textContent = 'N° (Nuevo)';
            updateFacTotals();
            // focus first input
            document.querySelector('#fac-items .desc')?.focus();
        });

        // Listener para cuotas
        document.getElementById('fac-cuotas')?.addEventListener('change', updateVencimiento);

        // Cerrar modal
        document.getElementById('btn-cerrar-fac')?.addEventListener('click', function(){
            const modal = document.getElementById('modal-factura');
            clearFacForm();
            modal.classList.add('hidden'); modal.style.display = 'none';
        });

        // Cerrar al clicar fuera
        document.getElementById('modal-factura')?.addEventListener('click', function(e){
            if (e.target === this){ this.classList.add('hidden'); this.style.display='none'; }
        });

        // Añadir fila
        document.getElementById('fac-add-item')?.addEventListener('click', function(e){
            e.preventDefault();
            const tbody = document.getElementById('fac-items');
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-gray-50';
            tr.innerHTML = `
                <td class="px-4 py-3"><input class="w-full p-2 border border-gray-300 rounded-md desc focus:border-blue-500 focus:ring-2 focus:ring-blue-200" placeholder="Descripción del servicio o repuesto" value=""></td>
                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md cant text-center focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="1"></td>
                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md precio text-right focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="0"></td>
                <td class="px-4 py-3 text-right font-semibold importe"><span class="importe-val">$ 0</span></td>
                <td class="px-4 py-3 text-center no-print">
                    <button type="button" class="text-red-500 hover:text-red-700 btn-remove-item p-1" title="Eliminar">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
            attachFacListeners(tr);
            tr.querySelector('.desc')?.focus();
        });

        // Recalcula importes al cambiar cantidad o precio
        function attachFacListeners(row){
            const cant = row.querySelector('.cant');
            const precio = row.querySelector('.precio');
            if (cant) cant.addEventListener('input', updateFacTotals);
            if (precio) precio.addEventListener('input', updateFacTotals);
            
            const btnRemove = row.querySelector('.btn-remove-item');
            if (btnRemove) {
                btnRemove.addEventListener('click', function() {
                    if (document.querySelectorAll('#fac-items tr').length > 1) {
                        row.remove();
                        updateFacTotals();
                    } else {
                        // Si es la última fila, limpiar en lugar de borrar
                        row.querySelector('.desc').value = '';
                        row.querySelector('.cant').value = '1';
                        row.querySelector('.precio').value = '0';
                        updateFacTotals();
                    }
                });
            }
            updateFacTotals();
        }

        // Attach listeners for initial rows
        document.querySelectorAll('#fac-items tr').forEach(r => attachFacListeners(r));

        function updateFacTotals(){
            let subtotal = 0;
            document.querySelectorAll('#fac-items tr').forEach(tr=>{
                const c = Number((tr.querySelector('.cant')||{value:1}).value) || 0;
                const p = Number((tr.querySelector('.precio')||{value:0}).value) || 0;
                const val = +(c * p);
                const impEl = tr.querySelector('.importe-val');
                if (impEl) impEl.textContent = '$ ' + fmt(val);
                subtotal += val;
            });
            const iva = +(subtotal * 0.19);
            const total = +(subtotal + iva);
            document.getElementById('fac-sub').textContent = '$ ' + fmt(subtotal);
            document.getElementById('fac-iva').textContent = '$ ' + fmt(iva);
            document.getElementById('fac-total').textContent = '$ ' + fmt(total);
        }

        function updateVencimiento() {
            const cuotas = parseInt(document.getElementById('fac-cuotas').value, 10) || 1;
            const fechaEmisionISO = document.getElementById('modal-factura').dataset.fechaEmision;
            if (!fechaEmisionISO) return;

            const fechaVencimiento = new Date(fechaEmisionISO);
            if (cuotas > 1) {
                fechaVencimiento.setMonth(fechaVencimiento.getMonth() + (cuotas - 1));
            }
            document.getElementById('fac-venc').textContent = fechaVencimiento.toLocaleDateString();
        }

        // --- LÓGICA PARA GUARDAR Y CARGAR ---

        // Recopilar datos del formulario en un objeto
        function getFacturaData() {
            const items = [];
            document.querySelectorAll('#fac-items tr').forEach(tr => {
                items.push({
                    descripcion: tr.querySelector('.desc').value,
                    cantidad: tr.querySelector('.cant').value,
                    precio: tr.querySelector('.precio').value,
                });
            });

            const firmaMecanicoSrc = document.getElementById('firma-preview').src;
            const firmaGerenteSrc = document.getElementById('gerente-firma-preview').src;
            const firmaClienteSrc = document.getElementById('cliente-firma-preview').src;

            return {
                id: document.getElementById('modal-factura').dataset.facturaId || null,
                numero: document.getElementById('fac-num').textContent,
                fecha: document.getElementById('fac-fecha').textContent,
                vencimiento: document.getElementById('fac-venc').textContent,
                cuotas: document.getElementById('fac-cuotas').value,
                cliente: {
                    nombre: document.getElementById('para-nombre').value,
                    apellido: document.getElementById('para-apellido').value,
                    rut: document.getElementById('para-rut').value,
                    fono: document.getElementById('para-fono').value,
                    vin: document.getElementById('para-vin').value,
                    chasis: document.getElementById('para-chasis').value,
                    motor: document.getElementById('para-motor').value,
                    matricula: document.getElementById('para-matricula').value,
                },
                vehiculo: {
                    estado: document.getElementById('veh-estado-select').value,
                    mecanico: document.getElementById('veh-mecanico').value,
                    comentario: document.getElementById('veh-comentario').value,
                },
                items: items,
                firmas: {
                    mecanico: firmaMecanicoSrc.startsWith('data:image') ? firmaMecanicoSrc : null,
                    gerente: firmaGerenteSrc.startsWith('data:image') ? firmaGerenteSrc : null,
                    cliente: firmaClienteSrc.startsWith('data:image') ? firmaClienteSrc : null,
                },
                nombresFirmas: {
                    mecanico: document.getElementById('mecanico-firma-nombre').value,
                    gerente: document.getElementById('gerente-firma-nombre').value,
                    cliente: document.getElementById('cliente-firma-nombre').value,
                }
            };
        }

        // Guardar factura (botón Guardar)
        document.getElementById('btn-guardar-fac')?.addEventListener('click', async function() {
            await saveFactura();
        });

        // Imprimir (guarda y luego imprime) - VERSIÓN MEJORADA
        document.getElementById('btn-imprimir-fac')?.addEventListener('click', async function(){
            // Primero guardar si es necesario
            await saveFactura();
            
            // Preparar para impresión
            prepareForPrint();
            
            // Pequeño delay para asegurar que los estilos se apliquen
            setTimeout(() => {
                window.print();
                // Restaurar después de un delay mayor
                setTimeout(cleanupPrintStyles, 500);
            }, 100);
        });

        // Listener para limpiar estilos después de imprimir
        window.addEventListener('afterprint', function() {
            cleanupPrintStyles();
        });

        // Sincronizar nombre del cliente con la firma
        document.getElementById('para-nombre')?.addEventListener('input', function() {
            const nombre = this.value;
            const apellido = document.getElementById('para-apellido').value;
            document.getElementById('cliente-firma-nombre').value = nombre + (apellido ? ' ' + apellido : '');
        });
        
        document.getElementById('para-apellido')?.addEventListener('input', function() {
            const nombre = document.getElementById('para-nombre').value;
            const apellido = this.value;
            document.getElementById('cliente-firma-nombre').value = nombre + (apellido ? ' ' + apellido : '');
        });

        // Función para guardar en el servidor
        async function saveFactura() {
            const data = getFacturaData();
            if (!data.cliente.nombre) {
                alert('Por favor, ingrese el nombre del cliente.');
                return;
            }
            try {
                const res = await fetch('../controllers/save_factura.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                if (!res.ok) {
                    const errorText = await res.text();
                    throw new Error(`Error del servidor (${res.status}): ${errorText.substring(0, 200)}...`);
                }
                const json = await res.json();
                if (json.success) {
                    alert('Factura guardada correctamente.');
                    document.getElementById('modal-factura').dataset.facturaId = json.id;
                    document.getElementById('fac-num').textContent = 'N° ' + json.id;
                    renderFacturas();
                } else {
                    throw new Error(json.error || 'Error desconocido al guardar.');
                }
            } catch (e) {
                console.error("Error en saveFactura:", e);
                alert('Error de red al guardar la factura: ' + e.message);
            }
        }

        // Cargar y mostrar la lista de facturas
        async function renderFacturas(search = '') {
            const rawSearchQuery = search;

            const tbody = document.getElementById('listado-facturas');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Cargando...</td></tr>';
            try {
                const res = await fetch('../controllers/save_factura.php'); // Carga solo las facturas del usuario logueado por defecto
                if (!res.ok) {
                    const errorText = await res.text();
                    throw new Error(`Error del servidor (${res.status}): ${errorText.substring(0, 200)}...`);
                }
                const json = await res.json();
                if (!json.success) throw new Error(json.error || 'La respuesta del servidor no fue exitosa.');

                let facturasVisibles = json.lista.filter(factura => factura.cliente?.nombre !== 'Borrado_x');
                let facturasFiltradas = facturasVisibles;

                if (rawSearchQuery.trim()) {
                    const searchQueryNum = rawSearchQuery.toLowerCase().replace(/n°/g, '').trim();
                    const searchQuery = rawSearchQuery.toLowerCase();

                    facturasFiltradas = facturasVisibles.filter(factura => {
                        const id = String(factura.id);
                        const nombre = factura.cliente?.nombre?.toLowerCase() || '';
                        const apellido = factura.cliente?.apellido?.toLowerCase() || '';
                        return id.includes(searchQueryNum) || nombre.includes(searchQuery) || apellido.includes(searchQuery);
                    });
                }

                tbody.innerHTML = '';
                if (facturasFiltradas.length === 0) {
                    const message = rawSearchQuery ? `No se encontraron facturas para "${rawSearchQuery}".` : 'No hay facturas guardadas.';
                    tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4">${message}</td></tr>`;
                    return;
                }

                facturasFiltradas.forEach(factura => {
                    if (!factura || typeof factura.id === 'undefined' || !Array.isArray(factura.items)) {
                        console.warn('Omitiendo factura por datos incompletos:', factura);
                        return;
                    }

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="px-4 py-3 font-semibold">N° ${factura.id}</td>
                        <td class="px-4 py-3">${(factura.cliente?.nombre || '') + ' ' + (factura.cliente?.apellido || '') || 'Sin cliente'}</td>
                        <td class="px-4 py-3">${factura.fecha || 'N/A'}</td>
                        <td class="px-4 py-3 font-mono font-bold text-green-700">$ ${fmt(factura.items.reduce((total, item) => total + (item.cantidad * item.precio) * 1.19, 0))}</td>
                        <td class="px-4 py-3 text-center no-print">
                            <div class="flex justify-center items-center space-x-2">
                            <button class="btn-ver-fac px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors" data-factura-id="${factura.id}">Ver/Editar</button>
                            ${esAdmin ? `<button class="btn-borrar-fac px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors" data-factura-id="${factura.id}">Borrar</button>` : ''}
                            </div>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Error al cargar facturas.<br><small class="text-gray-400">${e.message}</small></td></tr>`;
            }
        }

        // Borrar una factura
        async function deleteFactura(id) {
            if (!confirm(`¿Estás seguro de que quieres borrar la factura N° ${id}? Esta acción no se puede deshacer.`)) {
                return;
            }
            try {
                const res = await fetch('../controllers/save_factura.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'delete', id: id, scope: esAdmin ? 'all' : 'user' })
                });
                if (!res.ok) {
                    const errorText = await res.text();
                    throw new Error(`Error del servidor (${res.status}): ${errorText.substring(0, 200)}...`);
                }
                const json = await res.json();
                if (json.success) {
                    alert('Factura borrada correctamente.');
                    renderFacturas();
                } else {
                    throw new Error(json.error || 'Error desconocido al borrar.');
                }
            } catch (e) {
                console.error("Error en deleteFactura:", e);
                alert('Error de red al borrar la factura: ' + e.message);
            }
        }

        // Cargar una factura en el modal al hacer clic en "Ver/Editar"
        document.getElementById('listado-facturas').addEventListener('click', async function(e) {
            const targetButton = e.target;

            if (targetButton.matches('.btn-borrar-fac')) {
                const id = targetButton.dataset.facturaId;
                if (id) {
                    deleteFactura(id);
                }
                return;
            }

            if (targetButton.matches('.btn-ver-fac')) {
                const id = targetButton.dataset.facturaId;
                if (!id) return;

                try {
                    const res = await fetch(`../controllers/save_factura.php?id=${id}`);
                    if (!res.ok) {
                        const errorText = await res.text();
                        throw new Error(`Error del servidor (${res.status}): ${errorText.substring(0, 200)}...`);
                    }
                    const json = await res.json();

                    if (json.success && json.factura) {
                        const factura = json.factura;
                        clearFacForm();
                        document.getElementById('modal-factura').dataset.facturaId = factura.id;

                        if (factura.fecha && factura.fecha.includes('/')) {
                            const fechaParts = factura.fecha.split('/');
                            const fechaEmisionObj = new Date(fechaParts[2], fechaParts[1] - 1, fechaParts[0]);
                            document.getElementById('modal-factura').dataset.fechaEmision = fechaEmisionObj.toISOString();
                        }

                        document.getElementById('fac-num').textContent = 'N° ' + factura.id;
                        document.getElementById('fac-fecha').textContent = factura.fecha;
                        document.getElementById('para-nombre').value = factura.cliente?.nombre || '';
                        document.getElementById('para-apellido').value = factura.cliente?.apellido || '';
                        document.getElementById('para-rut').value = factura.cliente?.rut || '';
                        document.getElementById('para-fono').value = factura.cliente?.fono || '';
                        document.getElementById('para-vin').value = factura.cliente?.vin || '';
                        document.getElementById('para-chasis').value = factura.cliente?.chasis || '';
                        document.getElementById('para-motor').value = factura.cliente?.motor || '';
                        document.getElementById('para-matricula').value = factura.cliente?.matricula || '';
                        document.getElementById('veh-estado-select').value = factura.vehiculo?.estado || '';
                        document.getElementById('veh-mecanico').value = factura.vehiculo?.mecanico || '';
                        document.getElementById('veh-comentario').value = factura.vehiculo?.comentario || '';
                        document.getElementById('fac-cuotas').value = factura.cuotas || '1';
                        
                        if (factura.nombresFirmas) {
                            document.getElementById('mecanico-firma-nombre').value = factura.nombresFirmas.mecanico || factura.vehiculo?.mecanico || 'Mecánico';
                            document.getElementById('gerente-firma-nombre').value = factura.nombresFirmas.gerente || 'Gerente / Supervisor';
                            document.getElementById('cliente-firma-nombre').value = factura.nombresFirmas.cliente || 
                                (factura.cliente?.nombre || '') + (factura.cliente?.apellido ? ' ' + factura.cliente.apellido : '');
                        } else {
                            document.getElementById('cliente-firma-nombre').value = 
                                (factura.cliente?.nombre || '') + (factura.cliente?.apellido ? ' ' + factura.cliente.apellido : '');
                        }
                        
                        updateVencimiento();

                        if (factura.firmas) {
                            if (factura.firmas.mecanico) {
                                document.getElementById('firma-preview').src = factura.firmas.mecanico;
                                document.getElementById('firma-preview').classList.remove('hidden');
                                document.getElementById('firma-placeholder').classList.add('hidden');
                            }
                            if (factura.firmas.gerente) {
                                document.getElementById('gerente-firma-preview').src = factura.firmas.gerente;
                                document.getElementById('gerente-firma-preview').classList.remove('hidden');
                                document.getElementById('gerente-firma-placeholder').classList.add('hidden');
                            }
                            if (factura.firmas.cliente) {
                                document.getElementById('cliente-firma-preview').src = factura.firmas.cliente;
                                document.getElementById('cliente-firma-preview').classList.remove('hidden');
                                document.getElementById('cliente-firma-placeholder').classList.add('hidden');
                            }
                        }

                        const tbody = document.getElementById('fac-items');
                        tbody.innerHTML = '';
                        factura.items.forEach(item => {
                            const tr = document.createElement('tr');
                            tr.className = 'hover:bg-gray-50';
                            tr.innerHTML = `
                                <td class="px-4 py-3"><input class="w-full p-2 border border-gray-300 rounded-md desc focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="${item.descripcion || ''}"></td>
                                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md cant text-center focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="${item.cantidad || 1}"></td>
                                <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md precio text-right focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="${item.precio || 0}"></td>
                                <td class="px-4 py-3 text-right font-semibold importe"><span class="importe-val">$ 0</span></td>
                                <td class="px-4 py-3 text-center no-print">
                                    <button type="button" class="text-red-500 hover:text-red-700 btn-remove-item p-1" title="Eliminar">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                    </button>
                                </td>
                            `;
                            tbody.appendChild(tr);
                            attachFacListeners(tr);
                        });
                        updateFacTotals();
                        document.getElementById('modal-factura').classList.remove('hidden');
                        document.getElementById('modal-factura').style.display = 'flex';
                    } else {
                        throw new Error(json.error || 'No se encontró la factura.');
                    }
                } catch (error) {
                    console.error("Error al cargar factura para ver/editar:", error);
                    alert('Error de red al cargar la factura: ' + error.message);
                }
            }
        });

        // Limpiar formulario
        function clearFacForm() {
            document.getElementById('modal-factura').dataset.facturaId = '';
            document.getElementById('modal-factura').dataset.fechaEmision = '';
            document.getElementById('factura-printable').querySelectorAll('input, textarea, select').forEach(el => {
                if (el.id !== 'veh-mecanico' && !el.id.includes('firma-nombre')) {
                    el.value = '';
                }
            });
            document.getElementById('fac-items').innerHTML = `
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3"><input class="w-full p-2 border border-gray-300 rounded-md desc focus:border-blue-500 focus:ring-2 focus:ring-blue-200" placeholder="Descripción del servicio o repuesto" value=""></td>
                    <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md cant text-center focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="1"></td>
                    <td class="px-4 py-3"><input type="number" min="0" step="1" class="w-full p-2 border border-gray-300 rounded-md precio text-right focus:border-blue-500 focus:ring-2 focus:ring-blue-200" value="0"></td>
                    <td class="px-4 py-3 text-right font-semibold importe"><span class="importe-val">$ 0</span></td>
                    <td class="px-4 py-3 text-center no-print">
                        <button type="button" class="text-red-500 hover:text-red-700 btn-remove-item p-1" title="Eliminar">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                    </td>
                </tr>
            `;
            document.getElementById('veh-mecanico').value = "<?php echo (isset($_SESSION['nombre']) ? htmlspecialchars($_SESSION['nombre']) : '') . (isset($_SESSION['rut']) ? ' - ' . htmlspecialchars($_SESSION['rut']) : ''); ?>";
            
            document.getElementById('mecanico-firma-nombre').value = "<?php echo isset($_SESSION['nombre']) ? htmlspecialchars($_SESSION['nombre']) : 'Mecánico'; ?>";
            document.getElementById('gerente-firma-nombre').value = "Gerente / Supervisor";
            document.getElementById('cliente-firma-nombre').value = "";
            
            attachFacListeners(document.querySelector('#fac-items tr'));
            updateFacTotals();
            document.getElementById('fac-cuotas').value = '1';
            updateVencimiento();
            
            firmasConfig.forEach(config => {
                const input = document.getElementById(config.inputId);
                const preview = document.getElementById(config.previewId);
                const placeholder = document.getElementById(config.placeholderId);
                
                if (input) input.value = '';
                if (preview) {
                    preview.src = '';
                    preview.classList.add('hidden');
                }
                if (placeholder) placeholder.classList.remove('hidden');
            });
        }

        // Carga inicial y búsqueda
        const searchInput = document.getElementById('buscar');
        const searchForm = searchInput.closest('form');

        function performSearch() {
            const query = searchInput.value.trim();
            renderFacturas(query);
        }

        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            performSearch();
        });

        // Carga inicial de la lista
        performSearch();

        // ESC para cerrar
        document.addEventListener('keydown', function(e){ if (e.key==='Escape'){ const m=document.getElementById('modal-factura'); if (m && !m.classList.contains('hidden')){ m.classList.add('hidden'); m.style.display='none'; } } });
    </script>

<?php include 'partials/footer.php'; ?>