<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1) {
    header("Location: index.php");
    exit(); 
}
include dirname(__DIR__) . '/models/conexion.php';

include 'partials/header.php';

// --- Lógica para leer datos de facturas desde la base de datos `factura` ---
$labels_ventas = [];
$datos_ventas = [];
$labels_estados = [];
$datos_estados = [];

// 1) Ventas por día últimos 30 días
$ventas_por_dia = [];
$hoy = new DateTime();
$inicio = (new DateTime())->sub(new DateInterval('P29D'));

$sql = "SELECT fechaemision::date AS fecha, COALESCE(SUM(total),0) AS total FROM factura WHERE fechaemision >= current_date - INTERVAL '29 days' GROUP BY fecha ORDER BY fecha";
$res = pg_query($conexion, $sql);
if ($res) {
    while ($row = pg_fetch_assoc($res)) {
        $fecha = $row['fecha'];
        $total = floatval($row['total']);
        $ventas_por_dia[$fecha] = $total;
    }
}

// Construir etiquetas de últimos 30 días
$period = new DatePeriod($inicio, new DateInterval('P1D'), (int)$hoy->diff($inicio)->format('%a') + 1);
foreach ($period as $d) {
    $key = $d->format('Y-m-d');
    $labels_ventas[] = $d->format('d/m');
    $datos_ventas[] = isset($ventas_por_dia[$key]) ? round($ventas_por_dia[$key], 2) : 0;
}

// 2) Conteo de estados por vehículo
$estados_crudos = [];
$sql2 = "SELECT COALESCE(data->'vehiculo'->> 'estado','desconocido') AS estado, COUNT(*) AS cnt FROM factura GROUP BY COALESCE(data->'vehiculo'->> 'estado','desconocido')";
$res2 = pg_query($conexion, $sql2);
if ($res2) {
    while ($row = pg_fetch_assoc($res2)) {
        $estado = trim(strtolower($row['estado']));
        $cnt = intval($row['cnt']);
        $estados_crudos[$estado] = ($estados_crudos[$estado] ?? 0) + $cnt;
    }
}

// Mapear estados crudos a categorías
$mapa = [
    'listo' => 'Listo',
    'solo_repuestos' => 'Listo',
    'pendiente' => 'En taller',
    'revision' => 'En taller'
];

$conteo_categorias = ['Listo' => 0, 'En taller' => 0, 'Otros' => 0];
foreach ($estados_crudos as $raw => $cnt) {
    if (isset($mapa[$raw])) {
        $conteo_categorias[$mapa[$raw]] += $cnt;
    } else {
        $conteo_categorias['Otros'] += $cnt;
    }
}

$labels_estados = array_keys($conteo_categorias);
$datos_estados = array_values($conteo_categorias);

// Calcular estadísticas adicionales
$venta_maxima = max($datos_ventas);
$venta_minima = min(array_filter($datos_ventas, function($v) { return $v > 0; }));
$venta_minima = $venta_minima ?: 0;
$venta_promedio = array_sum($datos_ventas) / count(array_filter($datos_ventas, function($v) { return $v > 0; }));
$venta_promedio = $venta_promedio ?: 0;
$dias_con_ventas = count(array_filter($datos_ventas, function($v) { return $v > 0; }));
$porcentaje_listo = $conteo_categorias['Listo'] > 0 ? round(($conteo_categorias['Listo'] / array_sum($datos_estados)) * 100, 1) : 0;

// Determinar colores de fondo según tema
$clases_fondo = [
    'light' => 'bg-gradient-to-br from-gray-50 to-gray-100',
    'dark' => 'bg-gradient-to-br from-gray-800 to-gray-900',
    'green-mode' => 'bg-gradient-to-br from-emerald-50 to-green-100',
    'dark-green' => 'bg-gradient-to-br from-emerald-800 to-green-900',
    'blue-mode' => 'bg-gradient-to-br from-blue-50 to-indigo-100',
    'dark-blue' => 'bg-gradient-to-br from-blue-800 to-indigo-900'
];

$clase_fondo_principal = $clases_fondo[$tema_actual] ?? $clases_fondo['light'];

// Determinar nombre del rol
$nombre_rol = 'Cliente';
if ($nivel_empleado == 1) {
    $nombre_rol = 'Admin Verde';
} elseif ($nivel_empleado == 2) {
    $nombre_rol = 'Admin Azul';
}
?>

<main class="min-h-screen p-4 md:p-6 transition-colors duration-300">
    <div class="max-w-7xl mx-auto">
        <!-- Header Mejorado con Selector de Tema -->
        <div class="mb-8">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold text-skin-main">Dashboard de Reportes</h1>
                    <p class="text-skin-muted mt-2">
                        Resumen de ventas y estado de vehículos 
                        
                    </p>
                </div>
                
                <div class="flex items-center space-x-4">
                    
                    <div class="flex items-center space-x-2">
                        <span class="text-sm text-skin-muted">Actualizado hoy</span>
                        <div class="bg-skin-card rounded-lg p-2 shadow-sm border border-skin-border">
                            <span class="text-skin-main font-medium">
                                <?php echo date('d/m/Y'); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tarjetas de Resumen Estadístico -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
            <!-- Tarjeta Ventas -->
            <div class="bg-skin-card rounded-2xl shadow-lg p-5 border-l-4 border-skin-accent transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-skin-muted font-medium">Ventas (30 días)</p>
                        <p class="text-2xl md:text-3xl font-bold text-skin-main mt-1">$<?php echo number_format(array_sum($datos_ventas), 0, ',', '.'); ?></p>
                        <p class="text-xs text-skin-muted mt-1"><?php echo $dias_con_ventas; ?> días con ventas</p>
                    </div>
                    <div class="bg-skin-accent/10 p-3 rounded-xl">
                        <svg class="w-6 h-6 text-skin-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-skin-border">
                    <div class="flex justify-between text-sm">
                        <span class="text-skin-muted">Promedio diario</span>
                        <span class="font-semibold text-skin-main">$<?php echo number_format($venta_promedio, 0, ',', '.'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Vehículos Listos -->
            <div class="bg-skin-card rounded-2xl shadow-lg p-5 border-l-4 border-green-500 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-skin-muted font-medium">Vehículos Listos</p>
                        <p class="text-2xl md:text-3xl font-bold text-skin-main mt-1">
                            <?php echo $conteo_categorias['Listo']; ?>
                        </p>
                        <p class="text-xs text-skin-muted mt-1"><?php echo $porcentaje_listo; ?>% del total</p>
                    </div>
                    <div class="bg-green-500/10 p-3 rounded-xl">
                        <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-skin-border">
                    <div class="flex justify-between text-sm">
                        <span class="text-skin-muted">Estado: Disponible</span>
                        <span class="font-semibold text-green-500">Listo para entrega</span>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta En Taller -->
            <div class="bg-skin-card rounded-2xl shadow-lg p-5 border-l-4 border-yellow-500 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-skin-muted font-medium">En Taller</p>
                        <p class="text-2xl md:text-3xl font-bold text-skin-main mt-1">
                            <?php echo $conteo_categorias['En taller']; ?>
                        </p>
                        <p class="text-xs text-skin-muted mt-1">En proceso de reparación</p>
                    </div>
                    <div class="bg-yellow-500/10 p-3 rounded-xl">
                        <svg class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-skin-border">
                    <div class="flex justify-between text-sm">
                        <span class="text-skin-muted">Estado: En proceso</span>
                        <span class="font-semibold text-yellow-500">Revisión/Reparación</span>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Total Vehículos -->
            <div class="bg-skin-card rounded-2xl shadow-lg p-5 border-l-4 border-purple-500 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-skin-muted font-medium">Total Vehículos</p>
                        <p class="text-2xl md:text-3xl font-bold text-skin-main mt-1">
                            <?php echo array_sum($datos_estados); ?>
                        </p>
                        <p class="text-xs text-skin-muted mt-1">Registrados en sistema</p>
                    </div>
                    <div class="bg-purple-500/10 p-3 rounded-xl">
                        <svg class="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-skin-border">
                    <div class="flex justify-between text-sm">
                        <span class="text-skin-muted">Otros estados</span>
                        <span class="font-semibold text-skin-main"><?php echo $conteo_categorias['Otros']; ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Gráficos -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Gráfico de Ventas -->
            <div class="bg-skin-card rounded-2xl shadow-lg overflow-hidden">
                <div class="px-6 pt-6 pb-2">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <h2 class="text-xl font-bold text-skin-main">Evolución de Ventas</h2>
                            <p class="text-skin-muted text-sm">Últimos 30 días</p>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="flex items-center">
                                <span class="w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
                                <span class="text-sm text-skin-muted">Ventas diarias</span>
                            </div>
                            <div class="bg-blue-500/10 text-blue-500 px-3 py-1 rounded-lg text-sm font-medium">
                                <span class="hidden sm:inline">Total: </span>$<?php echo number_format(array_sum($datos_ventas), 0, ',', '.'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-2 pt-2 pb-6">
                    <div class="h-80">
                        <canvas id="graficoVentas"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Gráfico de Estados -->
            <div class="bg-skin-card rounded-2xl shadow-lg overflow-hidden">
                <div class="px-6 pt-6 pb-2">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <h2 class="text-xl font-bold text-skin-main">Estado de Vehículos</h2>
                            <p class="text-skin-muted text-sm">Distribución actual</p>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="bg-green-500/10 text-green-500 px-3 py-1 rounded-lg text-sm font-medium">
                                Total: <?php echo array_sum($datos_estados); ?> vehículos
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center p-2">
                    <div class="w-full lg:w-2/5 p-4">
                        <div class="h-64">
                            <canvas id="graficoEstados"></canvas>
                        </div>
                    </div>
                    <div class="w-full lg:w-3/5 p-4">
                        <div class="space-y-4">
                            <?php foreach($labels_estados as $index => $estado): 
                                $porcentaje = array_sum($datos_estados) > 0 ? round(($datos_estados[$index] / array_sum($datos_estados)) * 100, 1) : 0;
                            ?>
                            <div class="bg-skin-base rounded-xl p-4 hover:bg-skin-card-hover transition-colors duration-200">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center">
                                        <span class="w-4 h-4 rounded-full mr-3" style="--chart-color-0: #3b82f6; --chart-color-1: #22c55e; --chart-color-2: #f59e0b; background-color: var(--chart-color-<?php echo $index; ?>)"></span>
                                        <span class="font-medium text-skin-main"><?php echo $estado; ?></span>
                                    </div>
                                    <span class="text-lg font-bold text-skin-main"><?php echo $datos_estados[$index]; ?></span>
                                </div>
                                <div class="flex items-center justify-between text-sm">
                                    <span class="text-skin-muted"><?php echo $porcentaje; ?>% del total</span>
                                    <div class="w-32 bg-skin-base-muted rounded-full h-2">
                                        <div class="h-2 rounded-full" style="width: <?php echo $porcentaje; ?>%; background-color: var(--chart-color-<?php echo $index; ?>)"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Incluir Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const labelsVentas = <?php echo json_encode($labels_ventas); ?>;
    const datosVentas = <?php echo json_encode($datos_ventas); ?>;
    const labelsEstados = <?php echo json_encode($labels_estados); ?>;
    const datosEstados = <?php echo json_encode($datos_estados); ?>;
    
    // Función para obtener colores del tema desde CSS
    const getThemeColors = () => {
        const style = getComputedStyle(document.documentElement);
        return {
            gridColor: style.getPropertyValue('--border-color').trim() + '33', // con opacidad
            textColor: style.getPropertyValue('--text-main').trim(),
            mutedTextColor: style.getPropertyValue('--text-muted').trim(),
            accentColor: style.getPropertyValue('--accent').trim(),
            cardBg: style.getPropertyValue('--bg-card').trim(),
            chartColors: [
                '#3b82f6', // Azul para "En taller"
                '#22c55e', // Verde para "Listo"
                '#f59e0b'  // Ámbar para "Otros"
            ]
        };
    };
    const theme = getThemeColors();
    
    // Gráfico de Ventas
    const ctxVentas = document.getElementById('graficoVentas').getContext('2d');
    const gradient = ctxVentas.createLinearGradient(0, 0, 0, 400);
    
    gradient.addColorStop(0, theme.accentColor + '4D'); // 30% opacidad
    gradient.addColorStop(1, theme.accentColor + '0D'); // 5% opacidad
    
    new Chart(ctxVentas, {
        type: 'line',
        data: {
            labels: labelsVentas,
            datasets: [{ 
                label: 'Ventas Diarias',
                data: datosVentas,
                borderColor: theme.accentColor,
                backgroundColor: gradient,
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: theme.accentColor,
                pointBorderColor: theme.cardBg,
                pointBorderWidth: 3,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: theme.cardBg,
                    titleColor: theme.textColor,
                    bodyColor: theme.textColor,
                    borderColor: theme.gridColor,
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    boxPadding: 6,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += new Intl.NumberFormat('es-CL', { 
                                    style: 'currency', 
                                    currency: 'CLP',
                                    minimumFractionDigits: 0 
                                }).format(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false,
                        color: theme.gridColor
                    },
                    ticks: {
                        stepSize: 1,
                        callback: function(value, index, values) {
                            return new Intl.NumberFormat('es-CL', { 
                                style: 'currency', 
                                currency: 'CLP', 
                                minimumFractionDigits: 0 
                            }).format(value);
                        },
                        font: {
                            size: 11
                        },
                        padding: 10,
                        color: theme.mutedTextColor
                    },
                    title: {
                        display: true,
                        text: 'Monto de Venta (CLP)',
                        font: {
                            size: 12,
                            weight: 'bold'
                        },
                        padding: {top: 10, bottom: 10},
                        color: theme.textColor
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 11
                        },
                        maxRotation: 45,
                        color: theme.mutedTextColor
                    },
                    title: {
                        display: true,
                        text: 'Fecha (día/mes)',
                        font: {
                            size: 12,
                            weight: 'bold'
                        },
                        padding: {top: 10, bottom: 10},
                        color: theme.textColor
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index',
            }
        }
    });
    
    // Gráfico de Estados
    const ctxEstados = document.getElementById('graficoEstados').getContext('2d');
    
    new Chart(ctxEstados, {
        type: 'doughnut',
        data: {
            labels: labelsEstados,
            datasets: [{
                data: datosEstados,
                backgroundColor: theme.chartColors,
                borderColor: theme.cardBg,
                borderWidth: 3,
                hoverOffset: 20,
                hoverBorderWidth: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: theme.cardBg,
                    titleColor: theme.textColor,
                    bodyColor: theme.textColor,
                    borderColor: theme.gridColor,
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    boxPadding: 6,
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} vehículos (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Manejar el menú de temas para mantenerlo abierto al hacer clic
    const themeToggle = document.getElementById('theme-toggle');
    const themeMenu = document.getElementById('theme-menu');
    
    themeToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        themeMenu.classList.toggle('hidden');
    });
    
    // Cerrar el menú al hacer clic fuera
    document.addEventListener('click', function() {
        themeMenu.classList.add('hidden');
    });
    
    // Prevenir que se cierre al hacer clic dentro del menú
    themeMenu.addEventListener('click', function(e) {
        e.stopPropagation();
    });
});
</script>

<?php include 'partials/footer.php'; ?>