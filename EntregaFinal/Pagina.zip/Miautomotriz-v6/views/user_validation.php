<?php
require '/models/conexion.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function regresarConError($mensaje) {
    $_SESSION['error_registro'] = $mensaje; // Guardamos el error "en la mochila"
    header("Location: login.php");       // Nos devolvemos al formulario
    exit();                                 // Detenemos este script
}
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $token_hash = hash("sha256", $token);

    $query = "SELECT * FROM persona WHERE token_hash = $1";
    $result = pg_query_params($conexion, $query, array($token_hash));

    if (pg_num_rows($result) > 0) {
        $user = pg_fetch_assoc($result);
        $token_expires_at = strtotime($user['token_expires_at']);
        
        if ($token_expires_at > time()) {
            $query = "UPDATE persona SET personaveri = TRUE, token_hash = NULL, token_expires_at = NULL WHERE rut = $1";
            $result = pg_query_params($conexion, $query, array($user['rut']));

            if ($result) {
                $_SESSION['mensaje_exito'] = "Correo verificado correctamente. Ya puedes iniciar sesión en WEB o APP.";
                header("Location: login.php");
                exit();
            } else {
                regresarConError("Error al verificar el correo.");
            }
        } else {
            regresarConError("El token ha expirado.");
        }
    } else {
        regresarConError("Token inválido.");
    }
} else {
    regresarConError("No se ha proporcionado un token.");
}
?>
