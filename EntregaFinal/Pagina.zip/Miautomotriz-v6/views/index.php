<?php
include 'partials/header.php';
@include '../models/conexion.php'; // Incluir la conexión a la base de datos

$productos = [];
$proximo_id_producto = 1;
$proximo_id_servicio = 1;
$productos_para_servicios = [];

if (isset($conexion) && $conexion) {
    // Obtener el último ID de productos
    $query_last_id = "SELECT COALESCE(MAX(id), 0) + 1 as next_id FROM piezas";
    $res_last = pg_query($conexion, $query_last_id);
    if ($res_last) {
        $row_last = pg_fetch_assoc($res_last);
        $proximo_id_producto = $row_last['next_id'];
        $proximo_id_servicio = $row_last['next_id'];
    }
    
    // Obtener productos para el modal de selección (solo productos, no servicios)
    $query_productos = "SELECT id, nombre, precio_v, marca FROM piezas WHERE servicio = 0 ORDER BY nombre";
    $res_productos = pg_query($conexion, $query_productos);
    if ($res_productos) {
        while ($row = pg_fetch_assoc($res_productos)) {
            $productos_para_servicios[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio_v' => $row['precio_v'],
                'marca' => $row['marca'] ?? ''
            ];
        }
    }

    // Consulta para obtener los ÚLTIMOS 3 productos de la base de datos
    $res = pg_query($conexion, "SELECT id, nombre, precio_v AS precio, img, marca, EXTRACT(YEAR FROM anio) AS anio, cantidad, servicio, n_bodega FROM piezas WHERE (servicio = 1 OR cantidad > 0) ORDER BY id DESC LIMIT 3");
    if ($res) {
        while ($row = pg_fetch_assoc($res)) {
            $imagen_path = $row['img'] ?? '';
            // Prepend path for relative URLs, ignore absolute URLs
            if (!empty($imagen_path) && !filter_var($imagen_path, FILTER_VALIDATE_URL)) {
                $imagen_path = '../public/' . ltrim($imagen_path, '/');
            }

            // Mapear las columnas de la BD a las claves que espera la plantilla
            $productos[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio' => $row['precio'],
                'imagen' => $imagen_path, // 'img' de la BD se convierte en 'imagen'
                'marca' => $row['marca'] ?? '',
                'anio' => $row['anio'] ?? '',
                'cantidad' => $row['cantidad'] ?? 0,
                'servicio' => $row['servicio'] ?? 0,
                'n_bodega' => $row['n_bodega'] ?? 0,
                'alt' => 'Imagen de ' . htmlspecialchars($row['nombre'])
            ];
        }
    } else {
        // Si la consulta falla, guardamos el error para mostrarlo.
        $db_error = "Error al cargar productos destacados: " . pg_last_error($conexion);
    }
}
?>

<main class="flex-grow max-w-7xl min-h-screen mx-auto w-full p-4 md:p-8">
    <h2 class="text-2xl font-bold mb-4">Ultimos Productos Agregados</h2>

    <!-- Contenedor de productos en formato Grid -->
    <div id="productos-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if (isset($db_error)): ?>
            <div class="col-span-full bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">¡Error!</strong>
                <span class="block sm:inline"><?php echo htmlspecialchars($db_error); ?></span>
            </div>
        <?php else: ?>
            <?php foreach ($productos as $i => $producto) : ?>
            <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg w-full p-6 transition-colors duration-300 flex flex-col h-full" data-id="<?php echo $producto['id']; ?>">
                <div class="prod-img-wrap w-full h-56 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center mb-4 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400">Imagen no disponible</div>
                    <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['alt']); ?>" class="object-cover w-full h-full relative z-10" onerror="this.style.display='none'">
                </div>
                <div class="flex-1 text-center">
                    <h3 class="text-lg font-bold mb-2"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                    <div class="text-sm text-skin-muted mb-2">
                        <span class="prod-marca"><?php echo htmlspecialchars($producto['marca'] ?? ''); ?></span>
                        <span class="prod-anio"><?php echo !empty($producto['anio']) ? ' - ' . htmlspecialchars($producto['anio']) : ''; ?></span>
                    </div>
                    <?php 
                    // Verificar si es servicio (por marca o categoría)
                    $es_servicio = ($producto['servicio'] == 1);
                    $stock = (int)$producto['cantidad'];
                    ?>
                    <?php if (!$es_servicio): ?>
                        <?php if ($stock <= 0): ?>
                            <p class="text-red-500 font-bold mb-2">Agotado</p>
                        <?php else: ?>
                            <p class="text-sm text-skin-muted mb-2">Disponibles: <?php echo $stock; ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php 
                    // Calcular precio con IVA (19% en Chile)
                    if ($es_servicio) {
                        // Para servicios, 'precio' es el final.
                        $precio_con_iva = round((float)($producto['precio'] ?? 0));
                    } else {
                        // Para productos, 'precio' es sin IVA.
                        $precio_sin_iva = (float)($producto['precio'] ?? 0);
                        $iva_calculado = $precio_sin_iva * 0.19;
                        $precio_con_iva = round($precio_sin_iva + $iva_calculado);
                    }
                    ?>
                    <p class="text-skin-muted font-medium mb-2 text-xl">$<?php echo number_format($precio_con_iva, 0, ',', '.'); ?></p>
                    <?php if (!$es_servicio): ?><p class="text-sm text-skin-muted">(IVA incluido: $<?php echo number_format(round($iva_calculado), 0, ',', '.'); ?>)</p><?php endif; ?>
                </div>
                <div class="mt-auto">
                    <?php if (!$es_servicio && $stock <= 0): ?>
                    <button class="w-full bg-gray-400 text-white font-bold py-2 rounded-lg shadow-md cursor-not-allowed" disabled>
                        Agotado
                    </button>
                    <?php else: ?>
                    <button class="add-to-cart w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-2 rounded-lg shadow-md transition transform active:scale-95" data-id="<?php echo htmlspecialchars($producto['id']); ?>" data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>" data-precio="<?php echo htmlspecialchars($precio_con_iva); ?>" data-img="<?php echo htmlspecialchars($producto['imagen']); ?>">
                        Agregar al carrito
                    </button>
                    <?php endif; ?>
                </div>
                <?php if (isset($esAdmin) && $esAdmin): ?>
                <div class="mt-3 flex gap-2">
                    <button class="borrar-btn px-3 py-1 bg-red-500 text-white rounded-md" data-id="<?php echo htmlspecialchars($producto['id']); ?>">Eliminar</button>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="text-center mt-10">
        <a href="productos.php" class="inline-block bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-1 hover:shadow-xl">
            Ver todos los productos
        </a>
    </div>

    <!-- Sección de Presentación de la Empresa -->
    <div class="mt-16 mb-12">
        <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg p-8 md:p-10">
            <h2 class="text-3xl font-bold text-center text-skin-muted mb-8">Sobre Miau-tomotriz</h2>
            <div class="grid md:grid-cols-2 gap-8">
                
                <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                    <h3 class="text-2xl font-semibold mb-4 text-skin-main">Tu Taller Mecánico de Confianza</h3>
                    <p class="text-skin-muted mb-4">
                        En Miau-tomotriz, nos apasiona mantener tu vehículo en perfectas condiciones. Ofrecemos un servicio integral con personal certificado y equipos de última generación para garantizar la calidad y tu seguridad.
                    </p>
                    <ul class="list-disc list-inside space-y-1 text-skin-muted">
                        <li>Mantenimiento preventivo y correctivo</li>
                        <li>Diagnóstico computarizado avanzado</li>
                        <li>Reparación de frenos, motor y transmisión</li>
                        <li>Servicio eléctrico y venta de repuestos</li>
                    </ul>
                </div>
                
                <div class="bg-skin-base border border-skin-border rounded-xl p-6">
                    <h3 class="text-2xl font-semibold mb-4 text-skin-main">Proximamente Encuentra tu Próximo Vehículo Aqui con Nosotros</h3>
                    <p class="text-skin-muted">
                        Como futura automotora, te ofreceremos una selección de vehículos nuevos y seminuevos cuidadosamente inspeccionados. Nuestro compromiso será brindarte transparencia, asesoría personalizada y las mejores opciones de financiamiento, para que puedas tomar la mejor decisión.
                    </p>
                </div>
            </div>
        </div>
    </div>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Agregar al carrito
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function() {
            const producto = {
                id: this.dataset.id,
                nombre: this.dataset.nombre,
                precio: parseFloat(this.dataset.precio),
                img: this.dataset.img
            };
            
            // Agregar al carrito usando la función global
            if (typeof agregarAlCarrito === 'function') {
                agregarAlCarrito(producto);
            } else {
                console.error('La función del carrito no está disponible. Asegúrate de que cart.js esté cargado.');
            }
        });
    });
    
    // Prevenir envío del formulario con Enter en campos no submit
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && e.target.type !== 'submit' && e.target.tagName !== 'BUTTON') {
                e.preventDefault();
                this.submit();
            }
        });
    }
});
</script>
<?php include 'partials/footer.php'; ?>