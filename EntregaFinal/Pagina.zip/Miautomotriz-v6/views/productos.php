<?php
include 'partials/header.php';
include dirname(__DIR__) . '/models/conexion.php';

// Obtener el término de búsqueda de la URL
$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$precio_min = isset($_GET['precio_min']) && is_numeric($_GET['precio_min']) ? (int)$_GET['precio_min'] : '';
$precio_max = isset($_GET['precio_max']) && is_numeric($_GET['precio_max']) ? (int)$_GET['precio_max'] : '';
$filtro_marca = isset($_GET['filtro_marca']) ? $_GET['filtro_marca'] : 'todos';

$esAdmin = isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2;
$productos = [];

// Obtener el próximo ID disponible para productos
$proximo_id_producto = 1;
$proximo_id_servicio = 1;

// Obtener productos para el modal de selección en servicios
$productos_para_servicios = [];

if (isset($conexion) && $conexion) {
    // Obtener el último ID de productos
    $query_last_id = "SELECT COALESCE(MAX(id), 0) + 1 as next_id FROM piezas";
    $res_last = pg_query($conexion, $query_last_id);
    if ($res_last) {
        $row_last = pg_fetch_assoc($res_last);
        $proximo_id_producto = $row_last['next_id'];
        $proximo_id_servicio = $row_last['next_id'];
    }
    
    // Obtener productos para el modal de selección (solo productos, no servicios)
    $query_productos = "SELECT id, nombre, precio_v, marca FROM piezas WHERE servicio = 0 ORDER BY nombre";
    $res_productos = pg_query($conexion, $query_productos);
    if ($res_productos) {
        while ($row = pg_fetch_assoc($res_productos)) {
            $productos_para_servicios[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio_v' => $row['precio_v'],
                'marca' => $row['marca'] ?? ''
            ];
        }
    }
    
    // Consulta de productos para mostrar en la página principal
    $base_query = "SELECT id, nombre, precio_v, precio_c, img, marca, anio, n_bodega, cantidad, categoria, servicio FROM piezas";
    $conditions = [];
    $params = [];
    $param_count = 1;

    if (!empty($search_query)) {
        $conditions[] = "(nombre ILIKE $" . $param_count . " OR marca ILIKE $" . $param_count . ")";
        $params[] = '%' . $search_query . '%';
        $param_count++;
    }
    if ($precio_min !== '') {
        $conditions[] = "precio_v >= $" . $param_count;
        $params[] = $precio_min;
        $param_count++;
    }
    if ($precio_max !== '') {
        $conditions[] = "precio_v <= $" . $param_count;
        $params[] = $precio_max;
        $param_count++;
    }

    if ($filtro_marca === 'servicios') {
        $conditions[] = "servicio = 1";
    } elseif ($filtro_marca === 'productos') {
        $conditions[] = "servicio = 0";
    }

    $query = $base_query . (!empty($conditions) ? " WHERE " . implode(' AND ', $conditions) : "") . " ORDER BY id ASC";
    $res = pg_query_params($conexion, $query, $params);

    if ($res) {
        while ($row = pg_fetch_assoc($res)) {
            $imagen_path = $row['img'] ?? '';
            // Prepend path for relative URLs, ignore absolute URLs
            if (!empty($imagen_path) && !filter_var($imagen_path, FILTER_VALIDATE_URL)) {
                $imagen_path = '../public/' . ltrim($imagen_path, '/');
            }

            $anio_completo = $row['anio'] ?? '';
            $anio_display = $anio_completo ? date('Y', strtotime($anio_completo)) : '';
            $productos[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'precio' => $row['precio_v'],
                'precio_c' => $row['precio_c'] ?? 0,
                'imagen' => $imagen_path,
                'marca' => $row['marca'] ?? '',
                'anio' => $anio_display,
                'anio_completo' => $anio_completo,
                'n_bodega' => $row['n_bodega'] ?? 0,
                'cantidad' => $row['cantidad'] ?? 0,
                'categoria' => $row['categoria'] ?? '',
                'servicio' => $row['servicio'] ?? 0,
                'alt' => 'Imagen de ' . htmlspecialchars($row['nombre'])
            ];
        }
    } else {
        $db_error = "Error al consultar la base de datos: " . pg_last_error($conexion);
    }
}
?>

<main class="flex-grow max-w-7xl min-h-screen mx-auto w-full p-4 md:p-8">
    <h2 class="text-3xl font-bold mb-8 text-center">Todos Nuestros Productos</h2>

    <!-- Botones de Filtro por Marca -->
    <div class="mb-4 flex justify-center gap-2">
        <a href="productos.php?filtro_marca=todos" class="px-4 py-2 rounded-lg text-sm font-semibold <?php echo $filtro_marca === 'todos' ? 'bg-skin-accent text-white' : 'bg-skin-card border border-skin-border text-skin-muted'; ?>">
            Todo
        </a>
        <a href="productos.php?filtro_marca=productos" class="px-4 py-2 rounded-lg text-sm font-semibold <?php echo $filtro_marca === 'productos' ? 'bg-skin-accent text-white' : 'bg-skin-card border border-skin-border text-skin-muted'; ?>">
            Productos
        </a>
        <a href="productos.php?filtro_marca=servicios" class="px-4 py-2 rounded-lg text-sm font-semibold <?php echo $filtro_marca === 'servicios' ? 'bg-skin-accent text-white' : 'bg-skin-card border border-skin-border text-skin-muted'; ?>">
            Servicios
        </a>
    </div>

    <!-- Barra de búsqueda -->
    <div class="mb-8 max-w-2xl mx-auto p-4 bg-skin-card2 rounded-lg border border-skin-border">
        <form id="search-form" method="get" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
            <div class="md:col-span-2">
                <label for="buscar" class="block text-sm font-medium text-skin-muted mb-1">Buscar</label>
                <input id="buscar" name="q" type="text" placeholder="Nombre o marca..." value="<?php echo htmlspecialchars($search_query); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div>
                <label for="precio_min" class="block text-sm font-medium text-skin-muted mb-1">Precio Mín.</label>
                <input id="precio_min" name="precio_min" type="number" placeholder="0" value="<?php echo htmlspecialchars($precio_min); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div>
                <label for="precio_max" class="block text-sm font-medium text-skin-muted mb-1">Precio Máx.</label>
                <input id="precio_max" name="precio_max" type="number" placeholder="Sin límite" value="<?php echo htmlspecialchars($precio_max); ?>" class="w-full text-skin-muted bg-skin-card p-2 rounded-lg border border-skin-border shadow-sm focus:outline-none focus:ring-2 focus:ring-skin-accent" />
            </div>
            <div class="md:col-span-4 flex justify-end gap-2 mt-2">
                <a href="productos.php" class="bg-skin-card border border-skin-border text-skin-muted px-4 py-2 rounded-lg hover:shadow-sm" title="Limpiar búsqueda">
                    Limpiar
                </a>
                
                <button type="submit" class="bg-skin-accent text-white px-6 py-2 rounded-lg hover:bg-skin-accent-hover shadow-sm" title="Buscar">
                    Buscar
                </button>

                <?php if ($esAdmin): ?>
                    <button id="add-menu-btn" type="button" class="bg-yellow-500 hover:bg-yellow-600 border text-black px-4 py-2 rounded-lg shadow-sm transform hover:shadow-md flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 3a1 1 0 00-1 1v5H4a1 1 0 100 2h5v5a1 1 0 102 0v-5h5a1 1 0 100-2h-5V4a1 1 0 00-1-1z" clip-rule="evenodd" />
                        </svg>
                        Nuevo producto o servicio
                    </button>
                <?php endif; ?>
            </div>
            <input type="hidden" name="filtro_marca" value="<?php echo htmlspecialchars($filtro_marca); ?>">
        </form>
    </div>

    <!-- Contenedor de productos -->
    <div id="productos-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php if (isset($db_error)): ?>
            <div class="col-span-full bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">¡Error!</strong>
                <span class="block sm:inline"><?php echo htmlspecialchars($db_error); ?></span>
            </div>
        <?php elseif (empty($productos) && (empty($search_query) && $precio_min === '' && $precio_max === '')): ?>
            <p class="col-span-full text-center text-skin-muted">No hay productos en la base de datos.</p>
        <?php elseif (empty($productos)): ?>
            <p class="col-span-full text-center text-skin-muted">No se encontraron productos que coincidan con tu búsqueda.</p>
        <?php else: ?>
            <?php foreach ($productos as $i => $producto) : ?>
            <div class="bg-skin-card border border-skin-border rounded-2xl shadow-lg w-full p-6 transition-colors duration-300 flex flex-col h-full" data-id="<?php echo $producto['id']; ?>">
                <div class="prod-img-wrap w-full h-56 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center mb-4 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400">Imagen no disponible</div>
                    <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="<?php echo htmlspecialchars($producto['alt']); ?>" class="object-cover w-full h-full relative z-10" onerror="this.style.display='none'">
                </div>
                <div class="flex-1 text-center">
                    <h3 class="text-lg font-bold mb-2"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                    <div class="text-sm text-skin-muted mb-2">
                        <span class="prod-marca"><?php echo htmlspecialchars($producto['marca'] ?? ''); ?></span>
                        <span class="prod-anio"><?php echo !empty($producto['anio']) ? ' - ' . htmlspecialchars($producto['anio']) : ''; ?></span>
                    </div>
                    <?php 
                    // Verificar si es servicio (por marca o categoría)
                    $es_servicio = ($producto['servicio'] == 1);
                    $stock = (int)$producto['cantidad'];
                    ?>
                    <?php if (!$es_servicio): ?>
                        <?php if ($stock <= 0): ?>
                            <p class="text-red-500 font-bold mb-2">Agotado</p>
                        <?php else: ?>
                            <p class="text-sm text-skin-muted mb-2">Disponibles: <?php echo $stock; ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php 
                    // Calcular precio con IVA (19% en Chile)
                    if ($es_servicio) {
                        // Para servicios, 'precio' es el final.
                        $precio_con_iva = round((float)($producto['precio'] ?? 0));
                    } else {
                        // Para productos, 'precio' es sin IVA.
                        $precio_sin_iva = (float)($producto['precio'] ?? 0);
                        $iva_calculado = $precio_sin_iva * 0.19;
                        $precio_con_iva = round($precio_sin_iva + $iva_calculado);
                    }
                    ?>
                    <p class="text-skin-muted font-medium mb-2 text-xl">$<?php echo number_format($precio_con_iva, 0, ',', '.'); ?></p>
                    <?php if (!$es_servicio): ?><p class="text-sm text-skin-muted">(IVA incluido: $<?php echo number_format(round($iva_calculado), 0, ',', '.'); ?>)</p><?php endif; ?>
                </div>
                <div class="mt-auto">
                    <?php if (!$es_servicio && $stock <= 0): ?>
                    <button class="w-full bg-gray-400 text-white font-bold py-2 rounded-lg shadow-md cursor-not-allowed" disabled>
                        Agotado
                    </button>
                    <?php else: ?>
                    <button class="add-to-cart w-full bg-skin-accent hover:bg-skin-accent-hover text-white font-bold py-2 rounded-lg shadow-md transition transform active:scale-95" 
                            data-id="<?php echo htmlspecialchars($producto['id']); ?>" 
                            data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>" 
                            data-precio="<?php echo htmlspecialchars($precio_con_iva); ?>"
                            data-img="<?php echo htmlspecialchars($producto['imagen']); ?>"
                            >
                        Agregar al carrito
                    </button>
                    <?php endif; ?>
                </div>
                <?php if ($esAdmin): ?>
                <div class="mt-3 flex gap-2">
                    <?php if ($producto['servicio'] == 1): // Es un servicio, botón amarillo ?>
                        <button class="edit-service-btn flex-grow px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-md text-sm" 
                                data-id="<?php echo $producto['id']; ?>">
                            Editar Servicio
                        </button>
                    <?php else: // Es un producto, botón verde ?>
                        <button class="edit-product-btn flex-grow px-3 py-1 bg-green-500 hover:bg-green-600 text-white rounded-md text-sm" 
                                data-id="<?php echo $producto['id']; ?>">
                            Editar Producto
                        </button>
                    <?php endif; ?>
                    <button class="borrar-btn px-3 py-1 bg-red-500 text-white rounded-md" data-id="<?php echo $producto['id']; ?>">Eliminar</button>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<!-- Modal para seleccionar tipo (Producto/Servicio) -->
<div id="modal-tipo" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 p-4">
    <div class="bg-skin-card p-8 rounded-lg shadow-xl w-full max-w-md">
        <div class="text-center mb-6">
            <h3 class="text-2xl font-bold  ">Nuevo producto o servicio</h3>
            <p class="text-skin-muted mt-2">N°: <span id="tipo-numero"><?php echo str_pad($proximo_id_producto, 4, '0', STR_PAD_LEFT); ?></span></p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <button id="btn-producto" class="bg-blue-500 hover:bg-blue-600 text-white p-6 rounded-lg transition transform hover:scale-[1.02] flex flex-col items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
                <span class="text-xl font-semibold">Producto</span>
            </button>
            
            <button id="btn-servicio" class="bg-green-500 hover:bg-green-600 text-white p-6 rounded-lg transition transform hover:scale-[1.02] flex flex-col items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span class="text-xl font-semibold">Servicio</span>
            </button>
        </div>
        
        <div class="text-center">
            <button id="close-tipo-modal" class="px-6 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 transition">
                Cerrar
            </button>
        </div>
    </div>
</div>

<!-- Modal para Agregar/Editar Producto -->
<div id="modal-producto" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 p-4">
    <div class="bg-skin-card p-6 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 id="modal-title" class="text-2xl font-bold  ">Producto</h3>
            <p class="text-skin-muted">N°: <span id="producto-numero"><?php echo str_pad($proximo_id_producto, 4, '0', STR_PAD_LEFT); ?></span></p>
        </div>
        
        <form id="form-producto" class="space-y-4">
            <input type="hidden" id="prod-id" name="id">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Nombre</label>
                    <input type="text" id="prod-nombre" name="nombre" class="w-full p-2 border border-skin-border rounded bg-skin-card  " required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de venta (sin IVA)</label>
                    <input type="number" id="prod-precio_v" name="precio_v" class="w-full p-2 border border-skin-border rounded bg-skin-card  " required>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de compra</label>
                    <input type="number" id="prod-precio_c" name="precio_c" class="w-full p-2 border border-skin-border rounded bg-skin-card  ">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Marca</label>
                    <input type="text" id="prod-marca" name="marca" class="w-full p-2 border border-skin-border rounded bg-skin-card  ">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Fecha</label>
                    <input type="date" id="prod-anio" name="anio" class="w-full p-2 border border-skin-border rounded bg-skin-card  ">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Categoría</label>
                    <input type="text" id="prod-categoria" name="categoria" class="w-full p-2 border border-skin-border rounded bg-skin-card  ">
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Cantidad</label>
                    <input type="number" id="prod-cantidad" name="cantidad" class="w-full p-2 border border-skin-border rounded bg-skin-card" min="0">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">N° Bodega</label>
                    <input type="number" id="prod-n_bodega" name="n_bodega" class="w-full p-2 border border-skin-border rounded bg-skin-card  ">
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-skin-muted mb-1">Imagen / URL</label>
                <input type="text" id="prod-img" name="img" class="w-full p-2 border border-skin-border rounded bg-skin-card  " placeholder="URL de la imagen">
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded p-3">
                <p class="text-sm text-blue-800">
                    <strong>Nota:</strong> El IVA (19%) se calculará automáticamente al mostrar el producto a los clientes.
                </p>
            </div>
            
            <div class="flex justify-between gap-2 pt-4 border-t border-skin-border">
                <button type="button" id="limpia-producto" class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">
                    Limpiar
                </button>
                <div class="flex gap-2">
                    <button type="button" id="cancel-producto" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">
                        Cerrar
                    </button>
                    <button type="submit" class="px-4 py-2 bg-skin-accent text-white rounded hover:bg-skin-accent-hover">
                        Guardar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal para Agregar Servicio -->
<div id="modal-servicio" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 p-4">
    <div class="bg-skin-card p-6 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 id="modal-title-servicio" class="text-2xl font-bold  ">Servicio</h3>
            <p class="text-skin-muted">N°: <span id="servicio-numero"><?php echo str_pad($proximo_id_servicio, 4, '0', STR_PAD_LEFT); ?></span></p>
        </div>
        
        <form id="form-servicio" class="space-y-4">
            <input type="hidden" id="serv-id" name="id">
            <input type="hidden" id="serv-precio_total" name="precio_total" value="0">
            
            <div>
                <label class="block text-sm font-medium text-skin-muted mb-1">Nombre del Servicio *</label>
                <input type="text" id="serv-nombre" name="nombre" class="w-full p-2 border border-skin-border rounded bg-skin-card  " required placeholder="Ej: Cambio de aceite y filtro">
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de mano de obra *</label>
                    <input type="number" id="serv-precio_mdo" name="precio_mdo" class="w-full p-2 border border-skin-border rounded bg-skin-card  " required min="0" value="0">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de refacciones/piezas</label>
                    <input type="number" id="serv-precio_refacciones" name="precio_refacciones" class="w-full p-2 border border-skin-border rounded bg-skin-card  " min="0" value="0" readonly>
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Precio de refacciones externas</label>
                    <input type="number" id="serv-precio_ref_externas" name="precio_ref_externas" class="w-full p-2 border border-skin-border rounded bg-skin-card  " min="0" value="0">
                </div>
            </div>
            
            <!-- Resumen de precios -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 bg-skin-card2 border border-skin-border rounded p-4">
                <div>
                    <p class="text-sm text-skin-muted">Subtotal</p>
                    <p class="text-lg font-semibold  ">$<span id="serv-subtotal">0</span></p>
                </div>
                <div>
                    <p class="text-sm text-skin-muted">IVA (19%)</p>
                    <p class="text-lg font-semibold  ">$<span id="serv-iva">0</span></p>
                </div>
                <div>
                    <p class="text-sm text-skin-muted">Total a pagar</p>
                    <p class="text-xl font-bold text-green-600">$<span id="serv-total">0</span></p>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Imagen / URL</label>
                    <input type="text" id="serv-img" name="img" class="w-full p-2 border border-skin-border rounded bg-skin-card  " placeholder="URL de la imagen (opcional)">
                </div>
                <div>
                    <label class="block text-sm font-medium text-skin-muted mb-1">Mecánico encargado</label>
                    <input type="text" id="serv-mecanico" name="mecanico" class="w-full p-2 border border-skin-border rounded bg-skin-card  " placeholder="Nombre del mecánico">
                </div>
            </div>
            
            <!-- Sección para listado de piezas -->
            <div class="border border-skin-border rounded p-4 mt-4">
                <h4 class="font-semibold   mb-2">Refacciones/Piezas utilizadas</h4>
                <p class="text-sm text-skin-muted mb-4">
                    Selecciona los productos (refacciones) que se utilizarán en este servicio. 
                    Los precios se sumarán automáticamente al costo total.
                </p>
                
                <!-- Selector de productos -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-skin-muted mb-2">Seleccionar producto:</label>
                    <div class="flex gap-2">
                        <select id="select-producto" class="flex-1 p-2 border border-skin-border rounded bg-skin-card  ">
                            <option value="">-- Selecciona un producto --</option>
                            <?php foreach ($productos_para_servicios as $prod): ?>
                            <option value="<?php echo $prod['id']; ?>" data-precio="<?php echo $prod['precio_v']; ?>">
                                <?php echo htmlspecialchars($prod['nombre']); ?> - $<?php echo number_format($prod['precio_v'], 0, ',', '.'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" id="agregar-pieza-btn" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            Agregar
                        </button>
                    </div>
                </div>
                
                <!-- Lista de productos agregados -->
                <div class="border border-skin-border rounded p-3">
                    <h5 class="font-medium   mb-3">Productos seleccionados:</h5>
                    <div id="lista-piezas" class="space-y-2 max-h-60 overflow-y-auto">
                        <!-- Aquí se agregarán dinámicamente los productos -->
                        <p class="text-sm text-skin-muted text-center py-4">No hay productos agregados</p>
                    </div>
                    <div class="mt-3 pt-3 border-t border-skin-border">
                        <div class="flex justify-between items-center">
                            <span class="text-sm font-medium text-skin-muted">Total de refacciones:</span>
                            <span class="font-semibold  ">$<span id="total-refacciones">0</span></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="flex justify-between gap-2 pt-4 border-t border-skin-border">
                <button type="button" id="limpia-servicio" class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">
                    Limpiar
                </button>
                <div class="flex gap-2">
                    <button type="button" id="cancel-servicio" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">
                        Cerrar
                    </button>
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        Guardar Servicio
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal para seleccionar productos -->
<div id="modal-seleccion-productos" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 p-4">
    <div class="bg-skin-card p-6 rounded-lg shadow-xl w-full max-w-4xl max-h-[80vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold  ">Seleccionar Productos para el Servicio</h3>
            <button type="button" id="close-modal-productos" class="px-3 py-1 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">
                Cerrar
            </button>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php foreach ($productos_para_servicios as $prod): ?>
            <div class="border border-skin-border rounded p-4 hover:bg-skin-card2 transition-colors">
                <div class="flex justify-between items-start mb-2">
                    <h4 class="font-medium  "><?php echo htmlspecialchars($prod['nombre']); ?></h4>
                    <span class="text-sm font-semibold text-green-600">$<?php echo number_format($prod['precio_v'], 0, ',', '.'); ?></span>
                </div>
                <p class="text-sm text-skin-muted mb-3"><?php echo htmlspecialchars($prod['marca']); ?></p>
                <button type="button" class="w-full px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm agregar-producto-servicio"
                        data-id="<?php echo $prod['id']; ?>"
                        data-nombre="<?php echo htmlspecialchars($prod['nombre']); ?>"
                        data-precio="<?php echo $prod['precio_v']; ?>"
                        data-marca="<?php echo htmlspecialchars($prod['marca']); ?>">
                    Agregar al servicio
                </button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Definir showNotification si no existe (para asegurar que las notificaciones funcionen)
    if (typeof showNotification === 'undefined') {
        window.showNotification = function(message, type = 'success') {
            const toast = document.createElement('div');
            toast.className = `toast-notification toast-${type} show`;
            toast.innerHTML = `<span class="toast-icon">${type === 'success' ? '✓' : '✕'}</span><span>${message}</span>`;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 400);
            }, 3000);
        };
    }

    // Agregar al carrito
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function() {
            const producto = {
                id: this.dataset.id,
                nombre: this.dataset.nombre,
                precio: parseFloat(this.dataset.precio),
                img: this.dataset.img
            };
            
            // Agregar al carrito usando la función global
            if (typeof agregarAlCarrito === 'function') {
                agregarAlCarrito(producto);
            } else {
                console.error('La función del carrito no está disponible. Asegúrate de que cart.js esté cargado.');
            }
        });
    });
    
    // Prevenir envío del formulario con Enter en campos no submit
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                // Simplemente prevenimos el envío, el botón de búsqueda explícito se encargará.
            }
        });
    }

    // --- Lógica para Modales de Admin ---
    const esAdmin = <?php echo json_encode($esAdmin); ?>;
    if (esAdmin) {
        const modalTipo = document.getElementById('modal-tipo');
        const modalProducto = document.getElementById('modal-producto');
        const modalServicio = document.getElementById('modal-servicio');
        
        const addMenuBtn = document.getElementById('add-menu-btn');
        const proximoIdProducto = <?php echo $proximo_id_producto; ?>;
        const proximoIdServicio = <?php echo $proximo_id_servicio; ?>;

        function openModal(modal) {
            if (modal) {
                modal.classList.remove('hidden');
                modal.style.display = 'flex';
            }
        }

        function closeModal(modal) {
            if (modal) {
                modal.classList.add('hidden');
                modal.style.display = 'none';
            }
        }

        // Abrir modal de selección de tipo
        addMenuBtn?.addEventListener('click', () => openModal(modalTipo));

        // Cerrar modales con botones y clic exterior
        document.getElementById('close-tipo-modal')?.addEventListener('click', () => closeModal(modalTipo));
        modalTipo?.addEventListener('click', e => { if (e.target === modalTipo) closeModal(modalTipo); });

        document.getElementById('cancel-producto')?.addEventListener('click', () => closeModal(modalProducto));
        modalProducto?.addEventListener('click', e => { if (e.target === modalProducto) closeModal(modalProducto); });

        document.getElementById('cancel-servicio')?.addEventListener('click', () => closeModal(modalServicio));
        modalServicio?.addEventListener('click', e => { if (e.target === modalServicio) closeModal(modalServicio); });

        // Cerrar con tecla ESC
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                closeModal(modalTipo);
                closeModal(modalProducto);
                closeModal(modalServicio);
            }
        });

        // Navegación desde el modal de tipo a los formularios
        document.getElementById('btn-producto')?.addEventListener('click', () => {
            closeModal(modalTipo);
            const form = document.getElementById('form-producto');
            if (form) {
                form.reset();
                document.getElementById('prod-id').value = '';
                document.getElementById('modal-title').textContent = 'Agregar Producto';
                document.getElementById('producto-numero').textContent = proximoIdProducto.toString().padStart(4, '0');
            }
            openModal(modalProducto);
        });

        // --- Lógica para el modal de Servicio ---
        let piezasSeleccionadas = [];
        const listaPiezasContainer = document.getElementById('lista-piezas');
        const selectProducto = document.getElementById('select-producto');
        const agregarPiezaBtn = document.getElementById('agregar-pieza-btn');

        const precioMdoInput = document.getElementById('serv-precio_mdo');
        const precioExternasInput = document.getElementById('serv-precio_ref_externas');
        const precioRefaccionesInput = document.getElementById('serv-precio_refacciones');

        const subtotalSpan = document.getElementById('serv-subtotal');
        const ivaSpan = document.getElementById('serv-iva');
        const totalSpan = document.getElementById('serv-total');
        const totalRefaccionesSpan = document.getElementById('total-refacciones');
        const precioTotalHiddenInput = document.getElementById('serv-precio_total');

        function updateServicioTotal() {
            const manoDeObra = parseFloat(precioMdoInput?.value) || 0;
            const refaccionesExternas = parseFloat(precioExternasInput?.value) || 0;
            
            const totalRefacciones = piezasSeleccionadas.reduce((sum, pieza) => sum + (parseFloat(pieza.precio) * (parseInt(pieza.cantidad, 10) || 1)), 0);
            if(precioRefaccionesInput) precioRefaccionesInput.value = totalRefacciones;
            if(totalRefaccionesSpan) totalRefaccionesSpan.textContent = totalRefacciones.toLocaleString('es-CL');

            const subtotal = manoDeObra + totalRefacciones + refaccionesExternas; 
            const iva = subtotal * 0.19;
            const total = subtotal + iva;

            if(subtotalSpan) subtotalSpan.textContent = Math.round(subtotal).toLocaleString('es-CL');
            if(ivaSpan) ivaSpan.textContent = Math.round(iva).toLocaleString('es-CL');
            if(totalSpan) totalSpan.textContent = Math.round(total).toLocaleString('es-CL');
            if(precioTotalHiddenInput) precioTotalHiddenInput.value = Math.round(total);
        }

        function renderPiezasSeleccionadas() {
            if (!listaPiezasContainer) return;
            listaPiezasContainer.innerHTML = '';
            if (piezasSeleccionadas.length === 0) {
                listaPiezasContainer.innerHTML = '<p class="text-sm text-skin-muted text-center py-4">No hay productos agregados</p>';
            } else {
                piezasSeleccionadas.forEach((pieza, index) => {
                    const piezaEl = document.createElement('div');
                    piezaEl.className = 'flex justify-between items-center p-2 bg-skin-base rounded gap-4';
                    piezaEl.innerHTML = `
                        <div class="flex-grow">
                            <p class="font-medium text-sm">${pieza.nombre}</p>
                            <p class="text-xs text-skin-muted">$${parseFloat(pieza.precio).toLocaleString('es-CL')} c/u</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="number" value="${pieza.cantidad}" min="1" class="w-16 text-center p-1 border border-skin-border rounded bg-skin-card pieza-cantidad-input" data-index="${index}">
                            <button type="button" class="text-red-500 hover:text-red-700 remove-pieza-btn text-2xl leading-none" data-index="${index}">&times;</button>
                        </div>
                    `;
                    listaPiezasContainer.appendChild(piezaEl);
                });
            }
            
            document.querySelectorAll('.remove-pieza-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.dataset.index, 10);
                    piezasSeleccionadas.splice(index, 1);
                    renderPiezasSeleccionadas();
                    updateServicioTotal();
                });
            });

            document.querySelectorAll('.pieza-cantidad-input').forEach(input => {
                input.addEventListener('change', function() {
                    const index = parseInt(this.dataset.index, 10);
                    const newCantidad = parseInt(this.value, 10);
                    if (newCantidad > 0) piezasSeleccionadas[index].cantidad = newCantidad;
                    updateServicioTotal();
                });
            });
        }

        agregarPiezaBtn?.addEventListener('click', () => {
            const selectedOption = selectProducto.options[selectProducto.selectedIndex];
            if (!selectedOption || !selectedOption.value) {
                showNotification('Por favor, selecciona un producto.', 'warning');
                return;
            }
            const piezaId = selectedOption.value;
            const existingPieza = piezasSeleccionadas.find(p => p.id === piezaId);

            if (existingPieza) {
                existingPieza.cantidad++;
            } else {
                const pieza = {
                    id: piezaId,
                    nombre: selectedOption.text.split(' - ')[0],
                    precio: parseFloat(selectedOption.dataset.precio),
                    cantidad: 1
                };
                piezasSeleccionadas.push(pieza);
            }
            renderPiezasSeleccionadas();
            updateServicioTotal();
        });

        precioMdoInput?.addEventListener('input', updateServicioTotal);
        precioExternasInput?.addEventListener('input', updateServicioTotal);

        document.getElementById('btn-servicio')?.addEventListener('click', () => { // Abrir modal de servicio
            closeModal(modalTipo);
            const form = document.getElementById('form-servicio');
            if (form) {
                form.reset();
                document.getElementById('serv-id').value = '';
                document.getElementById('modal-title-servicio').textContent = 'Agregar Servicio';
                document.getElementById('servicio-numero').textContent = proximoIdServicio.toString().padStart(4, '0');
                piezasSeleccionadas = [];
                renderPiezasSeleccionadas();
                updateServicioTotal();
            }
            openModal(modalServicio);
        });

        // Lógica para botones de limpiar
        document.getElementById('limpia-producto')?.addEventListener('click', () => document.getElementById('form-producto')?.reset());

        document.getElementById('limpia-servicio')?.addEventListener('click', () => {
            document.getElementById('form-servicio')?.reset();
            piezasSeleccionadas = [];
            renderPiezasSeleccionadas();
            updateServicioTotal();
        });

        // --- Lógica para guardar ---

        // Guardar Producto
        document.getElementById('form-producto')?.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            fetch('../controllers/save_producto.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            }).then(res => res.json()).then(response => {
                if (response.success) {
                    showNotification('Producto guardado correctamente.', 'success');
                    location.reload();
                } else {
                    showNotification('Error al guardar: ' + (response.error || 'Error desconocido'), 'error');
                }
            }).catch(err => showNotification('Error de conexión.', 'error'));
        });

        // Guardar Servicio
        document.getElementById('form-servicio')?.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            data.piezas = piezasSeleccionadas;
            fetch('../controllers/save_servicio.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            }).then(res => res.json()).then(response => {
                if (response.success) {
                    showNotification('Servicio guardado correctamente.', 'success');
                    location.reload();
                } else {
                    showNotification('Error al guardar: ' + (response.error || 'Error desconocido'), 'error');
                }
            }).catch(err => showNotification('Error de conexión.', 'error'));
        });

        // --- Lógica para borrar ---
        document.querySelectorAll('.borrar-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                const card = this.closest('div[data-id]');
                const nombre = card.querySelector('h3').textContent;

                if (confirm(`¿Estás seguro de que quieres eliminar "${nombre}"? Esta acción no se puede deshacer.`)) {
                    fetch('../controllers/eliminar_producto.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: id })
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            showNotification('Elemento eliminado correctamente.', 'success');
                            card.style.transition = 'opacity 0.5s ease';
                            card.style.opacity = '0';
                            setTimeout(() => card.remove(), 500);
                        } else {
                            if (response.error === 'in_use') {
                                showNotification('No se puede eliminar: ' + response.details, 'error');
                            } else {
                                showNotification('Error al eliminar: ' + (response.error || 'Error desconocido.'), 'error');
                            }
                        }
                    })
                    .catch(err => showNotification('Error de conexión al intentar eliminar.', 'error'));
                }
            });
        });

        // --- Lógica para Editar ---

        /**
         * Abre el modal para editar un PRODUCTO y precarga sus datos.
         * @param {object} data - El objeto `dataset` del botón de editar.
         */
        async function openProductEditModal(data) {
            const productId = data.id;
            if (!productId) {
                showNotification('Error: ID de producto no válido.', 'error');
                return;
            }

            const modal = document.getElementById('modal-producto');
            const form = document.getElementById('form-producto');
            if (!modal || !form) {
                showNotification('Error: El formulario de producto no se encuentra.', 'error');
                return;
            }
            
            try {
                // Obtener detalles del producto desde el servidor
                const response = await fetch(`../controllers/get_producto_details.php?id=${productId}`);
                if (!response.ok) {
                    throw new Error(`Error HTTP: ${response.status} (Verifica que get_producto_details.php exista)`);
                }
                const result = await response.json();

                if (!result.success) {
                    showNotification(result.error || 'Error al cargar detalles del producto', 'error');
                    return;
                }

                const product = result.product;

                // Limpiar y configurar el modal
                form.reset();
                document.getElementById('modal-title').textContent = 'Editar Producto';
                document.getElementById('producto-numero').textContent = (product.id || '').toString().padStart(4, '0');

                // Poblar el formulario con los datos del producto
                document.getElementById('prod-id').value = product.id || '';
                document.getElementById('prod-nombre').value = product.nombre || '';
                document.getElementById('prod-precio_v').value = product.precio_v || 0;
                document.getElementById('prod-precio_c').value = product.precio_c || 0;
                document.getElementById('prod-marca').value = product.marca || '';
                document.getElementById('prod-anio').value = product.anio || ''; // anio viene en formato YYYY-MM-DD
                document.getElementById('prod-categoria').value = product.categoria || '';
                document.getElementById('prod-cantidad').value = product.cantidad || 0;
                document.getElementById('prod-n_bodega').value = product.n_bodega || 0;
                document.getElementById('prod-img').value = product.img || '';

                // Abrir el modal
                openModal(modal);

            } catch (e) {
                console.error(e);
                showNotification('Error de conexión al cargar producto', 'error');
            }
        }

        /**
         * Abre el modal para editar un SERVICIO, obtiene sus detalles del servidor y precarga los datos.
         * @param {object} data - El objeto `dataset` del botón de editar.
         */
        async function openServiceEditModal(data) {
            const serviceId = data.id;
            if (!serviceId) {
                showNotification('Error: ID de servicio no válido.', 'error');
                return;
            }

            // 1. Obtener el modal y el formulario que se usan para CREAR servicios.
            const modal = document.getElementById('modal-servicio');
            const form = document.getElementById('form-servicio');
            if (!modal || !form) {
                showNotification('Error: El formulario de servicio no se encuentra.', 'error');
                return;
            }

            try {
                // 2. Buscar los datos completos del servicio en el servidor.
                const response = await fetch(`../controllers/get_servicio_details.php?id=${serviceId}`);
                
                if (!response.ok) {
                    throw new Error(`Error HTTP: ${response.status} (Verifica que get_servicio_details.php exista)`);
                }

                const result = await response.json();

                if (!result.success) {
                    showNotification(result.error || 'Error al cargar detalles del servicio', 'error');
                    return;
                }

                const service = result.service;
                const parts = result.parts;

                // 3. Preparar el formulario para la edición.
                form.reset(); // Limpiar cualquier dato anterior.
                document.getElementById('modal-title-servicio').textContent = 'Editar Servicio';
                document.getElementById('servicio-numero').textContent = service.id.toString().padStart(4, '0');

                // 4. Llenar todos los campos del formulario con los datos obtenidos.
                document.getElementById('serv-id').value = service.id;
                
                // Quitar el sufijo " (Servicio)" para una mejor edición.
                let nombre = service.nombre;
                if (nombre.endsWith(' (Servicio)')) {
                    nombre = nombre.substring(0, nombre.length - 11);
                }
                document.getElementById('serv-nombre').value = nombre;
                
                document.getElementById('serv-precio_mdo').value = service.precio_mdo || 0;
                document.getElementById('serv-mecanico').value = service.mecanico || '';
                document.getElementById('serv-img').value = service.img || '';

                // Llenar la lista de piezas asociadas.
                piezasSeleccionadas = parts.map(p => ({
                    id: p.id,
                    nombre: p.nombre,
                    precio: parseFloat(p.precio),
                    cantidad: parseInt(p.cantidad)
                }));
                renderPiezasSeleccionadas();

                // Calcular el precio de "refacciones externas" (ya que no se guarda directamente).
                const totalConIva = parseFloat(service.precio_v) || 0;
                const subtotal = Math.round(totalConIva / 1.19);
                const mdo = parseFloat(service.precio_mdo) || 0;
                const partsTotal = parts.reduce((sum, p) => sum + (parseFloat(p.precio) * parseInt(p.cantidad)), 0);
                
                let externas = subtotal - mdo - partsTotal;
                if (externas < 0) externas = 0;
                
                document.getElementById('serv-precio_ref_externas').value = Math.round(externas);

                // 5. Actualizar los totales y abrir el modal.
                updateServicioTotal();
                openModal(modal);

            } catch (e) {
                console.error(e);
                showNotification('Error de conexión al cargar servicio', 'error');
            }
        }

        // Event listener principal que decide qué función de edición llamar
        document.querySelectorAll('.edit-product-btn, .edit-service-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const data = this.dataset;

                // Verificamos la clase del botón para decidir qué modal abrir
                if (this.classList.contains('edit-service-btn')) {
                    // Si es un servicio, llama a la función de edición de servicios.
                    openServiceEditModal(data);
                } else {
                    // Si no, es un producto, y llama a la función de edición de productos.
                    openProductEditModal(data);
                }
            });
        });
    }
});
</script>

<?php include 'partials/footer.php' ?>