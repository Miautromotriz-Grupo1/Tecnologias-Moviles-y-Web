<?php
include '../models/conexion.php';
session_start();

header('Content-Type: application/json');

// Verificar permisos de administrador
if (!isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

// Asegurarse de que la tabla 'servicio_manodeobra' exista para evitar errores en el JOIN.
// Esto es especialmente útil si se editan servicios antiguos creados antes de que existiera esta tabla.
$create_mdo_table = "
    CREATE TABLE IF NOT EXISTS servicio_manodeobra (
        id INTEGER PRIMARY KEY REFERENCES piezas(id) ON DELETE CASCADE,
        nombre_mdo TEXT,
        precio_mdo INTEGER,
        img_mdo TEXT,
        mecanico TEXT
    );
";
@pg_query($conexion, $create_mdo_table);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
    exit;
}

try {
    // 1. Obtener datos principales del servicio (tabla piezas + manodeobra)
    $query_service = "
        SELECT p.id, p.nombre, p.precio_v, p.img, 
               m.precio_mdo, m.mecanico
        FROM piezas p
        LEFT JOIN servicio_manodeobra m ON p.id = m.id
        WHERE p.id = $1 AND p.servicio = 1
    ";
    
    $res_service = pg_query_params($conexion, $query_service, [$id]);
    
    if (!$res_service) {
        throw new Exception("Error en la consulta de servicio: " . pg_last_error($conexion));
    }
    
    $service = pg_fetch_assoc($res_service);
    
    if (!$service) {
        throw new Exception("Servicio no encontrado");
    }
    
    // 2. Obtener piezas/refacciones asociadas
    $query_parts = "
        SELECT sp.pieza_id as id, p.nombre, p.precio_v as precio, sp.cantidad
        FROM servicio_piezas sp
        JOIN piezas p ON sp.pieza_id = p.id
        WHERE sp.servicio_id = $1
    ";
    
    $res_parts = pg_query_params($conexion, $query_parts, [$id]);
    
    if (!$res_parts) {
        throw new Exception("Error en la consulta de piezas: " . pg_last_error($conexion));
    }
    
    $parts = [];
    while ($row = pg_fetch_assoc($res_parts)) {
        $parts[] = [
            'id' => $row['id'],
            'nombre' => $row['nombre'],
            'precio' => $row['precio'],
            'cantidad' => $row['cantidad']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'service' => $service,
        'parts' => $parts
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>