<?php
include '../models/conexion.php';
session_start();

ini_set('display_errors', 0); // Evitar que warnings de PHP rompan el formato JSON
header('Content-Type: application/json');

// Verificar sesión
if (!isset($_SESSION['empleado']) || ($_SESSION['empleado'] != 2 && $_SESSION['empleado'] != 1)) {
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado']);
    exit;
}

// --- INICIALIZACIÓN DE TABLAS (SOLO SI NO EXISTEN) ---
if ($conexion) {
    // Tabla Presupuesto (Según tu esquema + vin_vehiculo para relacionar + notas/obs)
    $sql_presupuesto = "CREATE TABLE IF NOT EXISTS presupuesto(
        id SERIAL NOT NULL,
        nombre_cli text,
        total double precision DEFAULT 0,
        iva double precision DEFAULT 0,
        subtotal double precision DEFAULT 0,
        fecha date,
        creado_por_rut varchar(20),
        borrado_por_rut varchar(20) DEFAULT NULL::character varying,
        borrado_en timestamp without time zone,
        estado boolean DEFAULT true,
        creado timestamp without time zone DEFAULT now(),
        apellido_cli text,
        rut_cli varchar(20),
        telefono1_cli text,
        telefono2_cli text,
        direccion_cli text,
        observaciones text,
        notas text,
        vin_vehiculo text,
        correo_cli text,
        PRIMARY KEY(id)
    );";
    // modificado timestamp without time zone DEFAULT now(),
    pg_query($conexion, $sql_presupuesto);

    // Tabla Vehículo (Según tu esquema)
    $sql_vehiculo = "CREATE TABLE IF NOT EXISTS vehiculo(
        id_car text NOT NULL,
        marca_car text,
        anio_car date,
        vin_vehiculo text NOT NULL,
        color_car text,
        tipodevehiculo text,
        matricula varchar(8),
        personaid varchar NOT NULL,
        kilometraje integer,
        n_chasis text,
        modelo_car text,
        PRIMARY KEY(id_car),
        CONSTRAINT vehiculo_personaid_fkey FOREIGN key(personaid) REFERENCES persona(rut)
    );";
    // Nota: Se envuelve en try/catch implícito al ejecutar, si falla por la FK es porque persona no existe
    @pg_query($conexion, $sql_vehiculo);

    // Tabla Detalle de Presupuesto (Para guardar los items)
    $sql_detalle = "CREATE TABLE IF NOT EXISTS presupuesto_detalle (
        id SERIAL PRIMARY KEY,
        presupuesto_id INTEGER REFERENCES presupuesto(id) ON DELETE CASCADE,
        descripcion TEXT,
        cantidad NUMERIC,
        unidad TEXT,
        valor NUMERIC,
        total NUMERIC
    );";
    pg_query($conexion, $sql_detalle);

    // Asegurar que existan las columnas nuevas por si la tabla ya fue creada anteriormente
    $cols_check = [
        ['table' => 'presupuesto', 'col' => 'vin_vehiculo', 'type' => 'text'],
        ['table' => 'presupuesto', 'col' => 'notas', 'type' => 'text'],
        ['table' => 'presupuesto', 'col' => 'observaciones', 'type' => 'text'],
        ['table' => 'presupuesto', 'col' => 'correo_cli', 'type' => 'text'],
        ['table' => 'vehiculo', 'col' => 'modelo_car', 'type' => 'text'],
        ['table' => 'vehiculo', 'col' => 'vin_vehiculo', 'type' => 'text'],
        ['table' => 'vehiculo', 'col' => 'n_chasis', 'type' => 'text'],
        ['table' => 'vehiculo', 'col' => 'color_car', 'type' => 'text']
    ];

    foreach ($cols_check as $check) {
        $res = pg_query_params($conexion, 
            "SELECT column_name FROM information_schema.columns WHERE table_name=$1 AND column_name=$2", 
            [$check['table'], $check['col']]
        );
        if ($res && pg_num_rows($res) == 0) {
            @pg_query($conexion, "ALTER TABLE {$check['table']} ADD COLUMN {$check['col']} {$check['type']}");
        }
    }
}

$method = $_SERVER['REQUEST_METHOD'];

// --- MANEJO DE PETICIONES ---

if ($method === 'POST') {
    // GUARDAR O ACTUALIZAR PRESUPUESTO
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data) {
        echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
        exit;
    }

    pg_query($conexion, "BEGIN"); // Iniciar transacción

    try {
        // 1. Preparar datos del Presupuesto
        $nombre_cli = $data['nombre'] ?? '';
        $apellido_cli = $data['apellido'] ?? '';
        $rut_cli = $data['rut'] ?? '';
        $correo_cli = $data['correo'] ?? null;
        $telefono1 = $data['contacto1'] ?? null;
        $telefono2 = $data['contacto2'] ?? null;
        $direccion = $data['direccion'] ?? '';
        $fecha = $data['fecha'] ?? date('Y-m-d');
        $total = $data['total'] ?? 0;
        $iva = $data['iva'] ?? 0;
        $subtotal = $data['subtotal'] ?? 0;
        $observaciones = $data['observaciones'] ?? '';
        $notas = $data['notas'] ?? '';
        $creado_por = $_SESSION['rut'];
        $vin_vehiculo = $data['vin'] ?? null;
        
        // Unificar nombre completo
        $nombre_completo = trim($nombre_cli . ' ' . $apellido_cli);

        // 2. Insertar o Actualizar Presupuesto
        if (isset($data['id']) && !empty($data['id'])) {
            // Actualizar
            $query_presupuesto = "UPDATE presupuesto SET 
                nombre_cli = $1, apellido_cli = $2, rut_cli = $3, telefono1_cli = $4, telefono2_cli = $5, 
                direccion_cli = $6, fecha = $7, total = $8, iva = $9, subtotal = $10, 
                observaciones = $11, notas = $12, vin_vehiculo = $13, correo_cli = $14
                WHERE id = $15";
            $params_presupuesto = [
                $nombre_completo, $apellido_cli, $rut_cli, $telefono1, $telefono2, 
                $direccion, $fecha, $total, $iva, $subtotal, 
                $observaciones, $notas, $vin_vehiculo, $correo_cli, $data['id']
            ];
            $res_presupuesto = pg_query_params($conexion, $query_presupuesto, $params_presupuesto);
            if (!$res_presupuesto) {
                throw new Exception("Error al actualizar presupuesto: " . pg_last_error($conexion));
            }
            $presupuesto_id = $data['id'];
            
            // Borrar items antiguos
            $res_del = pg_query_params($conexion, "DELETE FROM presupuesto_detalle WHERE presupuesto_id = $1", [$presupuesto_id]);
            if (!$res_del) {
                throw new Exception("Error al limpiar items antiguos: " . pg_last_error($conexion));
            }
        } else {
            // Insertar
            $query_presupuesto = "INSERT INTO presupuesto (nombre_cli, apellido_cli, rut_cli, telefono1_cli, telefono2_cli, direccion_cli, fecha, total, iva, subtotal, observaciones, notas, vin_vehiculo, creado_por_rut, correo_cli) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING id";
            $params_presupuesto = [
                $nombre_completo, $apellido_cli, $rut_cli, $telefono1, $telefono2, 
                $direccion, $fecha, $total, $iva, $subtotal, 
                $observaciones, $notas, $vin_vehiculo, $creado_por, $correo_cli
            ];
            $res_presupuesto = pg_query_params($conexion, $query_presupuesto, $params_presupuesto);
            if (!$res_presupuesto) {
                throw new Exception("Error al insertar presupuesto: " . pg_last_error($conexion));
            }
            $row = pg_fetch_assoc($res_presupuesto);
            if (!$row) {
                throw new Exception("Error al obtener el ID del nuevo presupuesto.");
            }
            $presupuesto_id = $row['id'] ?? null;
        }
        
        // 3. Guardar Items
        if (isset($data['items']) && is_array($data['items'])) {
            $query_item = "INSERT INTO presupuesto_detalle (presupuesto_id, descripcion, cantidad, unidad, valor, total) VALUES ($1, $2, $3, $4, $5, $6)";
            foreach ($data['items'] as $item) {
                $res_item = pg_query_params($conexion, $query_item, [
                    $presupuesto_id,
                    $item['descripcion'],
                    $item['cantidad'],
                    $item['unidad'] ?? 'unidad',
                    $item['valor'],
                    $item['total']
                ]);
                if (!$res_item) {
                    throw new Exception("Error al guardar un item del presupuesto: " . pg_last_error($conexion));
                }
            }
        }

        // 4. Guardar Vehículo (Si hay datos de VIN)
        // Solo si hay VIN y un RUT de cliente válido
        if (!empty($vin_vehiculo) && !empty($rut_cli)) {
            // Verificar si el cliente (persona) existe antes de intentar insertar/actualizar el vehículo
            $check_persona = pg_query_params($conexion, "SELECT rut FROM persona WHERE rut = $1", [$rut_cli]);
            
            if ($check_persona && pg_num_rows($check_persona) > 0) {
                $id_car = $vin_vehiculo;
                $marca = $data['marca'] ?? '';
                $modelo = $data['modelo'] ?? ''; 
                $anio_num = (int)($data['anio'] ?? date('Y'));
                $anio_date = "$anio_num-01-01";
                $color = $data['color'] ?? '';
                $tipo = $data['tipo'] ?? '';
                $matricula = substr($data['matricula'] ?? '', 0, 8);
                $kilometraje = (int)($data['kilometraje'] ?? 0);
                $chasis = $data['chasis'] ?? '';
                $personaid = $rut_cli; // Usar el RUT del cliente

                $check_car = pg_query_params($conexion, "SELECT id_car FROM vehiculo WHERE id_car = $1", [$id_car]);
                if (!$check_car) {
                    throw new Exception("Error al verificar vehículo: " . pg_last_error($conexion));
                }
                
                if (pg_num_rows($check_car) > 0) {
                    // Update
                    $query_veh = "UPDATE vehiculo SET marca_car=$1, anio_car=$2, color_car=$3, tipodevehiculo=$4, matricula=$5, kilometraje=$6, n_chasis=$7, personaid=$8, modelo_car=$9, vin_vehiculo=$10 WHERE id_car=$10";
                    $res_veh = pg_query_params($conexion, $query_veh, [$marca, $anio_date, $color, $tipo, $matricula, $kilometraje, $chasis, $personaid, $modelo, $id_car]);
                } else {
                    // Insert
                    $query_veh = "INSERT INTO vehiculo (id_car, marca_car, anio_car, vin_vehiculo, color_car, tipodevehiculo, matricula, kilometraje, n_chasis, personaid, modelo_car) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)";
                    $res_veh = pg_query_params($conexion, $query_veh, [$id_car, $marca, $anio_date, $id_car, $color, $tipo, $matricula, $kilometraje, $chasis, $personaid, $modelo]);
                }
                if (!$res_veh) {
                    throw new Exception("Error al guardar vehículo: " . pg_last_error($conexion));
                }
            }
        }

        pg_query($conexion, "COMMIT");
        echo json_encode(['success' => true, 'id' => $presupuesto_id]);

    } catch (Exception $e) {
        pg_query($conexion, "ROLLBACK");
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }

} elseif ($method === 'GET') {
    // LISTAR O VER UN PRESUPUESTO
    
    if (isset($_GET['id'])) {
        // Ver uno específico
        $id = $_GET['id'];
        $es_admin = isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2;
        $rut_empleado = $_SESSION['rut'] ?? null;

        $query = "SELECT p.*, 
                         v.marca_car, v.anio_car, v.color_car, v.tipodevehiculo, v.matricula, v.kilometraje, v.n_chasis, v.vin_vehiculo, v.modelo_car
                  FROM presupuesto p 
                  LEFT JOIN vehiculo v ON p.vin_vehiculo = v.id_car
                  WHERE p.id = $1 AND p.estado = true";
        
        $params = [$id];

        // Si no es admin, solo puede ver sus propios presupuestos
        if (!$es_admin) {
            $query .= " AND p.creado_por_rut = $2";
            $params[] = $rut_empleado;
        }
        
        $res = pg_query_params($conexion, $query, $params);
        
        if ($row = pg_fetch_assoc($res)) {
            // Obtener items
            $res_items = pg_query_params($conexion, "SELECT * FROM presupuesto_detalle WHERE presupuesto_id = $1", [$id]);
            $items = pg_fetch_all($res_items) ?: [];
            
            // Formatear respuesta
            $presupuesto = [
                'id' => $row['id'],
                'numero' => str_pad($row['id'], 4, '0', STR_PAD_LEFT),
                'nombre' => $row['nombre_cli'],
                'apellido' => $row['apellido_cli'],
                'cliente' => $row['nombre_cli'] . ' ' . $row['apellido_cli'],
                'rut' => $row['rut_cli'],
                'correo' => $row['correo_cli'],
                'direccion' => $row['direccion_cli'],
                'fecha' => $row['fecha'],
                'contacto1' => $row['telefono1_cli'],
                'contacto2' => $row['telefono2_cli'],
                'observaciones' => $row['observaciones'],
                'notas' => $row['notas'],
                'total' => $row['total'],
                'subtotal' => $row['subtotal'],
                'iva' => $row['iva'],
                // Datos vehículo
                'marca' => $row['marca_car'],
                'modelo' => $row['modelo_car'],
                'anio' => $row['anio_car'] ? date('Y', strtotime($row['anio_car'])) : '',
                'tipo' => $row['tipodevehiculo'],
                'matricula' => $row['matricula'],
                'kilometraje' => $row['kilometraje'],
                'vin' => $row['vin_vehiculo'] ?? '',
                'chasis' => $row['n_chasis'],
                'color' => $row['color_car'],
                'items' => $items
            ];
            
            echo json_encode(['success' => true, 'presupuesto' => $presupuesto]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Presupuesto no encontrado']);
        }

    } else {
        // Listar todos
        $scope = $_GET['scope'] ?? 'user';
        $search = $_GET['search'] ?? '';
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 20;
        $offset = ($page - 1) * $limit;
        $es_admin = isset($_SESSION['empleado']) && $_SESSION['empleado'] == 2;
        $rut_empleado = $_SESSION['rut'] ?? null;

        $conditions = ["p.estado = true"];
        $params = [];
        $idx = 1;

        // Si el usuario es admin y quiere ver todos, no se aplica filtro de RUT.
        if ($es_admin && $scope === 'all') {
            // No se añade condición de filtro por RUT.
        } else {
            // Para todos los demás casos (empleado normal, o admin viendo 'Mis Presupuestos'),
            // se aplica el filtro por el RUT del usuario logueado.
            if (empty($rut_empleado)) {
                // No se puede filtrar si no hay sesión, devolver vacío.
                echo json_encode(['success' => true, 'presupuestos' => [], 'totalPages' => 0, 'currentPage' => 1]);
                exit;
            }
            $conditions[] = "p.creado_por_rut = $" . $idx++;
            $params[] = $rut_empleado;
        }

        // Búsqueda
        if (!empty($search)) {
            $conditions[] = "(p.nombre_cli ILIKE $" . $idx . " OR p.apellido_cli ILIKE $" . $idx . " OR p.rut_cli ILIKE $" . $idx . ")";
            $params[] = "%$search%";
            $idx++;
        }

        $sql_cond = implode(' AND ', $conditions);
        
        // Contar total
        $sql_count = "SELECT COUNT(*) as total FROM presupuesto p WHERE $sql_cond";
        $res_count = pg_query_params($conexion, $sql_count, $params);
        $total_rows = pg_fetch_result($res_count, 0, 'total');
        $total_pages = ceil($total_rows / $limit);

        // Obtener datos
        $sql = "SELECT p.id, p.nombre_cli, p.apellido_cli, p.rut_cli, p.correo_cli, p.telefono1_cli, p.fecha, p.total, p.creado_por_rut,
                       per.nombre as creado_por_nombre, per.apellido as creado_por_apellido
                FROM presupuesto p
                LEFT JOIN persona per ON p.creado_por_rut = per.rut
                WHERE $sql_cond
                ORDER BY p.id DESC 
                LIMIT $limit OFFSET $offset";
        
        $res = pg_query_params($conexion, $sql, $params);
        $presupuestos = [];
        
        while ($row = pg_fetch_assoc($res)) {
            $presupuestos[] = [
                'id' => $row['id'],
                'cliente' => $row['nombre_cli'] . ' ' . $row['apellido_cli'],
                'rut' => $row['rut_cli'],
                'correo' => $row['correo_cli'],
                'contacto1' => $row['telefono1_cli'],
                'creado_por_nombre' => trim($row['creado_por_nombre'] . ' ' . $row['creado_por_apellido']),
                'creado_por_rut' => $row['creado_por_rut'],
                'fecha' => $row['fecha'],
                'total' => $row['total']
            ];
        }

        echo json_encode([
            'success' => true, 
            'presupuestos' => $presupuestos,
            'totalPages' => $total_pages,
            'currentPage' => $page
        ]);
    }

} elseif ($method === 'DELETE') {
    // BORRADO LÓGICO
    $id = $_GET['id'] ?? null;
    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
        exit;
    }

    $rut_borra = $_SESSION['rut'];
    $query = "UPDATE presupuesto SET estado = false, borrado_por_rut = $1, borrado_en = now() WHERE id = $2";
    $res = pg_query_params($conexion, $query, [$rut_borra, $id]);

    if ($res) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
    }
}
?>