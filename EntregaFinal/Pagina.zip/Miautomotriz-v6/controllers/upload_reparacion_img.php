<?php
header('Content-Type: application/json');
session_start();

// 1. Seguridad: Verificar si el usuario es un empleado
if (!isset($_SESSION['empleado']) || !in_array($_SESSION['empleado'], [1, 2])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado.']);
    exit;
}

// 2. Verificar si se subió un archivo
if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No se recibió ningún archivo.']);
    exit;
}

$file = $_FILES['file'];

// 3. Verificar errores de subida
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error en la subida del archivo. Código: ' . $file['error']]);
    exit;
}

// 4. Definir y crear el directorio de subida si no existe
$uploadDir = dirname(__DIR__) . '/public/media/temp/';
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0775, true)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'No se pudo crear el directorio de subida. Verifique los permisos del servidor.']);
        exit;
    }
}

// 5. Validar el tipo de archivo (MIME type para más seguridad)
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($mimeType, $allowedMimeTypes)) {
    http_response_code(415);
    echo json_encode(['success' => false, 'error' => 'Tipo de archivo no permitido. Solo se aceptan JPG, PNG, GIF, WEBP.']);
    exit;
}

// 6. Generar un nombre único para evitar sobreescrituras
$fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
$uniqueName = uniqid('rep_', true) . '.' . strtolower($fileExtension);
$uploadPath = $uploadDir . $uniqueName;

// 7. Mover el archivo al destino final y devolver la ruta
if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
    // Devolver una ruta relativa a la raíz del proyecto para que el cliente pueda usarla
    $webPath = 'public/media/temp/' . $uniqueName;
    echo json_encode(['success' => true, 'path' => $webPath]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'No se pudo mover el archivo subido al destino final.']);
}
?>