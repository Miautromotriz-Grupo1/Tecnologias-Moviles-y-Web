<?php
session_start();

if (($_SESSION['empleado'] != 2)) {
    header("Location: index.php");
    exit(); 
}

@include '../models/conexion.php';


// 3. OBTENER RUT
if (isset($_GET['rut']) && !empty($_GET['rut'])) {
    $rut = trim($_GET['rut']);
    $query = "DELETE FROM persona WHERE rut = $1";
    $resultado = pg_query_params($conexion, $query, array($rut));

    if ($resultado) {
        // Verificar si realmente se borró alguna fila
        if (pg_affected_rows($resultado) > 0) {
            // Éxito
            header("Location: usuarios.php");
        } else {
            // El usuario no existía
            header("Location: usuarios.php");
        }
    } else {
        // Error de SQL (probablemente restricción de llave foránea)
        header("Location: usuarios.php");
    }

} else {
    // No se envió el RUT
    header("Location: usuarios.php");
}
?>