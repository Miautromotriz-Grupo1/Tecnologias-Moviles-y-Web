<?php
include '../models/conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

try {
    // Sanitización de datos para evitar errores con strings vacíos en campos numéricos/fecha
    $nombre = $data['nombre'];
    $precio_v = (isset($data['precio_v']) && $data['precio_v'] !== '') ? $data['precio_v'] : 0;
    
    $precio_c = (isset($data['precio_c']) && $data['precio_c'] !== '') ? $data['precio_c'] : null;
    $marca = (isset($data['marca']) && $data['marca'] !== '') ? $data['marca'] : null;
    $anio = (isset($data['anio']) && $data['anio'] !== '') ? $data['anio'] : null;
    $img = (isset($data['img']) && $data['img'] !== '') ? $data['img'] : null;
    $categoria = (isset($data['categoria']) && $data['categoria'] !== '') ? $data['categoria'] : null;
    $n_bodega = (isset($data['n_bodega']) && $data['n_bodega'] !== '') ? $data['n_bodega'] : null;
    $cantidad = (isset($data['cantidad']) && $data['cantidad'] !== '') ? $data['cantidad'] : 0;
    $servicio = 0; // Es un producto

    if (isset($data['id']) && !empty($data['id'])) {
        // Actualizar producto existente
        $query = "UPDATE piezas SET nombre = $1, precio_v = $2, precio_c = $3, marca = $4, anio = $5, img = $6, categoria = $7, n_bodega = $8, cantidad = $9, servicio = $10 WHERE id = $11";
        $params = [
            $nombre,
            $precio_v,
            $precio_c,
            $marca,
            $anio,
            $img,
            $categoria,
            $n_bodega,
            $cantidad,
            $servicio,
            $data['id']
        ];
        
        $result = pg_query_params($conexion, $query, $params);
        
        if ($result) {
            echo json_encode(['success' => true, 'id' => $data['id']]);
        } else {
            echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        }
    } else {
        // Insertar nuevo producto y obtener el ID generado
        $query = "INSERT INTO piezas (nombre, precio_v, precio_c, marca, anio, img, categoria, n_bodega, cantidad, servicio, creado) 
                  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW()) RETURNING id";
        $params = [
            $nombre,
            $precio_v,
            $precio_c,
            $marca,
            $anio,
            $img,
            $categoria,
            $n_bodega,
            $cantidad,
            $servicio
        ];
        
        $result = pg_query_params($conexion, $query, $params);
        
        if ($result) {
            $row = pg_fetch_assoc($result);
            $new_id = $row['id'];
            echo json_encode(['success' => true, 'id' => $new_id]);
        } else {
            echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        }
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>