<?php
date_default_timezone_set('America/Santiago');
include '../models/conexion.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}else{
     header("Location: ../views/index.php");
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function regresarConMensaje($mensaje,$header) {
    $_SESSION['error_registro'] = $mensaje;
    header("Location: ../views/$header");
    exit();                                 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $email = $_POST['rut'];
    $password = $_POST['password'];

    $sql = "SELECT rut, nombre, empleado, contrasenia,personaveri,token_expires_at FROM persona WHERE rut = $1";
    
    $resultado = pg_query_params($conexion, $sql, array($email));

    // Verificamos si hubo error técnico en la consulta
    if (!$resultado) {
        echo "Error en la consulta SQL.";
        exit;
    }

    // 3. CAMBIO: Usamos pg_num_rows en lugar de num_rows
    if (pg_num_rows($resultado) === 1) {
        
        // 4. CAMBIO: Usamos pg_fetch_assoc en lugar de fetch_assoc
        $fila = pg_fetch_assoc($resultado);

        if ($fila['personaveri']!='f'){
            if (password_verify($password, $fila['contrasenia'])) {
            // Login Exitoso
            $_SESSION['rut'] = $fila['rut'];
            $_SESSION['nombre'] = $fila['nombre'];
            $_SESSION['empleado'] = $fila['empleado'];

            $sqlClean = "UPDATE persona SET token_hash = NULL, token_expires_at = NULL WHERE rut = $1";
            pg_query_params($conexion, $sqlClean, array($fila['rut']));

            header("Location: ../views/index.php"); 
            exit();
        } else {
            regresarConMensaje('Contraseña incorrecta','login.php');
        }
        }else{
            $fecha_actual = new DateTime(); 
            $fecha_expiracion = new DateTime($fila['token_expires_at']);
            if ($fecha_actual > $fecha_expiracion) {
                
                // 3. Eliminamos al usuario de la base de datos
                $sql_delete = "DELETE FROM persona WHERE rut = $1";
                $borrado = pg_query_params($conexion, $sql_delete, array($email)); // $email contiene el rut del POST

                if ($borrado) {
                    regresarConMensaje('El tiempo de verificación expiró. Su cuenta ha sido eliminada.','register.php');
                   }

            }
             regresarConMensaje('Cuenta no verificado','login.php');
        }
        
    } else {
        regresarConMensaje('El rut no existe','login.php');
    }
}
?>