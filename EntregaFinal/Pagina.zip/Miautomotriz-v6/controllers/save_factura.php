<?php
// Endpoint para guardar y listar facturas en Postgres - Tabla 'factura'
header('Content-Type: application/json; charset=utf-8');
require_once '../models/conexion.php';

if (session_status() == PHP_SESSION_NONE) { 
    session_start(); 
}

// Asegurar que existan las columnas necesarias en tabla factura
@pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS creado_por_rut VARCHAR(20)");
@pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS personaid VARCHAR(20)");
@pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS data JSONB");
@pg_query($conexion, "ALTER TABLE factura ADD COLUMN IF NOT EXISTS borrado BOOLEAN DEFAULT FALSE");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $obj = json_decode($raw, true);

    // Manejo de borrado lógico (soft delete)
    if (isset($obj['action']) && $obj['action'] === 'delete') {
        $id_to_delete = $obj['id'] ?? null;
        if ($id_to_delete) {
            $rut_empleado = $_SESSION['rut'] ?? null;
            $es_admin = ($_SESSION['empleado'] ?? 0) == 2;
            
            if ($es_admin) {
                $query = "UPDATE factura SET borrado = TRUE WHERE id = $1";
                $res = pg_query_params($conexion, $query, [$id_to_delete]);
            } else {
                $query = "UPDATE factura SET borrado = TRUE WHERE id = $1 AND creado_por_rut = $2";
                $res = pg_query_params($conexion, $query, [$id_to_delete, $rut_empleado]);
            }

            if ($res && pg_affected_rows($res) > 0) {
                echo json_encode(['success' => true]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Factura no encontrada o sin permisos para borrar.']);
            }
            exit;
        }
    }

    if (!$obj) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'JSON inválido']);
        exit;
    }
    
    $rut_empleado = $_SESSION['rut'] ?? null;
    $json = json_encode($obj);
    $id = !empty($obj['id']) ? intval($obj['id']) : null;
    $personaid = $obj['cliente']['rut'] ?? null;
    
    // Calcular totales
    $subtotal = 0.0;
    $cantidad_total = 0;
    $repuestos = [];
    
    if (!empty($obj['items']) && is_array($obj['items'])) {
        foreach ($obj['items'] as $item) {
            $cant = floatval($item['cantidad'] ?? 0);
            $precio = floatval($item['precio'] ?? 0);
            $subtotal += $cant * $precio;
            $cantidad_total += (int)$cant;
            if (!empty($item['descripcion'])) {
                $repuestos[] = $item['descripcion'];
            }
        }
    }
    
    $neto = $subtotal;
    $iva_porcentaje = 0.19; // Corregido a 19%
    $iva_monto = $neto * $iva_porcentaje;
    $total = $neto + $iva_monto;
    $repuestos_str = implode(', ', array_slice($repuestos, 0, 100));
    $mecanico = $obj['vehiculo']['mecanico'] ?? null;
    
    // Parsear fecha de manera más robusta
    $fecha_str = $obj['fecha'] ?? date('d/m/Y');
    $fecha_emision = date('Y-m-d'); // Valor por defecto
    if (preg_match('#^(\d{2})/(\d{2})/(\d{4})$#', $fecha_str, $parts)) {
        // Formato dd/mm/yyyy
        $fecha_emision = $parts[3] . '-' . $parts[2] . '-' . $parts[1];
    } elseif (strtotime($fecha_str)) {
        // Otros formatos que strtotime pueda entender (como ISO 8601 o yyyy-mm-dd)
        $fecha_emision = date('Y-m-d', strtotime($fecha_str));
    } else {
        $fecha_emision = date('Y-m-d'); // Fallback final
    }
    
    // Actualizar o insertar
    if ($id) {
        $result = pg_query_params($conexion, 
            'UPDATE factura SET fechaemision = $1, neto = $2, iva = $3, total = $4, cantidad = $5, repuestosusados = $6, mecanicoencargado = $7, data = $8, creado_por_rut = $9, personaid = $11 WHERE id = $10 RETURNING id',
            array($fecha_emision, intval($neto), $iva_porcentaje, $total, $cantidad_total, $repuestos_str, $mecanico, $json, $rut_empleado, $id, $personaid)
        );
    } else {
        $result = pg_query_params($conexion,
            'INSERT INTO factura(fechaemision, neto, iva, total, cantidad, repuestosusados, mecanicoencargado, creado_por_rut, data, personaid) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id',
            array($fecha_emision, intval($neto), $iva_porcentaje, $total, $cantidad_total, $repuestos_str, $mecanico, $rut_empleado, $json, $personaid)
        );
    }

    if (!$result) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }
    
    $row = pg_fetch_assoc($result);
    $new_id = $row['id'] ?? $id;

    echo json_encode(['success' => true, 'id' => $new_id]);
    exit;
}

if ($method === 'GET') {
    $rut_empleado = $_SESSION['rut'] ?? null;
    $es_admin = ($_SESSION['empleado'] ?? 0) == 2;
    
    // Obtener una sola factura por ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        
        if ($es_admin) {
            $query = 'SELECT id, data, creado_por_rut FROM factura WHERE id = $1 AND borrado = FALSE';
            $res = pg_query_params($conexion, $query, [$id]);
        } else {
            $query = 'SELECT id, data, creado_por_rut FROM factura WHERE id = $1 AND creado_por_rut = $2 AND borrado = FALSE';
            $res = pg_query_params($conexion, $query, [$id, $rut_empleado]);
        }
        
        if ($res && pg_num_rows($res) > 0) {
            $r = pg_fetch_assoc($res);
            $data = json_decode($r['data'], true);
            if ($data) {
                $data['id'] = (int)$r['id'];
                $data['creado_por_rut'] = $r['creado_por_rut'];
                echo json_encode(['success' => true, 'factura' => $data]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Datos JSON inválidos']);
            }
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Factura no encontrada o sin permisos']);
        }
        exit;
    }
    
    // Obtener lista de facturas
    $scope = $_GET['scope'] ?? 'user';
    
    if ($es_admin && $scope === 'all') {
        $query = 'SELECT id, data, creado_por_rut FROM factura WHERE data IS NOT NULL AND borrado = FALSE ORDER BY id DESC LIMIT 100';
        $res = pg_query($conexion, $query);
    } else {
        if (!$rut_empleado) {
            echo json_encode(['success' => true, 'lista' => []]);
            exit;
        }
        $query = 'SELECT id, data, creado_por_rut FROM factura WHERE creado_por_rut = $1 AND data IS NOT NULL AND borrado = FALSE ORDER BY id DESC LIMIT 100';
        $res = pg_query_params($conexion, $query, array($rut_empleado));
    }
    
    if (!$res) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
        exit;
    }
    
    $out = [];
    while ($r = pg_fetch_assoc($res)) {
        if ($r['data']) {
            $data = json_decode($r['data'], true);
            if ($data && is_array($data)) {
                $data['id'] = (int)$r['id'];
                $data['creado_por_rut'] = $r['creado_por_rut'];
                $out[] = $data;
            }
        }
    }
    echo json_encode(['success' => true, 'lista' => $out]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Método no permitido']);
?>