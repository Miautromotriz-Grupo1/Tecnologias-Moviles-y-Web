<?php
include '../models/conexion.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['empleado'])) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'error' => 'ID no válido']);
    exit;
}

try {
    // Consultar la tabla presupuesto y unir con vehiculo
    $query = "
        SELECT 
            p.nombre_cli, p.rut_cli, p.telefono1_cli, p.correo_cli,
            v.marca_car, v.modelo_car, v.anio_car, v.matricula, v.color_car, v.kilometraje
        FROM presupuesto p
        LEFT JOIN vehiculo v ON p.vin_vehiculo = v.vin_vehiculo
        WHERE p.id = $1 AND p.estado = true
    ";
    $res = @pg_query_params($conexion, $query, [$id]);

    if (!$res) {
        throw new Exception("Error al consultar cotización (Verifica que las tablas 'presupuesto' y 'vehiculo' existan)");
    }

    $row = pg_fetch_assoc($res);

    if ($row) {
        // Mapear datos desde las columnas correctas
        $data = [
            'cliente' => $row['nombre_cli'] ?? '',
            'rut' => $row['rut_cli'] ?? '',
            'telefono' => $row['telefono1_cli'] ?? '',
            'correo' => $row['correo_cli'] ?? '',
            
            'marca' => $row['marca_car'] ?? '',
            'modelo' => $row['modelo_car'] ?? '',
            'patente' => $row['matricula'] ?? '',
            'anio' => $row['anio_car'] ? date('Y', strtotime($row['anio_car'])) : '',
            'color' => $row['color_car'] ?? '',
            'km' => $row['kilometraje'] ?? ''
        ];

        // Obtener los items asociados desde presupuesto_detalle
        $query_items = "
            SELECT descripcion, cantidad, valor, unidad
            FROM presupuesto_detalle
            WHERE presupuesto_id = $1
        ";
        $res_items = pg_query_params($conexion, $query_items, [$id]);
        $items = [];
        if ($res_items) {
            while ($item_row = pg_fetch_assoc($res_items)) {
                $items[] = [
                    'descripcion' => $item_row['descripcion'],
                    'cantidad' => $item_row['cantidad'],
                    'precio' => $item_row['valor'],
                    'unidad' => $item_row['unidad']
                ];
            }
        }
        $data['items'] = $items;

        echo json_encode(['success' => true, 'data' => $data]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Cotización no encontrada o ha sido eliminada']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>