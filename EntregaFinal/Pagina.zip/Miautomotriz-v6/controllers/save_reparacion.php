<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../models/conexion.php';
session_start();

if (!isset($_SESSION['empleado']) || !in_array($_SESSION['empleado'], [1, 2])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado']);
    exit;
}

// Crear tabla si no existe (usando SERIAL para id para autoincremento)
$sql = "CREATE TABLE IF NOT EXISTS ordenes_trabajo(
    id SERIAL PRIMARY KEY,
    nombre_mdo text NOT NULL,
    precio_mdo integer,
    img_mdo text,
    detalles_mdo text,
    fecha_fin_mdo date,
    fecha_en_mdo timestamp without time zone DEFAULT now(),
    borrado boolean DEFAULT false,
    CONSTRAINT ordenes_trabajo_personaid_fkey FOREIGN key(nombre_mdo) REFERENCES persona(rut)
);";
@pg_query($conexion, $sql);

// Asegurar columna borrado
@pg_query($conexion, "ALTER TABLE ordenes_trabajo ADD COLUMN IF NOT EXISTS borrado boolean DEFAULT false");

$method = $_SERVER['REQUEST_METHOD'];
$rut_empleado = $_SESSION['rut'] ?? null;

if ($method === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data) {
        echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
        exit;
    }

    $id = isset($data['id']) && $data['id'] !== 'Nuevo' ? intval($data['id']) : null;
    $new_id = null;

    pg_query($conexion, "BEGIN"); // Iniciar transacción

    try {
        // Calcular precio total
        $precio_mdo = 0;
        if (isset($data['items']) && is_array($data['items'])) {
            foreach ($data['items'] as $item) {
                $precio_mdo += (floatval($item['cantidad']) * floatval($item['precio']));
            }
            $precio_mdo = round($precio_mdo * 1.19); // + IVA
        }

        // Parsear fecha
        $fecha_fin_mdo = $data['fecha'] ?? date('Y-m-d');
        if (strpos($fecha_fin_mdo, '/') !== false) {
            $parts = explode('/', $fecha_fin_mdo);
            if (count($parts) == 3) $fecha_fin_mdo = "{$parts[2]}-{$parts[1]}-{$parts[0]}";
        }

        // 1. Insertar o actualizar para obtener el ID
        if ($id) {
            $query = "UPDATE ordenes_trabajo SET precio_mdo=$1, fecha_fin_mdo=$2 WHERE id=$3 AND nombre_mdo=$4 RETURNING id";
            $res = pg_query_params($conexion, $query, [$precio_mdo, $fecha_fin_mdo, $id, $rut_empleado]);
            $new_id = $id;
        } else {
            $query = "INSERT INTO ordenes_trabajo (nombre_mdo, precio_mdo, fecha_fin_mdo, fecha_en_mdo, detalles_mdo) VALUES ($1, $2, $3, NOW(), '{\"status\":\"processing\"}') RETURNING id";
            $res = pg_query_params($conexion, $query, [$rut_empleado, $precio_mdo, $fecha_fin_mdo]);
        }

        if (!$res || !($row = pg_fetch_assoc($res))) {
            throw new Exception("No se pudo obtener el ID de la orden de trabajo: " . pg_last_error($conexion));
        }
        $new_id = $row['id'];

        // 2. Procesar y mover imágenes
        $final_image_paths = ['antes' => [], 'despues' => []];
        $baseUploadDir = dirname(__DIR__) . '/public/media/temp/';
        $order_dir = $baseUploadDir . $new_id . '/';

        if (!is_dir($order_dir)) {
            if (!mkdir($order_dir, 0775, true)) {
                throw new Exception("No se pudo crear el directorio para la orden: " . $order_dir . ". Verifique los permisos del servidor.");
            }
        }

        function process_images($image_set, $type, $order_dir, $new_id) {
            $final_paths = [];
            $project_root = dirname(__DIR__);
            $web_base_path = 'public/media/temp/' . $new_id . '/';

            foreach ($image_set as $index => $temp_web_path) {
                // $temp_web_path es como 'public/media/temp/rep_....jpg'
                $temp_server_path = $project_root . '/' . $temp_web_path;

                // Comprobar si es un archivo temporal que necesita ser movido
                if (file_exists($temp_server_path) && strpos($temp_web_path, 'public/media/temp/') === 0) {
                    $file_extension = strtolower(pathinfo($temp_server_path, PATHINFO_EXTENSION));
                    $new_filename = $type . '_' . ($index + 1) . '.' . $file_extension;
                    
                    $new_server_path = $order_dir . $new_filename;
                    $new_web_path = $web_base_path . $new_filename;

                    if (rename($temp_server_path, $new_server_path)) {
                        $final_paths[] = $new_web_path; // Guardar la nueva ruta accesible desde la web
                    } else {
                        // Si falla el renombrado, mantener la ruta temporal para depuración
                        $final_paths[] = $temp_web_path;
                    }
                } else {
                    // Es una ruta existente, ya procesada. Mantenerla.
                    $final_paths[] = $temp_web_path;
                }
            }
            return $final_paths;
        }

        if (isset($data['imagenes']['antes'])) $final_image_paths['antes'] = process_images($data['imagenes']['antes'], 'antes', $order_dir, $new_id);
        if (isset($data['imagenes']['despues'])) $final_image_paths['despues'] = process_images($data['imagenes']['despues'], 'despues', $order_dir, $new_id);

        // 3. Actualizar el objeto de datos con las rutas finales
        $data['imagenes'] = $final_image_paths;
        $detalles_mdo = json_encode($data);

        // 4. Actualizar la fila con el JSON completo
        $query_final = "UPDATE ordenes_trabajo SET detalles_mdo=$1 WHERE id=$2";
        if (!pg_query_params($conexion, $query_final, [$detalles_mdo, $new_id])) {
            throw new Exception("Error al guardar los detalles finales de la orden.");
        }

        pg_query($conexion, "COMMIT");
        echo json_encode(['success' => true, 'id' => $new_id]);

    } catch (Exception $e) {
        pg_query($conexion, "ROLLBACK");
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} elseif ($method === 'GET') {
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $res = pg_query_params($conexion, "SELECT * FROM ordenes_trabajo WHERE id=$1", [$id]);
        if ($row = pg_fetch_assoc($res)) {
            $orden = json_decode($row['detalles_mdo'], true);
            if (!$orden) $orden = [];
            $orden['id'] = $row['id'];
            echo json_encode(['success' => true, 'orden' => $orden]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No encontrado']);
        }
    } else {
        $res = pg_query_params($conexion, "SELECT id, detalles_mdo, fecha_fin_mdo FROM ordenes_trabajo WHERE nombre_mdo=$1 AND borrado=false ORDER BY id DESC LIMIT 50", [$rut_empleado]);
        $lista = [];
        while ($row = pg_fetch_assoc($res)) {
            $d = json_decode($row['detalles_mdo'], true);
            if ($d) {
                $d['id'] = $row['id'];
                $lista[] = $d;
            }
        }
        echo json_encode(['success' => true, 'lista' => $lista]);
    }
} elseif ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        pg_query_params($conexion, "UPDATE ordenes_trabajo SET borrado=true WHERE id=$1 AND nombre_mdo=$2", [$id, $rut_empleado]);
        echo json_encode(['success' => true]);
    }
}
?>