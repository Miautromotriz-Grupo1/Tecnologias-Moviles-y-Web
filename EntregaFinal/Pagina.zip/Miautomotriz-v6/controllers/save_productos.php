<?php
include '../models/conexion.php';
session_start();

header('Content-Type: application/json');

// Verificar si es administrador (empleado == 2)
if (!isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
    exit;
}

$id = isset($input['id']) && is_numeric($input['id']) ? (int)$input['id'] : null;
$nombre = isset($input['nombre']) ? trim($input['nombre']) : '';
$marca = isset($input['marca']) ? trim($input['marca']) : '';
$precio = isset($input['precio']) && is_numeric($input['precio']) ? (int)$input['precio'] : 0;
$anio_input = isset($input['anio']) && is_numeric($input['anio']) ? (int)$input['anio'] : 0;
$img = isset($input['img']) ? trim($input['img']) : '';

// Convertir el año numérico a formato fecha (YYYY-01-01) para la columna 'date'
$anio = ($anio_input > 0) ? $anio_input . '-01-01' : null;

if (empty($nombre)) {
    echo json_encode(['success' => false, 'error' => 'El nombre es obligatorio']);
    exit;
}

if ($id) {
    // Actualizar: Se actualizan precio_v y precio_c con el mismo valor
    $query = "UPDATE piezas SET nombre = $1, marca = $2, precio_v = $3, precio_c = $3, anio = $4, img = $5 WHERE id = $6";
    $params = [$nombre, $marca, $precio, $anio, $img, $id];
} else {
    // Insertar: Se insertan precio_v y precio_c con el mismo valor
    $query = "INSERT INTO piezas (nombre, marca, precio_v, precio_c, anio, img) VALUES ($1, $2, $3, $3, $4, $5)";
    $params = [$nombre, $marca, $precio, $anio, $img];
}

$res = pg_query_params($conexion, $query, $params);

if ($res) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => pg_last_error($conexion)]);
}
?>