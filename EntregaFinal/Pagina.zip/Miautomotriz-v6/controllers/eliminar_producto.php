<?php
include '../models/conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['empleado']) || $_SESSION['empleado'] != 2) {
    echo json_encode(['success' => false, 'error' => 'Acceso no autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
    exit;
}

$query = "DELETE FROM piezas WHERE id = $1";
$result = pg_query_params($conexion, $query, [$data['id']]);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    $error_message = pg_last_error($conexion);
    // Detectar error de clave foránea (foreign key)
    if (strpos($error_message, 'violates foreign key constraint') !== false) {
        // El producto está en uso en otra tabla (servicios, facturas, etc.)
        echo json_encode(['success' => false, 'error' => 'in_use', 'details' => 'Este producto no se puede eliminar porque está siendo utilizado en un servicio, presupuesto o factura.']);
    } else {
        // Otro tipo de error de base de datos
        echo json_encode(['success' => false, 'error' => $error_message]);
    }
}
?>