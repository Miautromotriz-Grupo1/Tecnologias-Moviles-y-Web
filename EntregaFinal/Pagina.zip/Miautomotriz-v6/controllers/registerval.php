<?php
// 1. INICIAR SESIÓN DE FORMA SEGURA
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// --- FUNCIÓN PARA REDIRIGIR CON ERROR ---
function regresarConError($mensaje) {
    $_SESSION['error_registro'] = $mensaje; 
    header("Location: register.php");       
    exit();                                 
}

// --- VALIDAR RUT ---
function validarRut($rut) {
    // 1. Limpiar el RUT 
    $rutLimpio = preg_replace('/[^k0-9]/i', '', $rut);
    
    // 2. Validar largo mínimo
    if (strlen($rutLimpio) < 8 || strlen($rutLimpio) > 9) {
        return false;
    }

    // 3. Separar cuerpo y dígito verificador
    $dv = substr($rutLimpio, -1);
    $numero = substr($rutLimpio, 0, strlen($rutLimpio) - 1);
    
    // 4. Calcular el DV esperado
    $i = 2;
    $suma = 0;
    foreach (array_reverse(str_split($numero)) as $v) {
        if ($i == 8) $i = 2;
        $suma += $v * $i;
        ++$i;
    }
    
    $dvr = 11 - ($suma % 11);
    
    if ($dvr == 11) $dvr = 0;
    if ($dvr == 10) $dvr = 'K';
    
    // 5. Comparar (strtoupper para asegurar que 'k' sea igual a 'K')
    return ((string)$dvr === strtoupper($dv));
}

// --- FORMATEAR RUT (Para guardar ordenado en BD: 12345678-9) ---
function formatearRut($rut) {
    $rutLimpio = preg_replace('/[^k0-9]/i', '', $rut);
    $dv = substr($rutLimpio, -1);
    $numero = substr($rutLimpio, 0, strlen($rutLimpio) - 1);
    return $numero . "-" . strtoupper($dv);
}
// ----------------------------------------

// 2. DEPENDENCIAS
if (!file_exists('vendor/autoload.php')) {
    regresarConError("Error interno: Falta librería de correos (Vendor).");
}
require 'vendor/autoload.php';

if (!file_exists('conexion.php')) {
    regresarConError("Error interno: No existe archivo de conexión.");
}
require 'conexion.php';

if (!isset($conexion) || !$conexion) {
    regresarConError("Error de conexión a la base de datos.");
}

// 3. RECIBIR DATOS
$rut = $_POST['rut'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$password_repeat = $_POST['password-repeat'] ?? '';

// 4. VALIDACIONES BÁSICAS
if (empty($rut) || empty($nombre) || empty($email) || empty($password)) {
    regresarConError("Por favor completa todos los campos obligatorios.");
}

if ($password !== $password_repeat) {
    regresarConError("Las contraseñas no coinciden.");
}

// --- AQUI AGREGAMOS LA VALIDACIÓN DEL RUT ---
if (!validarRut($rut)) {
    regresarConError("El RUT ingresado no es válido.");
}

// Opcional: Reemplazamos el $rut por una versión limpia y formateada (Ej: 11222333-K)
// Esto evita que se guarde con puntos o sin guión en la BD.
$rut = formatearRut($rut); 

// 5. VERIFICAR SI EL CORREO YA EXISTE
$query = "SELECT * FROM persona WHERE correo = $1";
// Nota: Si quieres verificar también que el RUT no exista ya.
$result = pg_query_params($conexion, $query, array($email));

if (!$result) {
    regresarConError("Error al consultar la base de datos.");
}

if (pg_num_rows($result) > 0) {
    regresarConError("Este correo electrónico ya está registrado.");
}

// Verificar si el RUT ya existe 
$queryRut = "SELECT * FROM persona WHERE rut = $1";
$resultRut = pg_query_params($conexion, $queryRut, array($rut));
if (pg_num_rows($resultRut) > 0) {
    regresarConError("Este RUT ya está registrado.");
}

// 6. INSERTAR USUARIO
$password_hashed = password_hash($password, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(16));
$token_hash = hash("sha256", $token);
$token_expires_at = date("Y-m-d H:i:s", time() + 60 * 30); 

$queryInsert = "INSERT INTO persona (rut, nombre, apellido, correo, contrasenia, token_hash, token_expires_at, personaveri) VALUES ($1, $2, $3, $4, $5, $6, $7, FALSE)";
$resultInsert = pg_query_params($conexion, $queryInsert, array($rut, $nombre, $apellido, $email, $password_hashed, $token_hash, $token_expires_at));

if ($resultInsert) {
    // ENVIAR CORREO
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'proyectoicinf2@gmail.com'; 
        $mail->Password   = 'zkke fpjo nxcc xejs'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('proyectoicinf2@gmail.com', 'MIAUtomotriz');
        $mail->addAddress($email, $nombre);

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = 'Verificación de correo - MIAUtomotriz';
        
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        $path = "/pagina/v4/user_validation.php"; 
        $verificationLink = "$protocol://$host$path?token=$token";

        $mail->Body = "<h2>Hola $nombre,</h2><p>Verifica tu cuenta aquí: <a href='$verificationLink'>Enlace de verificación</a></p>";
        $mail->AltBody = "Verifica tu cuenta en: $verificationLink";

        $mail->send();
        
        // --- ÉXITO ---
        $_SESSION['mensaje_exito'] = "Registro exitoso. Revisa tu correo para activar la cuenta.";
        header("Location: login.php");
        exit();

    } catch (Exception $e) {
        regresarConError("Usuario registrado, pero falló el envío del correo de verificación.");
    }
} else {
    regresarConError("Error al registrar en la base de datos.");
}
?>